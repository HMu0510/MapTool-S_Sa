#include "stdafx.h"
#include "enemyManager.h"
#include "player.h"

HRESULT enemyManager::init()
{

	return S_OK;
}

void enemyManager::release()
{
}

void enemyManager::update()
{
	for (int i = 0; i < _vEnemy.size(); i++)
	{
		_vEnemy[i]->update();
	}
	this->playerCollision();
	this->attack();
}

void enemyManager::render()
{
	for (int i = 0; i < _vEnemy.size(); i++)
	{
		_vEnemy[i]->render();
	}
}

//Ÿ�԰� x, y��ǥ �޾� ���ʹ� ���Ϳ� �߰��ϱ�
void enemyManager::addEnemy(ENEMYTYPE type, float x, float y)
{
	enemy* enem = new enemy;
	enem->init();
	enem->setXY(x, y);
	enem->setType(type);
	enem->enemySetting();	
	
	_vEnemy.push_back(enem);
}

void enemyManager::hit(int idx)
{
	_vEnemy[idx]->hit();
}

//�÷��̾� �̸� �޾ƿͼ� �� �Ͱ� �浹
void enemyManager::playerCollision()
{
	RECT _rc;
	for (int i = 0; i < _vEnemy.size(); i++)
	{
		if (_vEnemy[i]->getType() == Cupa)
		{
			if (IntersectRect(&_rc, &_player->getRect((int)_player->getChamp()), &_vEnemy[i]->getFireRect()))
			{
				_player->hit();

			}
			else
			{
				SetWindowText(_hWnd, "����Ʈ");
			}
		}
	}
}

void enemyManager::attack()
{
	RECT _rc;
	for (int i = 0; i < _vEnemy.size(); i++)
	{
		if (IntersectRect(&_rc, &_player->getRect(_player->getChamp()), &_vEnemy[i]->getAttack()) && !_vEnemy[i]->getIsAttack())
		{
			if (_player->getRect(_player->getChamp()).left > _vEnemy[i]->getRect(_vEnemy[i]->getType()).left)
			{
				_vEnemy[i]->setIsLeft(false);
			}
			else
			{
				_vEnemy[i]->setIsLeft(true);
			}
			_vEnemy[i]->attack();
		}
	}
}
