#include "stdafx.h"
#include "inGameScene.h"

HRESULT inGameScene::init()
{
	_em = new enemyManager;
	_em->init();
	_isLoad = false;	

	_player = new player;
	_player->init();

	_em->setPlayer(_player);

	return S_OK;
}

void inGameScene::release()
{
	_player->release();
	_em->release();
}

void inGameScene::update()
{
	if (!_isLoad)
	{
		this->load();
		_isLoad = true;
	}

	//sprintf(str, "%d", _vEnemyData.size());
	//SetWindowText(_hWnd, str);
	_player->update();
	_em->update();
}

void inGameScene::render()
{
	IMAGEMANAGER->findImage("collision")->render(getMemDC(), 0, 0, 0, 0, 1200, 700);
	_player->render();
	_em->render();

}

void inGameScene::load()
{
	_readCnt = 0;
	HANDLE file;
	DWORD read;
	LARGE_INTEGER l_int;
	_vEnemyData.clear();

	file = CreateFile("save.map", GENERIC_READ, 0, NULL, OPEN_EXISTING,
		FILE_ATTRIBUTE_NORMAL, NULL);
	ReadFile(file, _tiles, sizeof(tagTile) * TILEX * TILEY, &read, NULL);
	CloseHandle(file);
	file = CreateFile("vectorSizeSave.map", GENERIC_READ, 0, NULL, OPEN_EXISTING,
		FILE_ATTRIBUTE_NORMAL, NULL);
	ReadFile(file, &_vectorSize, sizeof(int), &read, NULL);
	CloseHandle(file);
	//�÷��̾� �ε�
	file = CreateFile("savePlayer.map", GENERIC_READ, 0, NULL, OPEN_EXISTING,
		FILE_ATTRIBUTE_NORMAL, NULL);
	ReadFile(file, &_playerData, sizeof(PLAYERDATA), &read, NULL);
	CloseHandle(file);
	//���ʹ� �ε�
	file = CreateFile("saveEnemy.map", GENERIC_READ, 0, NULL, OPEN_EXISTING,
		FILE_ATTRIBUTE_NORMAL, NULL);
	while (_readCnt < _vectorSize)
	{
		ENEMYDATA _data;
		l_int.QuadPart = sizeof(ENEMYDATA) * _readCnt;
		SetFilePointerEx(file, l_int, NULL, FILE_CURRENT);
		ReadFile(file, &_data, sizeof(ENEMYDATA), &read, NULL);
		_vEnemyData.push_back(_data);
		_readCnt++;
	}
	CloseHandle(file);

	//�ε��� ���ʹ� ����
	for (int i = 0; i < _vEnemyData.size(); i++)
	{
		_em->addEnemy(_vEnemyData[i].type, _vEnemyData[i].x, _vEnemyData[i].y);
	}

	//�ε��� �÷��̾� ����
	_player->setChamp(_playerData.champ);
	_player->setXY(_playerData.x, _playerData.y);
	//_player->init();
	_player->playerSetting();
}
