#include "stdafx.h"
#include "inGameScene.h"

HRESULT inGameScene::init()
{

	SOUNDMANAGER->addSound("1�����", "SOUND/1�������.mp3", true, true);
	SOUNDMANAGER->addSound("2�����", "SOUND/2�������.mp3", true, true);
	SOUNDMANAGER->addSound("3�����", "SOUND/3�������.mp3", true, true);
	SOUNDMANAGER->addSound("4�����", "SOUND/4�������.mp3", true, true);
	SOUNDMANAGER->addSound("5�����", "SOUND/5�������.mp3", true, true);
	SOUNDMANAGER->addSound("6�����", "SOUND/6�������.mp3", true, true);
	_em = new enemyManager;
	_em->init();
	_isLoad = false;	

	_player = new player;
	_player->init();

	_em->setPlayer(_player);
	_player->setEnemyManager(_em);
	this->load();
	if (isSelectBg[0])SOUNDMANAGER->play("1�����", 0.5f);
	else if (isSelectBg[1])SOUNDMANAGER->play("2�����", 0.5f);
	else if (isSelectBg[2])SOUNDMANAGER->play("3�����", 0.5f);
	else if (isSelectBg[3])SOUNDMANAGER->play("4�����", 0.5f);
	else if (isSelectBg[4])SOUNDMANAGER->play("5�����", 0.7f);
	else if (isSelectBg[5])SOUNDMANAGER->play("6�����", 0.5f);	
	_collision = IMAGEMANAGER->findImage("collision");
	for (int i = 0; i < TILEY; i++)
	{
		for (int j = 0; j < TILEX; j++)
		{
			_tiles[i * TILEX + j].rc = RectMake(j * TILESIZE, i * TILESIZE, TILESIZE, TILESIZE);
		}
	}
	return S_OK;
}

void inGameScene::release()
{
	_player->release();
	_em->release();
}

void inGameScene::update()
{

	_player->update();
	_em->update();
}

void inGameScene::render()
{
	for (int i = 0; i < TILEX * TILEY; i++)
	{
		//������Ʈ �������� �ٸ� �̹��� Ÿ�� ��Ÿ����
		if (_tiles[i].obj == OBJ_OBJECT1)
		{
			IMAGEMANAGER->frameRender("basic", _collision->getMemDC(), _tiles[i].rc.left, _tiles[i].rc.top,
				_tiles[i].objFrameX, _tiles[i].objFrameY);
		}
		if (_tiles[i].obj == OBJ_OBJECT2)
		{
			IMAGEMANAGER->frameRender("snow", _collision->getMemDC(), _tiles[i].rc.left, _tiles[i].rc.top,
				_tiles[i].objFrameX, _tiles[i].objFrameY);
		}
		if (_tiles[i].obj == OBJ_OBJECT3)
		{
			IMAGEMANAGER->frameRender("sky", _collision->getMemDC(), _tiles[i].rc.left, _tiles[i].rc.top,
				_tiles[i].objFrameX, _tiles[i].objFrameY);
		}
		if (_tiles[i].obj == OBJ_OBJECT4)
		{
			IMAGEMANAGER->frameRender("object", _collision->getMemDC(), _tiles[i].rc.left, _tiles[i].rc.top,
				_tiles[i].objFrameX, _tiles[i].objFrameY);
		}
		if (_tiles[i].obj == OBJ_OBJECT5)
		{
			IMAGEMANAGER->frameRender("basement", _collision->getMemDC(), _tiles[i].rc.left, _tiles[i].rc.top,
				_tiles[i].objFrameX, _tiles[i].objFrameY);
		}
	}
	for (int i = 0; i < 6; i++)
	{
		if (isSelectBg[i])
			switch (i)
			{
			case 0:
				IMAGEMANAGER->render("cloud", getMemDC(),_player->getColX()/2,_player->getColY()/2);
				break;
			case 1:
				IMAGEMANAGER->render("mountain", getMemDC(), _player->getColX() / 2, _player->getColY() / 2);
				break;
			case 2:
				IMAGEMANAGER->render("forest", getMemDC(), _player->getColX() / 2, _player->getColY() / 2);
				break;
			case 3:
				IMAGEMANAGER->render("sea", getMemDC(), _player->getColX() / 2, _player->getColY() / 2);
				break;
			case 4:
				IMAGEMANAGER->render("jungle", getMemDC(), _player->getColX() / 2, _player->getColY() / 2);
				break;
			case 5:
				IMAGEMANAGER->render("sky_bg", getMemDC(), _player->getColX() / 2, _player->getColY() / 2);
				break;
			}
	}
	IMAGEMANAGER->findImage("collision")->render(getMemDC(), _player->getColX(), _player->getColY());
	_player->render();
	_em->render();

}

void inGameScene::load()
{
	_readCnt = 0;
	HANDLE file;
	DWORD read;
	LARGE_INTEGER l_int;
	_vEnemyData.clear();

	file = CreateFile("save.map", GENERIC_READ, 0, NULL, OPEN_EXISTING,
		FILE_ATTRIBUTE_NORMAL, NULL);
	ReadFile(file, _tiles, sizeof(tagTile) * TILEX * TILEY, &read, NULL);
	ReadFile(file, isSelectBg, sizeof(isSelectBg) * 6, &read, NULL);
	CloseHandle(file);
	file = CreateFile("vectorSizeSave.map", GENERIC_READ, 0, NULL, OPEN_EXISTING,
		FILE_ATTRIBUTE_NORMAL, NULL);
	ReadFile(file, &_vectorSize, sizeof(int), &read, NULL);
	CloseHandle(file);
	file = CreateFile("savePlayer.map", GENERIC_READ, 0, NULL, OPEN_EXISTING,
		FILE_ATTRIBUTE_NORMAL, NULL);
	ReadFile(file, &_playerData, sizeof(PLAYERDATA), &read, NULL);
	CloseHandle(file);
	file = CreateFile("saveEnemy.map", GENERIC_READ, 0, NULL, OPEN_EXISTING,
		FILE_ATTRIBUTE_NORMAL, NULL);
	while (_readCnt < _vectorSize)
	{
		ENEMYDATA _data;
		l_int.QuadPart = sizeof(ENEMYDATA) * _readCnt;
		SetFilePointerEx(file, l_int, NULL, FILE_CURRENT);
		ReadFile(file, &_data, sizeof(ENEMYDATA), &read, NULL);
		_vEnemyData.push_back(_data);
		_readCnt++;
	}
	CloseHandle(file);
	//�ε��� ���ʹ� ����
	for (int i = 0; i < _vEnemyData.size(); i++)
	{
		_em->addEnemy(_vEnemyData[i].type, _vEnemyData[i].x, _vEnemyData[i].y);
	}

	//�ε��� �÷��̾� ����

	_player->setChamp(_playerData.champ);
	_player->setXY(_playerData.x, _playerData.y);
	//_player->init();
	_player->playerSetting();

}
