#include "stdafx.h"
#include "startScene.h"

HRESULT startScene::init()
{
	SetWindowPos(_hWnd, NULL, 100, 100, 1275, 720, 0);
	IMAGEMANAGER->addImage("StartScene", "Images/����ȭ��.bmp", 1280, 720);
	IMAGEMANAGER->addImage("GameStart", "Images/���ӽ���.bmp", 300, 69);
	IMAGEMANAGER->addImage("MapToolButton", "Images/������ư.bmp", 300, 69);
	IMAGEMANAGER->addImage("GameOver", "Images/��������.bmp", 300, 69);
	SOUNDMANAGER->addSound("���ۼҸ�", "SOUND/StartSound.mp3");

	//��Ʈ ��ġ �ʱ�ȭ
	//_rc = RectMakeCenter(WINSIZEX / 2, WINSIZEY - 200, 200, 100);
	_start = RectMakeCenter(200, 400, 300, 69);
	_mapTool = RectMakeCenter(200, 500, 300, 69);
	_end = RectMakeCenter(200, 600, 300, 69);
	return S_OK;
}

void startScene::release()
{
}

void startScene::update()
{
	if (INPUT->GetKeyDown(VK_LBUTTON))
	{
		if (PtInRect(&_mapTool, _ptMouse))
		{
			SCENEMANAGER->loadScene("��������");
		}
		if (PtInRect(&_start, _ptMouse))
		{
			SOUNDMANAGER->play("���ۼҸ�");
			SCENEMANAGER->loadScene("�ε�ȭ��");
		}
		if (PtInRect(&_end, _ptMouse))
		{
			PostQuitMessage(0);
		}
	}

}

void startScene::render()
{
	IMAGEMANAGER->render("StartScene", getMemDC(), 0, -38);
	IMAGEMANAGER->render("GameStart", getMemDC(), _start.left, _start.top);
	IMAGEMANAGER->render("MapToolButton", getMemDC(), _mapTool.left, _mapTool.top);
	IMAGEMANAGER->render("GameOver", getMemDC(), _end.left, _end.top);
	//Rectangle(getMemDC(), _rc);
	//TextOut(getMemDC(), _rc.left + 50, _rc.top + 50, "START", strlen("START"));
}
