#include "stdafx.h"
#include "maptoolScene.h"

HRESULT maptoolScene::init()
{
	//���� ��ġ�� ���� �ε��� ��� ���� �ʱ�ȭ
	tmp = 0;

	//������ ī��Ʈ ���� �ʱ�ȭ
	pageCount = 0;

	//BnOå�ڸ� ��� ����â���� �����ϱ�
	_kindSelect = KIND_BG;

	//PnEå�ڸ� �÷��̾� ����â���� �����ϱ�
	_charSelect = CHARACTER_PLAYER;

	isCollision = isCollision = false;

	//��� ���� �̹��� 
	IMAGEMANAGER->addImage("sampleCloud", "��������.bmp", 100, 200);
	IMAGEMANAGER->addImage("sampleMountain", "�����.bmp", 100, 200);
	IMAGEMANAGER->addImage("sampleForest", "������.bmp", 100, 200);
	IMAGEMANAGER->addImage("sampleSea", "���ػ���.bmp", 100, 200);
	IMAGEMANAGER->addImage("sampleJungle", "���ۻ���.bmp", 100, 200);
	IMAGEMANAGER->addImage("sampleSky", "�ϴû���.bmp", 100, 200);


	//��� �̹��� 
	IMAGEMANAGER->addImage("cloud", "����.bmp", 4000, 1000);
	IMAGEMANAGER->addImage("mountain", "��.bmp", 4000, 1000);
	IMAGEMANAGER->addImage("forest", "��.bmp", 4000, 1000);
	IMAGEMANAGER->addImage("sea", "����.bmp", 4000, 1000);
	IMAGEMANAGER->addImage("jungle", "����.bmp", 4000, 1000);
	IMAGEMANAGER->addImage("sky_bg", "�ϴù��.bmp", 4000, 1000);

	//ó�� ����̹����� �ϴù������ �ʱ�ȭ
	for (int i = 0; i < 5; i++)
	{
		isSelectBg[i] = false;
	}

	//������Ʈ Ÿ�� �̹��� 
	IMAGEMANAGER->addFrameImage("basic", "�⺻��.bmp", 320, 360, SAMPLETILEX, SAMPLETILEY);		//�⺻��
	IMAGEMANAGER->addFrameImage("snow", "����.bmp", 320, 360, SAMPLETILEX, SAMPLETILEY);			//����
	IMAGEMANAGER->addFrameImage("sky", "�ϴ�.bmp", 320, 360, SAMPLETILEX, SAMPLETILEY);		    //�ϴ�
	IMAGEMANAGER->addFrameImage("object", "��ü.bmp", 320, 360, SAMPLETILEX, SAMPLETILEY);		//��ü
	IMAGEMANAGER->addFrameImage("basement", "���϶�.bmp", 320, 360, SAMPLETILEX, SAMPLETILEY);	//����

	//�÷��̾� �̹���
	IMAGEMANAGER->addImage("mario", "MarioIdle.bmp", 80, 80); //��������
	IMAGEMANAGER->addFrameImage("realMario", "RealMarioIdle.bmp", 80, 160, 1, 2); //�� ������
	IMAGEMANAGER->addFrameImage("luigi", "LuigiIdle.bmp", 80, 160, 1, 2); // ������
	IMAGEMANAGER->addFrameImage("toad", "ToadIdle.bmp", 80, 160, 1, 2); //��������

	for (int i = 0; i < 4; i++)
	{
		isSelectPlayer[i] = false;
		isRenderPlayer[i] = false;
		playerIndex[i] = 0;
	}

	//���ʹ� �̹���
	IMAGEMANAGER->addImage("WallIdle", "EnemyImages/WallIdle.bmp", 60, 80);
	IMAGEMANAGER->addImage("SkeletonIdle", "EnemyImages/SkeletonIdle.bmp", 48, 64);
	IMAGEMANAGER->addImage("RedTurtleIdle", "EnemyImages/RedTurtleIdle.bmp", 40, 80);
	IMAGEMANAGER->addImage("MushroomIdle", "EnemyImages/MushroomIdle.bmp", 40, 40);
	IMAGEMANAGER->addImage("MiniTurtleIdle", "EnemyImages/MiniTurtleIdle.bmp", 40, 40);
	IMAGEMANAGER->addImage("MiniCupaIdle", "EnemyImages/MiniCupaIdle.bmp", 64, 64);
	IMAGEMANAGER->addImage("GgulIdle", "EnemyImages/GgulIdle.bmp", 40, 40);
	IMAGEMANAGER->addImage("GreenTurtleIdle", "EnemyImages/GreenTurtleIdle.bmp", 40, 60);
	IMAGEMANAGER->addImage("CupaIdle", "EnemyImages/CupaIdle.bmp", 160, 160);



	for (int i = 0; i < 9; i++)
	{
		isSelectEnemy[i] = false;
		
	}
	
	//���� ���� �Һ��� �ʱ�ȭ
	isRenderBoss = false;

	//�޴��� ��Ʈ �ʱ�ȭ
	_rcMenu = RectMake(800, 0, 400, 600);
	//�޴��� �̹���
	IMAGEMANAGER->addImage("menu", "�޴���.bmp", 400, 600);

	//������(BnO) ��Ʈ �ʱ�ȭ
	_rcPageBnO = RectMake(800, 0, 400, 600);	
	//������(BnO) �̹���
	IMAGEMANAGER->addImage("tileBookBnO", "å��(BnO).bmp", 400, 600);

	//������(PnE) ��Ʈ �ʱ�ȭ
	_rcPagePnE = RectMake(800, 0, 400, 600);
	//������(PnE) �̹���
	IMAGEMANAGER->addImage("tileBookPnE", "å��(PnE).bmp", 400, 600);

	//�޴���ư �̹���
	IMAGEMANAGER->addFrameImage("button", "��ư.bmp", 131, 160, 1, 5);

	
	//��������
	this->maptoolSetup();
                                                                                                                                                                                                                
	
	return S_OK;
}

void maptoolScene::release()
{
}

void maptoolScene::update()
{

	//��� ���� �̹��� ��ǥ ������Ʈ
	//IMAGEMANAGER->findImage("sampleCloud")->setX(_rcPageBnO.left + 35);
	//IMAGEMANAGER->findImage("sampleCloud")->setY(_rcPageBnO.top + 83);
	//IMAGEMANAGER->findImage("sampleMountain")->setX(_rcPageBnO.left + 150);
	//IMAGEMANAGER->findImage("sampleMountain")->setY(_rcPageBnO.top + 83);
	//IMAGEMANAGER->findImage("sampleForest")->setX(_rcPageBnO.left + 265);
	//IMAGEMANAGER->findImage("sampleForest")->setY(_rcPageBnO.top + 83);
	//IMAGEMANAGER->findImage("sampleSea")->setX(_rcPageBnO.left + 35);
	//IMAGEMANAGER->findImage("sampleSea")->setY(_rcPageBnO.top + 303);
	//IMAGEMANAGER->findImage("sampleJungle")->setX(_rcPageBnO.left + 150);
	//IMAGEMANAGER->findImage("sampleJungle")->setY(_rcPageBnO.top + 303);
	//IMAGEMANAGER->findImage("sampleSky")->setX(_rcPageBnO.left + 265);
	//IMAGEMANAGER->findImage("sampleSky")->setY(_rcPageBnO.top + 303);

	//�÷��̾� ���� �̹��� ��ǥ ������Ʈ
	IMAGEMANAGER->findImage("mario")->setX(_rcPagePnE.left + 80);
	IMAGEMANAGER->findImage("mario")->setY(_rcPagePnE.top + 150);
	IMAGEMANAGER->findImage("realMario")->setX(_rcPagePnE.left + 230);
	IMAGEMANAGER->findImage("realMario")->setY(_rcPagePnE.top + 150);
	IMAGEMANAGER->findImage("luigi")->setX(_rcPagePnE.left + 80);
	IMAGEMANAGER->findImage("luigi")->setY(_rcPagePnE.top + 300);
	IMAGEMANAGER->findImage("toad")->setX(_rcPagePnE.left + 230);
	IMAGEMANAGER->findImage("toad")->setY(_rcPagePnE.top + 300);

	//���ʹ� ���� �̹��� ��ǥ ������Ʈ
	IMAGEMANAGER->findImage("WallIdle")->setX(_rcPagePnE.left + 60);
	IMAGEMANAGER->findImage("WallIdle")->setY(_rcPagePnE.top + 100);
	IMAGEMANAGER->findImage("SkeletonIdle")->setX(_rcPagePnE.left + 180);
	IMAGEMANAGER->findImage("SkeletonIdle")->setY(_rcPagePnE.top + 100);
	IMAGEMANAGER->findImage("RedTurtleIdle")->setX(_rcPagePnE.left + 300);
	IMAGEMANAGER->findImage("RedTurtleIdle")->setY(_rcPagePnE.top + 100);
	IMAGEMANAGER->findImage("MushroomIdle")->setX(_rcPagePnE.left + 60);
	IMAGEMANAGER->findImage("MushroomIdle")->setY(_rcPagePnE.top + 250);
	IMAGEMANAGER->findImage("CupaIdle")->setX(_rcPagePnE.left + 135);
	IMAGEMANAGER->findImage("CupaIdle")->setY(_rcPagePnE.top + 160);
	IMAGEMANAGER->findImage("MiniTurtleIdle")->setX(_rcPagePnE.left + 300);
	IMAGEMANAGER->findImage("MiniTurtleIdle")->setY(_rcPagePnE.top + 250);
	IMAGEMANAGER->findImage("MiniCupaIdle")->setX(_rcPagePnE.left + 60);
	IMAGEMANAGER->findImage("MiniCupaIdle")->setY(_rcPagePnE.top + 400);
	IMAGEMANAGER->findImage("GgulIdle")->setX(_rcPagePnE.left + 180);
	IMAGEMANAGER->findImage("GgulIdle")->setY(_rcPagePnE.top + 400);
	IMAGEMANAGER->findImage("GreenTurtleIdle")->setX(_rcPagePnE.left + 300);
	IMAGEMANAGER->findImage("GreenTurtleIdle")->setY(_rcPagePnE.top + 400);


	//å�� ������ �̵� ��ư ��ǥ ������Ʈ
	_rcPrev = RectMake(_rcPageBnO.left + 38, _rcPageBnO.top + 511, 44, 44);		//���� ��ư ��Ʈ
	_rcNext = RectMake(_rcPageBnO.left + 318, _rcPageBnO.top + 511, 44, 44);	//���� ��ư ��Ʈ

	//BG, Obj ��ư ��Ʈ
	_rcBackGround = RectMake(_rcPageBnO.left + 77, _rcPageBnO.top + 37, 55, 30);
	_rcObject = RectMake(_rcPageBnO.left + 242, _rcPageBnO.top + 37, 80, 30);

	//player, enemy ��ư ��Ʈ
	_rcPlayer = RectMake(_rcPagePnE.left + 37, _rcPagePnE.top + 37, 160, 32);
	_rcEnemy = RectMake(_rcPagePnE.left + 231, _rcPagePnE.top + 37, 135, 32);


	//��漱��
	if (_kindSelect == KIND_BG)
	{
		//������� ������ ���
		if (PtInRect(&(IMAGEMANAGER->findImage("sampleCloud")->boudingBox()), _ptMouse))
		{
			if (INPUT->GetKey(VK_LBUTTON))
			{
				isSelectBg[0] = true;
				isSelectBg[1] = false;
				isSelectBg[2] = false;
				isSelectBg[3] = false;
				isSelectBg[4] = false;
				isSelectBg[5] = false;
			}
		}
		//���� ������ ���
		if (PtInRect(&(IMAGEMANAGER->findImage("sampleMountain")->boudingBox()), _ptMouse))
		{
			if (INPUT->GetKey(VK_LBUTTON))
			{
				isSelectBg[1] = true;
				isSelectBg[0] = false;
				isSelectBg[2] = false;
				isSelectBg[3] = false;
				isSelectBg[4] = false;
				isSelectBg[5] = false;
			}
		}
		//����� ������ ���
		if (PtInRect(&(IMAGEMANAGER->findImage("sampleForest")->boudingBox()), _ptMouse))
		{
			if (INPUT->GetKey(VK_LBUTTON))
			{
				isSelectBg[2] = true;
				isSelectBg[0] = false;
				isSelectBg[1] = false;
				isSelectBg[3] = false;
				isSelectBg[4] = false;
				isSelectBg[5] = false;
			}
		}
		//���ع�� ������ ���
		if (PtInRect(&(IMAGEMANAGER->findImage("sampleSea")->boudingBox()), _ptMouse))
		{
			if (INPUT->GetKey(VK_LBUTTON))
			{
				isSelectBg[3] = true;
				isSelectBg[0] = false;
				isSelectBg[1] = false;
				isSelectBg[2] = false;
				isSelectBg[4] = false;
				isSelectBg[5] = false;
			}
		}
		//���۹�� ������ ���
		if (PtInRect(&(IMAGEMANAGER->findImage("sampleJungle")->boudingBox()), _ptMouse))
		{
			if (INPUT->GetKey(VK_LBUTTON))
			{
				isSelectBg[4] = true;
				isSelectBg[0] = false;
				isSelectBg[1] = false;
				isSelectBg[2] = false;
				isSelectBg[3] = false;
				isSelectBg[5] = false;
			}
		}
		//�ϴù�� ������ ���
		if (PtInRect(&(IMAGEMANAGER->findImage("sampleSky")->boudingBox()), _ptMouse))
		{
			if (INPUT->GetKey(VK_LBUTTON))
			{
				isSelectBg[5] = true;
				isSelectBg[1] = false;
				isSelectBg[2] = false;
				isSelectBg[3] = false;
				isSelectBg[4] = false;
				isSelectBg[0] = false;
			}
		}
	}

	//�÷��̾��
	if (_charSelect == CHARACTER_PLAYER)
	{
		if (PtInRect(&(IMAGEMANAGER->findImage("mario")->boudingBox()), _ptMouse))
		{
			if (INPUT->GetKey(VK_LBUTTON))
			{
				isSelectPlayer[0] = true;
				isSelectPlayer[1] = false;
				isSelectPlayer[2] = false;
				isSelectPlayer[3] = false;
			}
		}
		if (PtInRect(&(IMAGEMANAGER->findImage("realMario")->boudingBox()), _ptMouse))
		{
			if (INPUT->GetKey(VK_LBUTTON))
			{
				isSelectPlayer[1] = true;
				isSelectPlayer[0] = false;
				isSelectPlayer[2] = false;
				isSelectPlayer[3] = false;
			}
		}
		if (PtInRect(&(IMAGEMANAGER->findImage("luigi")->boudingBox()), _ptMouse))
		{
			if (INPUT->GetKey(VK_LBUTTON))
			{
				isSelectPlayer[2] = true;
				isSelectPlayer[1] = false;
				isSelectPlayer[0] = false;
				isSelectPlayer[3] = false;
			}
		}
		if (PtInRect(&(IMAGEMANAGER->findImage("toad")->boudingBox()), _ptMouse))
		{
			if (INPUT->GetKey(VK_LBUTTON))
			{
				isSelectPlayer[3] = true;
				isSelectPlayer[0] = false;
				isSelectPlayer[2] = false;
				isSelectPlayer[1] = false;
			}
		}

	}
	//���ʹ̼��� *******����*******
	if (_charSelect == CHARACTER_ENEMY ) 
	{
		if (PtInRect(&(IMAGEMANAGER->findImage("WallIdle")->boudingBox()), _ptMouse))
		{
			if (INPUT->GetKey(VK_LBUTTON))
			{
				isSelectEnemy[0] = true;
				isSelectEnemy[1] = false;
				isSelectEnemy[2] = false;
				isSelectEnemy[3] = false;
				isSelectEnemy[4] = false;
				isSelectEnemy[5] = false;
				isSelectEnemy[6] = false;
				isSelectEnemy[7] = false;
				isSelectEnemy[8] = false;
				_ctrlSelect = CTRL_NONE;



			}
		}
		if (PtInRect(&(IMAGEMANAGER->findImage("SkeletonIdle")->boudingBox()), _ptMouse))
		{
			if (INPUT->GetKey(VK_LBUTTON))
			{
				isSelectEnemy[1] = true;
				isSelectEnemy[0] = false;
				isSelectEnemy[2] = false;
				isSelectEnemy[3] = false;
				isSelectEnemy[4] = false;
				isSelectEnemy[5] = false;
				isSelectEnemy[6] = false;
				isSelectEnemy[7] = false;
				isSelectEnemy[8] = false;
				_ctrlSelect = CTRL_NONE;


			}
		}
		if (PtInRect(&(IMAGEMANAGER->findImage("RedTurtleIdle")->boudingBox()), _ptMouse))
		{
			if (INPUT->GetKey(VK_LBUTTON))
			{
				isSelectEnemy[2] = true;
				isSelectEnemy[0] = false;
				isSelectEnemy[1] = false;
				isSelectEnemy[3] = false;
				isSelectEnemy[4] = false;
				isSelectEnemy[5] = false;
				isSelectEnemy[6] = false;
				isSelectEnemy[7] = false;
				isSelectEnemy[8] = false;
				_ctrlSelect = CTRL_NONE;

			}
		}
		if (PtInRect(&(IMAGEMANAGER->findImage("MushroomIdle")->boudingBox()), _ptMouse))
		{
			if (INPUT->GetKey(VK_LBUTTON))
			{
				isSelectEnemy[3] = true;
				isSelectEnemy[0] = false;
				isSelectEnemy[2] = false;
				isSelectEnemy[1] = false;
				isSelectEnemy[4] = false;
				isSelectEnemy[5] = false;
				isSelectEnemy[6] = false;
				isSelectEnemy[7] = false;
				isSelectEnemy[8] = false;
				_ctrlSelect = CTRL_NONE;

			}
		}
		if (PtInRect(&(IMAGEMANAGER->findImage("MiniTurtleIdle")->boudingBox()), _ptMouse))
		{
			if (INPUT->GetKey(VK_LBUTTON))
			{
				isSelectEnemy[4] = true;
				isSelectEnemy[0] = false;
				isSelectEnemy[2] = false;
				isSelectEnemy[3] = false;
				isSelectEnemy[1] = false;
				isSelectEnemy[5] = false;
				isSelectEnemy[6] = false;
				isSelectEnemy[7] = false;
				isSelectEnemy[8] = false;
				_ctrlSelect = CTRL_NONE;
			}
		}
		if (PtInRect(&(IMAGEMANAGER->findImage("MiniCupaIdle")->boudingBox()), _ptMouse))
		{
			if (INPUT->GetKey(VK_LBUTTON))
			{
				isSelectEnemy[5] = true;
				isSelectEnemy[0] = false;
				isSelectEnemy[2] = false;
				isSelectEnemy[3] = false;
				isSelectEnemy[4] = false;
				isSelectEnemy[1] = false;
				isSelectEnemy[6] = false;
				isSelectEnemy[7] = false;
				isSelectEnemy[8] = false;
				_ctrlSelect = CTRL_NONE;

			}
		}
		if (PtInRect(&(IMAGEMANAGER->findImage("GgulIdle")->boudingBox()), _ptMouse))
		{
			if (INPUT->GetKey(VK_LBUTTON))
			{
				isSelectEnemy[6] = true;
				isSelectEnemy[0] = false;
				isSelectEnemy[2] = false;
				isSelectEnemy[3] = false;
				isSelectEnemy[4] = false;
				isSelectEnemy[5] = false;
				isSelectEnemy[1] = false;
				isSelectEnemy[7] = false;
				isSelectEnemy[8] = false;
				_ctrlSelect = CTRL_NONE;

			}
		}
		if (PtInRect(&(IMAGEMANAGER->findImage("GreenTurtleIdle")->boudingBox()), _ptMouse))
		{
			if (INPUT->GetKey(VK_LBUTTON))
			{
				isSelectEnemy[7] = true;
				isSelectEnemy[0] = false;
				isSelectEnemy[2] = false;
				isSelectEnemy[3] = false;
				isSelectEnemy[4] = false;
				isSelectEnemy[5] = false;
				isSelectEnemy[6] = false;
				isSelectEnemy[1] = false;
				isSelectEnemy[8] = false;
				_ctrlSelect = CTRL_NONE;

			}
		}
		if (PtInRect(&(IMAGEMANAGER->findImage("CupaIdle")->boudingBox()), _ptMouse))
		{
			if (INPUT->GetKey(VK_LBUTTON))
			{
				isSelectEnemy[8] = true;
				isSelectEnemy[0] = false;
				isSelectEnemy[2] = false;
				isSelectEnemy[3] = false;
				isSelectEnemy[4] = false;
				isSelectEnemy[5] = false;
				isSelectEnemy[6] = false;
				isSelectEnemy[7] = false;
				isSelectEnemy[1] = false;
				_ctrlSelect = CTRL_NONE;

			}
		}

	}

	//���찳�϶� ���ʹ� ���� �ʱ�ȭ ( �ƹ��͵� �������� ���� )
	if (_ctrlSelect == CTRL_ERASER)
	{
		isSelectEnemy[0] = false;
		isSelectEnemy[1] = false;
		isSelectEnemy[2] = false;
		isSelectEnemy[3] = false;
		isSelectEnemy[4] = false;
		isSelectEnemy[5] = false;
		isSelectEnemy[6] = false;
		isSelectEnemy[7] = false;
		isSelectEnemy[8] = false;
	}

	if (INPUT->GetKey(VK_LBUTTON)) this->setMap();
	if (INPUT->GetKeyDown(VK_LBUTTON))
	{
		
		this->setPlayer();
		this->setEnemy();

		if (PtInRect(&_rcSave, _ptMouse))
		{
			_ctrlSelect = CTRL_SAVE;
			this->save();
		}
		if (PtInRect(&_rcLoad, _ptMouse))
		{
			_ctrlSelect = CTRL_LOAD;
			this->load();
		}
		if (PtInRect(&_rcBackGround, _ptMouse))
		{
			_ctrlSelect = CTRL_NONE;			
			_kindSelect = KIND_BG;				//Ÿ�� ���� = ���	
		}
		if (PtInRect(&_rcObject, _ptMouse))
		{
			_ctrlSelect = CTRL_NONE;			
			_kindSelect = KIND_OBJECT;			//Ÿ�� ���� = ������Ʈ
		}
		if (PtInRect(&_rcPlayer, _ptMouse))
		{
			_ctrlSelect = CTRL_NONE;			
			_charSelect = CHARACTER_PLAYER;		//�÷��̾�
		}
		if (PtInRect(&_rcEnemy, _ptMouse))
		{
			_ctrlSelect = CTRL_NONE;			
			_charSelect = CHARACTER_ENEMY;		//���ʹ�
		}
		if (PtInRect(&_rcEraser, _ptMouse))
		{
			_ctrlSelect = CTRL_ERASER;

		}

		//������ �ѱ��
		//����ȭ��ǥ Ŭ��
		if (PtInRect(&_rcPrev, _ptMouse))
		{
			if (pageCount > 0) pageCount--;
		}
		//����ȭ��ǥ Ŭ��
		if (PtInRect(&_rcNext, _ptMouse))
		{
			if (pageCount < 4) pageCount++;
		}

	}

	//������ ������ ��� ���
	if (pageCount < 0) pageCount = 0;
	if (pageCount > 4) pageCount = 4;

	
}



void maptoolScene::render()
{
	
	////���õ� ��� �̹��� ���
	//for (int i = 0; i < 6; i++)
	//{
	//	if(isSelectBg[i])
	//		switch (i)
	//		{
	//		case 0:
	//			IMAGEMANAGER->render("cloud", getMemDC(), 0, 0);
	//			break;
	//		case 1:
	//			IMAGEMANAGER->render("mountain", getMemDC(), 0, 0);
	//			break;
	//		case 2:
	//			IMAGEMANAGER->render("forest", getMemDC(), 0, 0);
	//			break;
	//		case 3:
	//			IMAGEMANAGER->render("sea", getMemDC(), 0, 0);
	//			break;
	//		case 4:
	//			IMAGEMANAGER->render("jungle", getMemDC(), 0, 0);
	//			break;
	//		case 5:
	//			IMAGEMANAGER->render("sky_bg", getMemDC(), 0, 0);
	//			break;
	//		}
	//}
	
	////�޴��� ��Ʈ ���
	//Rectangle(getMemDC(), _rcMenu);
	////�޴��� �̹��� ���
	//IMAGEMANAGER->render("menu", getMemDC(), _rcMenu.left, _rcMenu.top);
	//
	////������(BnO)��Ʈ ���
	//Rectangle(getMemDC(), _rcPageBnO);
	////������(BnO) �̹��� ���
	//IMAGEMANAGER->render("tileBookBnO", getMemDC(), _rcPageBnO.left, _rcPageBnO.top);

	//������(PnE)��Ʈ ���
	Rectangle(getMemDC(), _rcPagePnE);
	

	//������(PnE) �̹��� ���
	IMAGEMANAGER->render("tileBookPnE", getMemDC(), _rcPagePnE.left, _rcPagePnE.top);
	

	
	////��� ���� �̹��� ���
	//if (_kindSelect == KIND_BG)
	//{
	//	IMAGEMANAGER->render("sampleCloud", getMemDC(),IMAGEMANAGER->findImage("sampleCloud")->getX(), IMAGEMANAGER->findImage("sampleCloud")->getY());
	//	IMAGEMANAGER->render("sampleMountain", getMemDC(),IMAGEMANAGER->findImage("sampleMountain")->getX(), IMAGEMANAGER->findImage("sampleMountain")->getY());
	//	IMAGEMANAGER->render("sampleForest", getMemDC(),IMAGEMANAGER->findImage("sampleForest")->getX(), IMAGEMANAGER->findImage("sampleForest")->getY());
	//	IMAGEMANAGER->render("sampleJungle", getMemDC(),IMAGEMANAGER->findImage("sampleJungle")->getX(), IMAGEMANAGER->findImage("sampleJungle")->getY());
	//	IMAGEMANAGER->render("sampleSea", getMemDC(),IMAGEMANAGER->findImage("sampleSea")->getX(), IMAGEMANAGER->findImage("sampleSea")->getY());
	//	IMAGEMANAGER->render("sampleSky", getMemDC(),IMAGEMANAGER->findImage("sampleSky")->getX(), IMAGEMANAGER->findImage("sampleSky")->getY());
	//
	//}

	////������Ʈ ���� �̹��� ���
	//if (_kindSelect == KIND_OBJECT)
	//{
	//	////�������̵� ȭ��ǥ ��Ʈ ���
	//	//Rectangle(getMemDC(), _rcPrev);	//����
	//	//Rectangle(getMemDC(), _rcNext);	//����
	//	
	//	//������ �̵��� ���� ��� ��ȭ
	//	switch (pageCount)
	//	{case 0:
	//	{
	//		IMAGEMANAGER->render("basic", getMemDC(), _sampleTile[0].rc.left, _sampleTile[0].rc.top);
	//		
	//		break;
	//	}
	//	case 1:
	//	{
	//		IMAGEMANAGER->render("snow", getMemDC(), _sampleTile[0].rc.left, _sampleTile[0].rc.top);
	//		
	//		break;
	//	}
	//	case 2:
	//	{
	//		IMAGEMANAGER->render("sky", getMemDC(), _sampleTile[0].rc.left, _sampleTile[0].rc.top);
	//		
	//		break;
	//	}
	//	case 3:
	//	{
	//
	//		IMAGEMANAGER->render("object", getMemDC(), _sampleTile[0].rc.left, _sampleTile[0].rc.top);
	//		
	//		break;
	//	}
	//	case 4:
	//	{
	//		IMAGEMANAGER->render("basement", getMemDC(), _sampleTile[0].rc.left, _sampleTile[0].rc.top);
	//		
	//		break;
	//
	//	}
	//	}
	//	
	//}
	

	//�÷��̾� ���� �̹��� ���
	if (_charSelect == CHARACTER_PLAYER)
	{
		IMAGEMANAGER->render("mario", getMemDC(), IMAGEMANAGER->findImage("mario")->getX(), IMAGEMANAGER->findImage("mario")->getY());
		IMAGEMANAGER->frameRender("realMario", getMemDC(), IMAGEMANAGER->findImage("realMario")->getX(), IMAGEMANAGER->findImage("realMario")->getY(),0,0);
		IMAGEMANAGER->frameRender("luigi", getMemDC(), IMAGEMANAGER->findImage("luigi")->getX(), IMAGEMANAGER->findImage("luigi")->getY(), 0, 0);
		IMAGEMANAGER->frameRender("toad", getMemDC(), IMAGEMANAGER->findImage("toad")->getX(), IMAGEMANAGER->findImage("toad")->getY(), 0, 0);
	}

	//���ʹ� ���� �̹��� ���
	if (_charSelect == CHARACTER_ENEMY)
	{
		IMAGEMANAGER->render("WallIdle", getMemDC(), IMAGEMANAGER->findImage("WallIdle")->getX(), IMAGEMANAGER->findImage("WallIdle")->getY());
		IMAGEMANAGER->render("SkeletonIdle", getMemDC(), IMAGEMANAGER->findImage("SkeletonIdle")->getX(), IMAGEMANAGER->findImage("SkeletonIdle")->getY());
		IMAGEMANAGER->render("RedTurtleIdle", getMemDC(), IMAGEMANAGER->findImage("RedTurtleIdle")->getX(), IMAGEMANAGER->findImage("RedTurtleIdle")->getY());
		IMAGEMANAGER->render("MushroomIdle", getMemDC(), IMAGEMANAGER->findImage("MushroomIdle")->getX(), IMAGEMANAGER->findImage("MushroomIdle")->getY());
		IMAGEMANAGER->render("MiniTurtleIdle", getMemDC(), IMAGEMANAGER->findImage("MiniTurtleIdle")->getX(), IMAGEMANAGER->findImage("MiniTurtleIdle")->getY());
		IMAGEMANAGER->render("MiniCupaIdle", getMemDC(), IMAGEMANAGER->findImage("MiniCupaIdle")->getX(), IMAGEMANAGER->findImage("MiniCupaIdle")->getY());
		IMAGEMANAGER->render("GgulIdle", getMemDC(), IMAGEMANAGER->findImage("GgulIdle")->getX(), IMAGEMANAGER->findImage("GgulIdle")->getY());
		IMAGEMANAGER->render("GreenTurtleIdle", getMemDC(), IMAGEMANAGER->findImage("GreenTurtleIdle")->getX(), IMAGEMANAGER->findImage("GreenTurtleIdle")->getY());
		IMAGEMANAGER->render("CupaIdle", getMemDC(), IMAGEMANAGER->findImage("CupaIdle")->getX(), IMAGEMANAGER->findImage("CupaIdle")->getY());
	}

//	//�ΰ���ȭ�� ������Ʈ�� �׸���
//	for (int i = 0; i < TILEX * TILEY; i++)
//	{
//		if (_tiles[i].obj == OBJ_NONE) continue;
//
//		//������Ʈ �������� �ٸ� �̹��� Ÿ�� ��Ÿ����
//		if (_tiles[i].obj == OBJ_OBJECT1)
//		{
//			IMAGEMANAGER->frameRender("basic", getMemDC(), _tiles[i].rc.left, _tiles[i].rc.top,
//				_tiles[i].objFrameX, _tiles[i].objFrameY);
//		}
//		if (_tiles[i].obj == OBJ_OBJECT2)
//		{
//			IMAGEMANAGER->frameRender("snow", getMemDC(), _tiles[i].rc.left, _tiles[i].rc.top,
//				_tiles[i].objFrameX, _tiles[i].objFrameY);
//		}
//		if (_tiles[i].obj == OBJ_OBJECT3)
//		{
//			IMAGEMANAGER->frameRender("sky", getMemDC(), _tiles[i].rc.left, _tiles[i].rc.top,
//				_tiles[i].objFrameX, _tiles[i].objFrameY);
//		}
//		if (_tiles[i].obj == OBJ_OBJECT4)
//		{
//			IMAGEMANAGER->frameRender("object", getMemDC(), _tiles[i].rc.left, _tiles[i].rc.top,
//				_tiles[i].objFrameX, _tiles[i].objFrameY);
//		}
//		if (_tiles[i].obj == OBJ_OBJECT5)
//		{
//			IMAGEMANAGER->frameRender("basement", getMemDC(), _tiles[i].rc.left, _tiles[i].rc.top,
//				_tiles[i].objFrameX, _tiles[i].objFrameY);
//		}
//	}
	
	//�÷��̾� �ʿ� �׸���
	//��������
	if(isRenderPlayer[0])
		IMAGEMANAGER->render("mario", getMemDC(), _tiles[playerIndex[0]].rc.left, _tiles[playerIndex[0]].rc.top);
	//�𸶸���
	if (isRenderPlayer[1])
		IMAGEMANAGER->frameRender("realMario", getMemDC(), _tiles[playerIndex[1]].rc.left, _tiles[playerIndex[1]].rc.top,0,0);
	//������
	if (isRenderPlayer[2])
		IMAGEMANAGER->frameRender("luigi", getMemDC(), _tiles[playerIndex[2]].rc.left, _tiles[playerIndex[2]].rc.top,0,0);
	//��������
	if (isRenderPlayer[3])
		IMAGEMANAGER->frameRender("toad", getMemDC(), _tiles[playerIndex[3]].rc.left, _tiles[playerIndex[3]].rc.top,0,0);

	//*******����*******
	//���ʹ� �ʿ� �׸���
	//WallIdle
	for (int i = 0; i < enemyIndex[0].size(); i++)
	{
		if (i % 4 == 0) IMAGEMANAGER->render("WallIdle", getMemDC(), _tiles[enemyIndex[0][i]].rc.left, _tiles[enemyIndex[0][i]].rc.top);

	}
	//SkeletonIdle
	for (int i = 0; i < enemyIndex[1].size(); i++)
	{
		if (i % 4 == 0) IMAGEMANAGER->render("SkeletonIdle", getMemDC(), _tiles[enemyIndex[1][i]].rc.left, _tiles[enemyIndex[1][i]].rc.top);
	}
	//RedTurtleIdle
	for (int i = 0; i < enemyIndex[2].size(); i++)
	{
		if (i % 2 == 0) IMAGEMANAGER->render("RedTurtleIdle", getMemDC(), _tiles[enemyIndex[2][i]].rc.left, _tiles[enemyIndex[2][i]].rc.top);
	}
	//MushroomIdle
	for (int i = 0; i < enemyIndex[3].size(); i++)
	{
		IMAGEMANAGER->render("MushroomIdle", getMemDC(), _tiles[enemyIndex[3][i]].rc.left, _tiles[enemyIndex[3][i]].rc.top);
	}
	//MiniTurtleIdle
	for (int i = 0; i < enemyIndex[4].size(); i++)
	{
		IMAGEMANAGER->render("MiniTurtleIdle", getMemDC(), _tiles[enemyIndex[4][i]].rc.left, _tiles[enemyIndex[4][i]].rc.top);
	}
	//MiniCupaIdle
	for (int i = 0; i < enemyIndex[5].size(); i++)
	{
		if (i % 4 == 0) IMAGEMANAGER->render("MiniCupaIdle", getMemDC(), _tiles[enemyIndex[5][i]].rc.left, _tiles[enemyIndex[5][i]].rc.top);
	}
	//GgulIdle
	for (int i = 0; i < enemyIndex[6].size(); i++)
	{
		IMAGEMANAGER->render("GgulIdle", getMemDC(), _tiles[enemyIndex[6][i]].rc.left, _tiles[enemyIndex[6][i]].rc.top);
	}
	//GreenTurtleIdle
	for (int i = 0; i < enemyIndex[7].size(); i++)
	{
		if (i % 2 == 0) IMAGEMANAGER->render("GreenTurtleIdle", getMemDC(), _tiles[enemyIndex[7][i]].rc.left, _tiles[enemyIndex[7][i]].rc.top);
	}
	
	//CupaIdle
	if (isRenderBoss)
	{
		for (int i = 0; i < enemyIndex[8].size(); i++)
		{
			if (i % 16 == 0) IMAGEMANAGER->render("CupaIdle", getMemDC(), _tiles[enemyIndex[8][i]].rc.left, _tiles[enemyIndex[8][i]].rc.top);
		}
	}
	//���� ����ȭ�� �� ������ ����Ÿ�� ��Ʈ �����ֱ�
	if (INPUT->GetToggleKey(VK_F1))
	{
		for (int i = 0; i < TILEX * TILEY; i++)
		{
			
			FrameRect(getMemDC(), _tiles[i].rc, RGB(255, 255, 0));
		}

		if (_kindSelect == KIND_OBJECT)
		{
			for (int i = 0; i < SAMPLETILEX * SAMPLETILEY; i++)
			{

				FrameRect(getMemDC(), _sampleTile[i].rc, RGB(255, 255, 0));
			}
		}
	}

	
	////��Ʈ�� ��ư �̹��� ���
	Rectangle(getMemDC(), _rcEraser);
	IMAGEMANAGER->frameRender("button", getMemDC(), _rcEraser.left, _rcEraser.top, 0, 0);
	//IMAGEMANAGER->frameRender("button", getMemDC(), _rcPnE.left, _rcPnE.top, 0, 1);
	//IMAGEMANAGER->frameRender("button", getMemDC(), _rcLoad.left, _rcLoad.top, 0, 2);
	//IMAGEMANAGER->frameRender("button", getMemDC(), _rcSave.left, _rcSave.top, 0, 3);
	//IMAGEMANAGER->frameRender("button", getMemDC(), _rcBnO.left, _rcBnO.top, 0, 4);
	
	//Rectangle(getMemDC(), _rcPlayer);
	//Rectangle(getMemDC(), _rcEnemy);
	
	
}

void maptoolScene::maptoolSetup()
{
	

	//���� �ΰ���ȭ�� ��Ʈ �ʱ�ȭ
	for (int i = 0; i < TILEY; i++)
	{
		for (int j = 0; j < TILEX; j++)
		{
			_tiles[i * TILEX + j].rc = RectMake(j * TILESIZE, i * TILESIZE, TILESIZE, TILESIZE);
		}
	}

	//������ ����Ÿ�� ��Ʈ �ʱ�ȭ
	for (int i = 0; i < SAMPLETILEY; i++)
	{
		for (int j = 0; j < SAMPLETILEX; j++)
		{
			_sampleTile[i * SAMPLETILEX + j].rc = RectMake(_rcPageBnO.left + 40 + j * TILESIZE, _rcPageBnO.top + 100 + i * TILESIZE, TILESIZE, TILESIZE);
		
			_sampleTile[i * SAMPLETILEX + j].objFrameX = j;
			_sampleTile[i * SAMPLETILEX + j].objFrameY = i;
		}
	}

	
	////��Ʈ�ѹ�ư ��Ʈ ��ġ �ʱ�ȭ (�޴��� ��ư)
	//_rcSave = RectMakeCenter(_rcMenu.left + 120, _rcMenu.top + 230, 131, 32);
	//_rcLoad = RectMakeCenter(_rcMenu.left + 270, _rcMenu.top + 230, 131, 32);
	//_rcBnO = RectMakeCenter(_rcMenu.left + 120, _rcMenu.top + 330, 131, 32);
	//_rcPnE = RectMakeCenter(_rcMenu.left + 270, _rcMenu.top + 330, 131, 32);
	//_rcEraser = RectMakeCenter(_rcMenu.left + 135, _rcMenu.top + 430, 131, 32);
	_rcEraser = RectMakeCenter(WINSIZEX-300, WINSIZEY-100 , 131, 32);
	

}

//������Ʈ ����, ���찳 ����� ������ �Լ�
void maptoolScene::setMap()
{

	//������Ʈ ����
	if (_kindSelect == KIND_OBJECT)
	{
		for (int i = 0; i < SAMPLETILEX * SAMPLETILEY; i++)
		{
			if (PtInRect(&_sampleTile[i].rc, _ptMouse))
			{
				_currentTile.x = _sampleTile[i].objFrameX;
				_currentTile.y = _sampleTile[i].objFrameY;
				break;
			}
		}

		//�ΰ���ȭ�� ��ƮƲ�� �浹�߳�?
		for (int i = 0; i < TILEX * TILEY; i++)
		{
			if (PtInRect(&_tiles[i].rc, _ptMouse))
			{
				//�����ư�� ������Ʈ�� ���
				if (_kindSelect == KIND_OBJECT)
				{

					_tiles[i].objFrameX = _currentTile.x;
					_tiles[i].objFrameY = _currentTile.y;

					//���������� ������Ʈ ���� ������
					switch (pageCount)
					{
					case 0:
						_tiles[i].obj = OBJ_OBJECT1;
						break;
					case 1:
						_tiles[i].obj = OBJ_OBJECT2;
						break;
					case 2:
						_tiles[i].obj = OBJ_OBJECT3;
						break;
					case 3:
						_tiles[i].obj = OBJ_OBJECT4;
						break;
					case 4:
						_tiles[i].obj = OBJ_OBJECT5;
						break;
					}
				}
			}
		}
	}



	//���찳
	for (int i = 0; i < TILEX * TILEY; i++)
	{

		//�����ư�� ���찳��?
		if (_ctrlSelect == CTRL_ERASER)
		{

			if (PtInRect(&_tiles[i].rc, _ptMouse))
			{

				//���ʹ� ����� *******����*******
				for (int j = 0; j < enemyIndex[0].size(); j++)
				{
					if (enemyIndex[0][j] == i)
					{
						switch (j % 4)
						{
						case 0:
							enemyIndex[0].erase(enemyIndex[0].begin() + j);
							enemyIndex[0].erase(enemyIndex[0].begin() + j);
							enemyIndex[0].erase(enemyIndex[0].begin() + j);
							enemyIndex[0].erase(enemyIndex[0].begin() + j);
							break;
						case 1:
							enemyIndex[0].erase(enemyIndex[0].begin() + (j - 1));
							enemyIndex[0].erase(enemyIndex[0].begin() + (j - 1));
							enemyIndex[0].erase(enemyIndex[0].begin() + (j - 1));
							enemyIndex[0].erase(enemyIndex[0].begin() + (j - 1));
							break;
						case 2:
							enemyIndex[0].erase(enemyIndex[0].begin() + (j - 2));
							enemyIndex[0].erase(enemyIndex[0].begin() + (j - 2));
							enemyIndex[0].erase(enemyIndex[0].begin() + (j - 2));
							enemyIndex[0].erase(enemyIndex[0].begin() + (j - 2));
							break;
						case 3:
							enemyIndex[0].erase(enemyIndex[0].begin() + (j - 3));
							enemyIndex[0].erase(enemyIndex[0].begin() + (j - 3));
							enemyIndex[0].erase(enemyIndex[0].begin() + (j - 3));
							enemyIndex[0].erase(enemyIndex[0].begin() + (j - 3));
							break;
						}
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == i)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == i + 1)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == i + 20)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == i + 21)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}
						break;
					}
				}
				for (int j = 0; j < enemyIndex[1].size(); j++)
				{
					if (enemyIndex[1][j] == i)
					{

						switch (j % 4)
						{
						case 0:
							enemyIndex[1].erase(enemyIndex[1].begin() + j);
							enemyIndex[1].erase(enemyIndex[1].begin() + j);
							enemyIndex[1].erase(enemyIndex[1].begin() + j);
							enemyIndex[1].erase(enemyIndex[1].begin() + j);
							break;
						case 1:
							enemyIndex[1].erase(enemyIndex[1].begin() + (j - 1));
							enemyIndex[1].erase(enemyIndex[1].begin() + (j - 1));
							enemyIndex[1].erase(enemyIndex[1].begin() + (j - 1));
							enemyIndex[1].erase(enemyIndex[1].begin() + (j - 1));
							break;
						case 2:
							enemyIndex[1].erase(enemyIndex[1].begin() + (j - 2));
							enemyIndex[1].erase(enemyIndex[1].begin() + (j - 2));
							enemyIndex[1].erase(enemyIndex[1].begin() + (j - 2));
							enemyIndex[1].erase(enemyIndex[1].begin() + (j - 2));
							break;
						case 3:
							enemyIndex[1].erase(enemyIndex[1].begin() + (j - 3));
							enemyIndex[1].erase(enemyIndex[1].begin() + (j - 3));
							enemyIndex[1].erase(enemyIndex[1].begin() + (j - 3));
							enemyIndex[1].erase(enemyIndex[1].begin() + (j - 3));
							break;
						}
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == i)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == i + 1)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == i + 20)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == i + 21)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}
						break;

					}
				}
				for (int j = 0; j < enemyIndex[2].size(); j++)
				{
					if (enemyIndex[2][j] == i)
					{
						switch (j % 2)
						{
						case 0:
							enemyIndex[2].erase(enemyIndex[2].begin() + j);
							enemyIndex[2].erase(enemyIndex[2].begin() + j);
							break;
						case 1:
							enemyIndex[2].erase(enemyIndex[2].begin() + (j - 1));
							enemyIndex[2].erase(enemyIndex[2].begin() + (j - 1));
							break;
						}
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == i)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}

						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == i + 20)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}

						break;
					}
				}

				for (int j = 0; j < enemyIndex[3].size(); j++)
				{
					if (enemyIndex[3][j] == i)
					{
						enemyIndex[3].erase(enemyIndex[3].begin() + j);
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == i)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}

						break;
					}
				}
				for (int j = 0; j < enemyIndex[4].size(); j++)
				{
					if (enemyIndex[4][j] == i)
					{
						enemyIndex[4].erase(enemyIndex[4].begin() + j);	//���� 4�� 1�� �߸� �����... 
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == i)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}

						break;
					}
				}
				for (int j = 0; j < enemyIndex[5].size(); j++)
				{
					if (enemyIndex[5][j] == i)
					{
						switch (j % 4)
						{
						case 0:
							enemyIndex[5].erase(enemyIndex[5].begin() + j);
							enemyIndex[5].erase(enemyIndex[5].begin() + j);
							enemyIndex[5].erase(enemyIndex[5].begin() + j);
							enemyIndex[5].erase(enemyIndex[5].begin() + j);
							break;
						case 1:
							enemyIndex[5].erase(enemyIndex[5].begin() + (j - 1));
							enemyIndex[5].erase(enemyIndex[5].begin() + (j - 1));
							enemyIndex[5].erase(enemyIndex[5].begin() + (j - 1));
							enemyIndex[5].erase(enemyIndex[5].begin() + (j - 1));
							break;
						case 2:
							enemyIndex[5].erase(enemyIndex[5].begin() + (j - 2));
							enemyIndex[5].erase(enemyIndex[5].begin() + (j - 2));
							enemyIndex[5].erase(enemyIndex[5].begin() + (j - 2));
							enemyIndex[5].erase(enemyIndex[5].begin() + (j - 2));
							break;
						case 3:
							enemyIndex[5].erase(enemyIndex[5].begin() + (j - 3));
							enemyIndex[5].erase(enemyIndex[5].begin() + (j - 3));
							enemyIndex[5].erase(enemyIndex[5].begin() + (j - 3));
							enemyIndex[5].erase(enemyIndex[5].begin() + (j - 3));
							break;
						}
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == i)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == i + 1)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == i + 20)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == i + 21)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}
						break;
					}
				}
				for (int j = 0; j < enemyIndex[6].size(); j++)
				{
					if (enemyIndex[6][j] == i)
					{
						enemyIndex[6].erase(enemyIndex[6].begin() + j);
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == i)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}

						break;
					}
				}
				for (int j = 0; j < enemyIndex[7].size(); j++)
				{
					if (enemyIndex[7][j] == i)
					{
						switch (j % 2)
						{
						case 0:
							enemyIndex[7].erase(enemyIndex[7].begin() + j);
							enemyIndex[7].erase(enemyIndex[7].begin() + j);
							break;
						case 1:
							enemyIndex[7].erase(enemyIndex[7].begin() + (j - 1));
							enemyIndex[7].erase(enemyIndex[7].begin() + (j - 1));
							break;
						}
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == i)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}

						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == i + 20)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}

						break;
					}
				}

				//���� �����
				for (int j = 0; j < enemyIndex[8].size(); j++)
				{
					if (enemyIndex[8][j] == i)
					{
						isSelectEnemy[8] = false;
						isRenderBoss = false;
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == tmp)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == tmp + 1)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == tmp + 2)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == tmp + 3)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == tmp + 20)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == tmp + 21)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == tmp + 22)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == tmp + 23)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == tmp + 40)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == tmp + 41)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == tmp + 42)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == tmp + 43)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == tmp + 60)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == tmp + 61)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == tmp + 62)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == tmp + 63)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}
					}

					//������Ʈ �����
					_tiles[i].objFrameX = 0;
					_tiles[i].objFrameY = 0;
					_tiles[i].obj = OBJ_NONE;
				}

			}
		}

	}
	
}
//�÷��̾� ���� �Լ�
void maptoolScene::setPlayer()
{
	
	if (_charSelect == CHARACTER_PLAYER)
	{
		//��������
		if (isSelectPlayer[0])
		{
			for (int i = 0; i < TILEX * TILEY; i++)
			{
				if (PtInRect(&_tiles[i].rc, _ptMouse))
				{
					if (i % 20 == 19 || i >= 380)continue;
					playerIndex[0] = i;
					isRenderPlayer[0] = true;
					isRenderPlayer[1] = false;
					isRenderPlayer[2] = false;
					isRenderPlayer[3] = false;
					break;

				}

			}
		}
		//�𸶸���
		if (isSelectPlayer[1])
		{

			for (int i = 0; i < TILEX * TILEY; i++)
			{
				if (PtInRect(&_tiles[i].rc, _ptMouse))
				{
					if (i % 20 == 19 || i >= 380)continue;
					playerIndex[1] = i;
					isRenderPlayer[1] = true;
					isRenderPlayer[0] = false;
					isRenderPlayer[2] = false;
					isRenderPlayer[3] = false;
					break;

				}

			}
		}

		//������
		if (isSelectPlayer[2])
		{

			for (int i = 0; i < TILEX * TILEY; i++)
			{
				if (i % 20 == 19 || i >= 380)continue;
				if (PtInRect(&_tiles[i].rc, _ptMouse))
				{
					playerIndex[2] = i;
					isRenderPlayer[2] = true;
					isRenderPlayer[0] = false;
					isRenderPlayer[1] = false;
					isRenderPlayer[3] = false;
					break;

				}

			}
		}
		//��������
		if (isSelectPlayer[3])
		{

			for (int i = 0; i < TILEX * TILEY; i++)
			{
				if (PtInRect(&_tiles[i].rc, _ptMouse))
				{
					if (i % 20 == 19 || i >= 380)continue;
					playerIndex[3] = i;
					isRenderPlayer[3] = true;
					isRenderPlayer[0] = false;
					isRenderPlayer[2] = false;
					isRenderPlayer[1] = false;
					break;

				}

			}
		}

	}
}

//*******����*******
//���ʹ� ���� �Լ�
void maptoolScene::setEnemy()
{
	
	if (_charSelect == CHARACTER_ENEMY)
	{
		//WallIdle
		if (isSelectEnemy[0])
		{
			for (int i = 0; i < TILEX * TILEY; i++)
			{
				isCollision = false;
				if (PtInRect(&_tiles[i].rc, _ptMouse))
				{
					if (i % 20 == 19 || i >= 380)continue;

					for (int j = 0; j < usedIndex.size(); j++)
					{
						if (usedIndex[j] == i || usedIndex[j] == i + 1 || usedIndex[j] == i + 20 || usedIndex[j] == i + 21)
						{
							isCollision = true;
						}

					}


					if (!isCollision)
					{
						usedIndex.push_back(i);
						usedIndex.push_back(i + 1);
						usedIndex.push_back(i + 20);
						usedIndex.push_back(i + 21);
						enemyIndex[0].push_back(i);
						enemyIndex[0].push_back(i + 1);
						enemyIndex[0].push_back(i + 20);
						enemyIndex[0].push_back(i + 21);					
						break;
					}


				}
			}
		}
		//SkeletonIdle
		if (isSelectEnemy[1])
		{
			for (int i = 0; i < TILEX * TILEY; i++)
			{
				isCollision = false;
				if (PtInRect(&_tiles[i].rc, _ptMouse))
				{
					if (i % 20 == 19 || i >= 380)continue;
					for (int j = 0; j < usedIndex.size(); j++)
					{
						if (usedIndex[j] == i || usedIndex[j] == i + 1 || usedIndex[j] == i + 20 || usedIndex[j] == i + 21)
						{
							isCollision = true;
						}

					}
					if (!isCollision)
					{
						enemyIndex[1].push_back(i);
						enemyIndex[1].push_back(i + 1);
						enemyIndex[1].push_back(i + 20);
						enemyIndex[1].push_back(i + 21);
						usedIndex.push_back(i);
						usedIndex.push_back(i + 1);
						usedIndex.push_back(i + 20);
						usedIndex.push_back(i + 21);
						break;
					}

				}

			}
		}
		//RedTurtleIdle
		if (isSelectEnemy[2])
		{
			for (int i = 0; i < TILEX * TILEY; i++)
			{
				isCollision = false;
				if (PtInRect(&_tiles[i].rc, _ptMouse))
				{
					if (i >= 380)continue;
					for (int j = 0; j < usedIndex.size(); j++)
					{
						if (usedIndex[j] == i || usedIndex[j] == i+20)
						{
							isCollision = true;
						}

					}


					if (!isCollision)
					{
						enemyIndex[2].push_back(i);
						enemyIndex[2].push_back(i+20);
						usedIndex.push_back(i);
						usedIndex.push_back(i + 20);
						break;
					}

				}

			}
		}
		//MushroomIdle
		if (isSelectEnemy[3])
		{
			for (int i = 0; i < TILEX * TILEY; i++)
			{
				isCollision = false;
				if (PtInRect(&_tiles[i].rc, _ptMouse))
				{
					for (int j = 0; j < usedIndex.size(); j++)
					{
						if (usedIndex[j] == i)
						{
							isCollision = true;
						}

					}

					if (!isCollision)
					{
						enemyIndex[3].push_back(i);
						usedIndex.push_back(i);
						break;
					}

				}

			}
		}
		//MiniTurtleIdle
		if (isSelectEnemy[4])
		{
			for (int i = 0; i < TILEX * TILEY; i++)
			{

				if (PtInRect(&_tiles[i].rc, _ptMouse))
				{
					isCollision = false;
					for (int j = 0; j < usedIndex.size(); j++)
					{
						if (usedIndex[j] == i)
						{
							isCollision = true;
						}

					}


					if (!isCollision)
					{
						enemyIndex[4].push_back(i);
						usedIndex.push_back(i);
						break;
					}

				}

			}
		}
		//MiniCupaIdle
		if (isSelectEnemy[5])
		{
			for (int i = 0; i < TILEX * TILEY; i++)
			{
				if (PtInRect(&_tiles[i].rc, _ptMouse))
				{
					isCollision = false;
					if (i % 20 == 19 || i >= 380)continue;
					for (int j = 0; j < usedIndex.size(); j++)
					{
						if (usedIndex[j] == i || usedIndex[j] == i + 1 || usedIndex[j] == i + 20 || usedIndex[j] == i + 21)
						{
							isCollision = true;
						}

					}


					if (!isCollision)
					{
						enemyIndex[5].push_back(i);
						enemyIndex[5].push_back(i+1);
						enemyIndex[5].push_back(i+20);
						enemyIndex[5].push_back(i+21);
						usedIndex.push_back(i);
						usedIndex.push_back(i + 1);
						usedIndex.push_back(i + 20);
						usedIndex.push_back(i + 21);
						break;
					}

				}

			}
		}
		//GgulIdle
		if (isSelectEnemy[6])
		{
			for (int i = 0; i < TILEX * TILEY; i++)
			{
				isCollision = false;
				if (PtInRect(&_tiles[i].rc, _ptMouse))
				{
					for (int j = 0; j < usedIndex.size(); j++)
					{
						if (usedIndex[j] == i)
						{
							isCollision = true;
						}

					}

					if (!isCollision)
					{
						enemyIndex[6].push_back(i);
						usedIndex.push_back(i);
						break;
					}

				}

			}
		}
		//GreenTurtleIdle
		if (isSelectEnemy[7])
		{
			for (int i = 0; i < TILEX * TILEY; i++)
			{
				if (PtInRect(&_tiles[i].rc, _ptMouse))
				{
					isCollision = false;
					if (i >= 380)continue;
					for (int j = 0; j < usedIndex.size(); j++)
					{
						if (usedIndex[j] == i ||usedIndex[j]==i+20)
						{
							isCollision = true;
						}

					}


					if (!isCollision)
					{
						enemyIndex[7].push_back(i);
						enemyIndex[7].push_back(i+20);
						usedIndex.push_back(i);
						usedIndex.push_back(i + 20);
           				break;
					}

				}

			}
		}
		//CupaIdle
		if (isSelectEnemy[8])
		{
			for (int i = 0; i < TILEX * TILEY; i++)
			{
				if (PtInRect(&_tiles[i].rc, _ptMouse))
				{
					
					if (tmp != i)
					{
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == tmp)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						} 
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == tmp+1)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == tmp+2)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == tmp+3)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == tmp+20)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == tmp +21)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == tmp + 22)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == tmp + 23)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == tmp+40)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == tmp + 41)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == tmp + 42)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == tmp + 43)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == tmp + 60)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == tmp + 61)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == tmp + 62)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == tmp + 63)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}

						for (int k = 0; k < enemyIndex[8].size(); k++)
						{
							if (enemyIndex[8][k] == tmp)
							{
								enemyIndex[8].erase(enemyIndex[8].begin() + k);
								break;
							}
						}
						for (int k = 0; k < enemyIndex[8].size(); k++)
						{
							if (enemyIndex[8][k] == tmp + 1)
							{
								enemyIndex[8].erase(enemyIndex[8].begin() + k);
								break;
							}
						}
						for (int k = 0; k < enemyIndex[8].size(); k++)
						{
							if (enemyIndex[8][k] == tmp + 2)
							{
								enemyIndex[8].erase(enemyIndex[8].begin() + k);
								break;
							}
						}
						for (int k = 0; k < enemyIndex[8].size(); k++)
						{
							if (enemyIndex[8][k] == tmp + 3)
							{
								enemyIndex[8].erase(enemyIndex[8].begin() + k);
								break;
							}
						}
						for (int k = 0; k < enemyIndex[8].size(); k++)
						{
							if (enemyIndex[8][k] == tmp + 20)
							{
								enemyIndex[8].erase(enemyIndex[8].begin() + k);
								break;
							}
						}
						for (int k = 0; k < enemyIndex[8].size(); k++)
						{
							if (enemyIndex[8][k] == tmp + 21)
							{
								enemyIndex[8].erase(enemyIndex[8].begin() + k);
								break;
							}
						}
						for (int k = 0; k < enemyIndex[8].size(); k++)
						{
							if (enemyIndex[8][k] == tmp + 22)
							{
								enemyIndex[8].erase(enemyIndex[8].begin() + k);
								break;
							}
						}
						for (int k = 0; k < enemyIndex[8].size(); k++)
						{
							if (enemyIndex[8][k] == tmp + 23)
							{
								enemyIndex[8].erase(enemyIndex[8].begin() + k);
								break;
							}
						}
						for (int k = 0; k < enemyIndex[8].size(); k++)
						{
							if (enemyIndex[8][k] == tmp + 40)
							{
								enemyIndex[8].erase(enemyIndex[8].begin() + k);
								break;
							}
						}
						for (int k = 0; k < enemyIndex[8].size(); k++)
						{
							if (enemyIndex[8][k] == tmp + 41)
							{
								enemyIndex[8].erase(enemyIndex[8].begin() + k);
								break;
							}
						}
						for (int k = 0; k < enemyIndex[8].size(); k++)
						{
							if (enemyIndex[8][k] == tmp + 42)
							{
								enemyIndex[8].erase(enemyIndex[8].begin() + k);
								break;
							}
						}
						for (int k = 0; k < enemyIndex[8].size(); k++)
						{
							if (enemyIndex[8][k] == tmp + 43)
							{
								enemyIndex[8].erase(enemyIndex[8].begin() + k);
								break;
							}
						}
						for (int k = 0; k < enemyIndex[8].size(); k++)
						{
							if (enemyIndex[8][k] == tmp + 60)
							{
								enemyIndex[8].erase(enemyIndex[8].begin() + k);
								break;
							}
						}
						for (int k = 0; k < enemyIndex[8].size(); k++)
						{
							if (enemyIndex[8][k] == tmp + 61)
							{
								enemyIndex[8].erase(enemyIndex[8].begin() + k);
								break;
							}
						}
						for (int k = 0; k < enemyIndex[8].size(); k++)
						{
							if (enemyIndex[8][k] == tmp + 62)
							{
								enemyIndex[8].erase(enemyIndex[8].begin() + k);
								break;
							}
						}
						for (int k = 0; k < enemyIndex[8].size(); k++)
						{
							if (enemyIndex[8][k] == tmp + 63)
							{
								enemyIndex[8].erase(enemyIndex[8].begin() + k);
								break;
							}
						}
									
					}
					
					isCollision = false;
					if (i % 20 > 16 || i >= 340)continue;
					for (int j = 0; j < usedIndex.size(); j++)
					{
						if (usedIndex[j] == i || usedIndex[j] == i+1|| usedIndex[j] == i+2|| usedIndex[j] == i+3|| usedIndex[j] == i+20||usedIndex[j] == i+21 || usedIndex[j] == i + 22 || usedIndex[j] == i + 23
							|| usedIndex[j] == i + 40 || usedIndex[j] == i + 41 || usedIndex[j] == i + 42 || usedIndex[j] == i + 43 || usedIndex[j] == i + 60 || usedIndex[j] == i + 61 || usedIndex[j] == i + 62 || usedIndex[j] == i + 63)
						{
							isCollision = true;
						}

					}
					if (!isCollision)
					{
						tmp = i;
						enemyIndex[8].push_back(i);
						enemyIndex[8].push_back(i + 1);
						enemyIndex[8].push_back(i + 2);
						enemyIndex[8].push_back(i + 3);
						enemyIndex[8].push_back(i + 20);
						enemyIndex[8].push_back(i + 21);
						enemyIndex[8].push_back(i + 22);
						enemyIndex[8].push_back(i + 23);
						enemyIndex[8].push_back(i + 40);
						enemyIndex[8].push_back(i + 41);
						enemyIndex[8].push_back(i + 42);
						enemyIndex[8].push_back(i + 43);
						enemyIndex[8].push_back(i + 60);
						enemyIndex[8].push_back(i + 61);
						enemyIndex[8].push_back(i + 62);
						enemyIndex[8].push_back(i + 63);
						usedIndex.push_back(i);
						usedIndex.push_back(i+1);
						usedIndex.push_back(i+2);
						usedIndex.push_back(i+3);
						usedIndex.push_back(i + 20);
						usedIndex.push_back(i + 21);
						usedIndex.push_back(i + 22);
						usedIndex.push_back(i + 23);
						usedIndex.push_back(i + 40);
						usedIndex.push_back(i + 41);
						usedIndex.push_back(i + 42);
						usedIndex.push_back(i + 43);
						usedIndex.push_back(i + 60);
						usedIndex.push_back(i + 61);
						usedIndex.push_back(i + 62);
						usedIndex.push_back(i + 63);

						isRenderBoss = true;
					}
					
				
					
				}

			}
		}
	}

}

void maptoolScene::save()
{
	HANDLE file;
	DWORD write;

	file = CreateFile("save.map", GENERIC_WRITE, 0, NULL, CREATE_ALWAYS,
		FILE_ATTRIBUTE_NORMAL, NULL);
	WriteFile(file, _tiles, sizeof(tagTile) * TILEX * TILEY, &write, NULL);
	CloseHandle(file);
}

void maptoolScene::load()
{
	HANDLE file;
	DWORD read;

	file = CreateFile("save.map", GENERIC_READ, 0, NULL, OPEN_EXISTING,
		FILE_ATTRIBUTE_NORMAL, NULL);
	ReadFile(file, _tiles, sizeof(tagTile) * TILEX * TILEY, &read, NULL);
	CloseHandle(file);
}


//BACKGROUND maptoolScene::bgSelect(int frameX, int frameY)
//{
//	
//}

//OBJECT maptoolScene::objectSelect(int frameX, int frameY)
//{
//	
//}
//