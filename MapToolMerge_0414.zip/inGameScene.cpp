#include "stdafx.h"
#include "inGameScene.h"
HRESULT inGameScene::init()
{
	this->load();
	SOUNDMANAGER->addSound("1�����", "1�������.mp3", true, true);
	SOUNDMANAGER->addSound("2�����", "2�������.mp3", true, true);
	SOUNDMANAGER->addSound("3�����", "3�������.mp3", true, true);
	SOUNDMANAGER->addSound("4�����", "4�������.mp3", true, true);
	SOUNDMANAGER->addSound("5�����", "5�������.mp3", true, true);
	SOUNDMANAGER->addSound("6�����", "6�������.mp3", true, true);
	_x = 500;
	_y = 100;
	_cameraB = false;
	_cameraT = false;
	_cameraR = false;
	_cameraL = false;
	_moveR = true;
	_moveL = true;
	_moveT = true;
	_moveB = true;
	_probeT = _y - 40;
	_probeB = _y + 40;
	_probeR = _x + 40;
	_probeL = _x - 40;
	_speed = 3.0f;
	_collision = IMAGEMANAGER->findImage("collision");
	for (int i = 0; i < TILEY; i++)
	{
		for (int j = 0; j < TILEX; j++)
		{
			_tiles[i * TILEX + j].rc = RectMake(j * TILESIZE, i * TILESIZE, TILESIZE, TILESIZE);
		}
	}
	
	
	_colX = _colY = 0;
	if (isSelectBg[0])SOUNDMANAGER->play("1�����", 0.5f);
	else if (isSelectBg[1])SOUNDMANAGER->play("2�����", 0.5f);
	else if (isSelectBg[2])SOUNDMANAGER->play("3�����", 0.5f);
	else if (isSelectBg[3])SOUNDMANAGER->play("4�����", 0.5f);
	else if (isSelectBg[4])SOUNDMANAGER->play("5�����", 0.5f);
	else if (isSelectBg[5])SOUNDMANAGER->play("6�����", 0.5f);
	
	return S_OK;
}

void inGameScene::release()
{
}

void inGameScene::update()
{
	_cameraRc = RectMakeCenter(_x, _y, 945,540);
	_rc = RectMakeCenter(_x, _y,80, 80);
	
	
	if (INPUT->GetKey(VK_DOWN)&& _moveB && _probeB< 960)
	{
		if (_cameraB)
		{
			if (_colY > -280)
			{
				_colY -= _speed;
			}
			else
			{
				_y += _speed;
			}
		}
		else
		{
			_y += _speed;
		}
		_probeB += _speed;
		_probeT += _speed;
		
	}
	if (INPUT->GetKey(VK_UP) && _moveT && _probeT > 0)
	{
		if (_cameraT)
		{
			if (_colY <= 0)
			{
				_colY += _speed;
			}
			else
			{
				_y -= _speed;
			}
		}
		else
		{
			_y -= _speed;
		}
		_probeB -= _speed;
		_probeT -= _speed;

	}
	if (INPUT->GetKey(VK_RIGHT) && _moveR && _probeR < 4000)
	{
		if (_cameraR)
		{
			if (_colX > -(4000-1260))
			{
				_colX -= _speed;
			}
			else
			{
				_x += _speed;
			}
		}
		else
		{
			_x += _speed;
		}
		_probeR += _speed;
		_probeL += _speed;

	}
	if (INPUT->GetKey(VK_LEFT) && _moveL && _probeL >= 0)
	{
		if (_cameraL)
		{
			if (_colX <= 0)
			{
				_colX += _speed;
			}
			else
			{
				_x -= _speed;
			}
		}
		else
		{
			_x -= _speed;
		}
		_probeR -= _speed;
		_probeL -= _speed;

	}
	if (_cameraRc.left <= 0)
	{
		_cameraL = true;
	}
	else
	{
		_cameraL = false;
	}
	if (_cameraRc.right >= 1275)
	{
		_cameraR = true;
	}
	else
	{
		_cameraR = false;
	}
	if (_cameraRc.top <= 0)
	{
		_cameraT = true;
	}
	else
	{
		_cameraT = false;
	}
	if (_cameraRc.bottom >= 680)
	{
		_cameraB = true;
	}
	else
	{
		_cameraB = false;
	}

	for (int i = _probeB - 2; i < _probeB+2 ; i++)
	{
		

			COLORREF color = GetPixel(_collision->getMemDC(), _probeL+20, i);
			COLORREF color1 = GetPixel(_collision->getMemDC(), _probeR-20, i);
			COLORREF color2 = GetPixel(_collision->getMemDC(), _probeL + (_probeR - _probeL) / 2, i);
			int r = GetRValue(color);
			int g = GetGValue(color);
			int b = GetBValue(color);
			int r1 = GetRValue(color1);
			int g1 = GetGValue(color1);
			int b1 = GetBValue(color1);
			int r2 = GetRValue(color2);
			int g2 = GetGValue(color2);
			int b2 = GetBValue(color2);

			if (!(r == 255 && g == 0 && b == 255)|| !(r1 == 255 && g1 == 0 && b1 == 255) || !(r2 == 255 && g2 == 0 && b2 == 255))
			{
				_moveB = false;
				//break;
			}
			else
			{
				_moveB = true;
				//break;
			}
		
		
	}
	//ž
	for (int i = _probeT - 2; i < _probeT + 2; i++)
	{
		
		COLORREF color = GetPixel(_collision->getMemDC(), _probeL+20, i);
		COLORREF color1 = GetPixel(_collision->getMemDC(), _probeR-20, i);
		COLORREF color2 = GetPixel(_collision->getMemDC(), _probeL + (_probeR - _probeL) / 2, i);
			int r = GetRValue(color);
			int g = GetGValue(color);
			int b = GetBValue(color);
			int r1 = GetRValue(color1);
			int g1 = GetGValue(color1);
			int b1 = GetBValue(color1);
			int r2 = GetRValue(color2);
			int g2 = GetGValue(color2);
			int b2 = GetBValue(color2);
			
			if (!(r == 255 && g == 0 && b == 255) || !(r1 == 255 && g1 == 0 && b1 == 255) || !(r2 == 255 && g2 == 0 && b2 == 255))
			{
				_moveT = false;
				//break;
			}
			else
			{
				_moveT = true;
				//break;
			}
		
		
	}
	//����
	for (int i = _probeL - 2; i < _probeL +2; i++)
	{		//���� ���� ģ��								���� ģ���� �߽�
		
			COLORREF color = GetPixel(_collision->getMemDC(), i, _probeT + (_probeB - _probeT)/2);
			COLORREF color1 = GetPixel(_collision->getMemDC(), i, _probeB-20);
			COLORREF color2 = GetPixel(_collision->getMemDC(), i, _probeT+20);
			int r = GetRValue(color);
			int g = GetGValue(color);
			int b = GetBValue(color);
			int r1 = GetRValue(color1);
			int g1 = GetGValue(color1);
			int b1 = GetBValue(color1);
			int r2 = GetRValue(color2);
			int g2 = GetGValue(color2);
			int b2 = GetBValue(color2);
			
			if (!(r == 255 && g == 0 && b == 255) || !(r1 == 255 && g1 == 0 && b1 == 255) || !(r2 == 255 && g2 == 0 && b2 == 255))
			{
				_moveL = false;
				//break;
			}
			else
			{
				_moveL = true;
				//break;
			}
		
		
	}
	//������
	for (int i = _probeR - 2; i < _probeR+2; i++)
	{
		
		COLORREF color = GetPixel(_collision->getMemDC(), i, _probeT + (_probeB - _probeT)/2);
		COLORREF color1 = GetPixel(_collision->getMemDC(), i, _probeB-20);
		COLORREF color2 = GetPixel(_collision->getMemDC(), i, _probeT+20);
		int r = GetRValue(color);
		int g = GetGValue(color);
		int b = GetBValue(color);
		int r1 = GetRValue(color1);
		int g1 = GetGValue(color1);
		int b1 = GetBValue(color1);
		int r2 = GetRValue(color2);
		int g2 = GetGValue(color2);
		int b2 = GetBValue(color2);
		if (!(r == 255 && g == 0 && b == 255) || !(r1 == 255 && g1 == 0 && b1 == 255) || !(r2 == 255 && g2 == 0 && b2 == 255))
		{
			_moveR = false;
			//break;
		}
		else
		{
			_moveR = true;
			//break;
		}
	}
}

void inGameScene::render()
{
	RECT rc;
	for (int i = 0; i < TILEX * TILEY; i++)
	{
		//������Ʈ �������� �ٸ� �̹��� Ÿ�� ��Ÿ����
		if (_tiles[i].obj == OBJ_OBJECT1)
		{
			IMAGEMANAGER->frameRender("basic", _collision->getMemDC(), _tiles[i].rc.left, _tiles[i].rc.top,
				_tiles[i].objFrameX, _tiles[i].objFrameY);
		}
		if (_tiles[i].obj == OBJ_OBJECT2)
		{
			IMAGEMANAGER->frameRender("snow", _collision->getMemDC(), _tiles[i].rc.left , _tiles[i].rc.top,
				_tiles[i].objFrameX, _tiles[i].objFrameY);
		}
		if (_tiles[i].obj == OBJ_OBJECT3)
		{
			IMAGEMANAGER->frameRender("sky", _collision->getMemDC(), _tiles[i].rc.left, _tiles[i].rc.top ,
				_tiles[i].objFrameX, _tiles[i].objFrameY);
		}
		if (_tiles[i].obj == OBJ_OBJECT4)
		{
			IMAGEMANAGER->frameRender("object", _collision->getMemDC(), _tiles[i].rc.left, _tiles[i].rc.top ,
				_tiles[i].objFrameX, _tiles[i].objFrameY);
		}
		if (_tiles[i].obj == OBJ_OBJECT5)
		{
			IMAGEMANAGER->frameRender("basement", _collision->getMemDC(), _tiles[i].rc.left , _tiles[i].rc.top ,
				_tiles[i].objFrameX, _tiles[i].objFrameY);
		}
	}
	for (int i = 0; i < 6; i++)
	{
		if (isSelectBg[i])
			switch (i)
			{
			case 0:
				IMAGEMANAGER->render("cloud", getMemDC(), _colX/2,_colY/2);
				break;
			case 1:
				IMAGEMANAGER->render("mountain", getMemDC(), _colX/2, _colY/2);
				break;
			case 2:
				IMAGEMANAGER->render("forest", getMemDC(), _colX/2, _colY/2);
				break;
			case 3:
				IMAGEMANAGER->render("sea", getMemDC(), _colX/2, _colY/2);
				break;
			case 4:
				IMAGEMANAGER->render("jungle", getMemDC(), _colX/2, _colY/2);
				break;
			case 5:
				IMAGEMANAGER->render("sky_bg", getMemDC(), _colX/2, _colY/2);
				break;
			}
	}
	IMAGEMANAGER->render("collision", getMemDC(),_colX,_colY);
	if (INPUT->GetToggleKey('A'))
	{
		//�浹�� �����簢��
		RECT rc1 = RectMakeCenter(_x, _probeB, 10, 10);
		RECT rc2 = RectMakeCenter(_x, _probeT, 10, 10);
		RECT rc3 = RectMakeCenter(_probeL, _y, 10, 10);
		RECT rc4 = RectMakeCenter(_probeR, _y, 10, 10);
		Rectangle(getMemDC(), rc1);
		Rectangle(getMemDC(), rc2);
		Rectangle(getMemDC(), rc3);
		Rectangle(getMemDC(), rc4);
		char str[100];
		sprintf(str, "%d %d %d %d %f %f %f %f", _probeT, _probeB, _probeL, _probeR, _colX, _colY, _x, _y);
		TextOut(getMemDC(), 100, 40, str, strlen(str));
	}
	if (INPUT->GetToggleKey('S'))
	{
		Rectangle(getMemDC(), _cameraRc);
		char str[100];
		sprintf(str, "%d %d %d %d", _cameraRc.top, _cameraRc.bottom, _cameraRc.left, _cameraRc.right);
		TextOut(getMemDC(), 100, 80, str, strlen(str));
	}
	//Rectangle(getMemDC(), _cameraRc);
	//Rectangle(getMemDC(), _PlayerRc);
	Rectangle(getMemDC(), _rc);
	if (INPUT->GetToggleKey(VK_F1))
	{
		for (int i = 0; i < TILEX * TILEY; i++)
		{
			//Rectangle(getMemDC(), _tiles[i].rc);
			FrameRect(getMemDC(), _tiles[i].rc, RGB(255, 255, 0));
		}
		
	}
	CHAR str[128];
	sprintf(str, "%d", _rc.top);
	TextOut(getMemDC(), 100, 100, str, strlen(str));
}
void inGameScene::save()
{
	HANDLE file;
	DWORD write;

	file = CreateFile("save.map", GENERIC_WRITE, 0, NULL, CREATE_ALWAYS,
		FILE_ATTRIBUTE_NORMAL, NULL);
	WriteFile(file, _tiles, sizeof(tagTile) * TILEX * TILEY, &write, NULL);
	WriteFile(file, isSelectBg, sizeof(isSelectBg)*6, &write, NULL);
	CloseHandle(file);
}

void inGameScene::load()
{
	HANDLE file;
	DWORD read;

	file = CreateFile("save.map", GENERIC_READ, 0, NULL, OPEN_EXISTING,
		FILE_ATTRIBUTE_NORMAL, NULL);
	ReadFile(file, _tiles, sizeof(tagTile) * TILEX * TILEY, &read, NULL);
	ReadFile(file, isSelectBg, sizeof(isSelectBg)*6, &read, NULL);
	CloseHandle(file);
}

