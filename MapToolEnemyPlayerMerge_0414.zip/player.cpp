#include "stdafx.h"
#include "player.h"
#include "enemyManager.h"

HRESULT player::init()
{
	//������ �ڵ忡�� �Ѿ��
	


	winX = 0;
	winY = 200;

	_player.champ = nope;
	_player.frameX = 0;
	_player.frameY = 0;
	_player.cameraRc = RectMakeCenter(_player.playerX, _player.playerY, 600, 600);
	_player.stat = normal;
	_gr = 25.0f;

	jump = false;
	reJump = false;
	jjin = true;
	_setting = false;
	_down = false;


	return S_OK;
}

void player::release()
{
}

void player::update()
{
	if (_player.stat != die)//��� �ִ��� 
	{
		if (_setting)
		{
			//�¿� ������
			for (int i = _player.playerX + 30; i < _player.playerX + 40; i++)
			{
				COLORREF color = GetPixel(IMAGEMANAGER->findImage("�Ƹ�ī��")->getMemDC(), i, _player.playerY);
				int r = GetRValue(color);
				int g = GetGValue(color);
				int b = GetBValue(color);


				if ((r == 255 && g == 0 && b == 255))
				{
					if (INPUT->GetKey(VK_RIGHT))
					{
						_player.playerX += 3;
						_player.frameY = 0;
						if (!jump)
						{
							_player.stat = walk;
						}
					}
					break;
				}
			}



			for (int i = _player.playerX - 40; i < _player.playerX - 30; i++)
			{
				COLORREF color = GetPixel(IMAGEMANAGER->findImage("�Ƹ�ī��")->getMemDC(), i, _player.playerY);
				int r = GetRValue(color);
				int g = GetGValue(color);
				int b = GetBValue(color);


				if ((r == 255 && g == 0 && b == 255))
				{
					if (INPUT->GetKey(VK_LEFT))
					{
						_player.playerX -= 3;
						_player.frameY = 1;
						if (!jump)
						{
							_player.stat = walk;
						}
					}
					break;
				}
			}

			if (INPUT->GetKeyUp(VK_RIGHT) || INPUT->GetKeyUp(VK_LEFT))
			{
				_player.stat = normal;
			}
			//�¿� ������ 

			//����
			if (INPUT->GetKeyDown(VK_SPACE) && jump == false && reJump == false)
			{
				jump = true;
				jjin = false;
				_player.stat = jumping;
				if (_player.frameY % 2 == 0)
				{
					_player.frameX = 0;
				}
				else
				{
					_player.frameX = 1;
				}
				_gr = 0;
			}

			if (jump)
			{
				_player.playerY = _player.playerY - sinf(3.141592 / 180 * 90) * 25;
				_player.stat = jumping;
			}

			//����

			//������
			if (sinf(3.141592 / 180 * 90) * 25 < _gr && jump)
			{
				jjin = true;


			}

			if (jjin)
			{

				_player.stat = jumping;
				if (_player.frameY % 2 == 0)
				{
					_player.frameX = 1;
				}
				else
				{
					_player.frameX = 0;
				}

				for (int i = 0; i < _em->getEnemy().size(); i++)
				{
					if (IntersectRect(&RC, &_player.playerRc, &_em->getEnemy()[i]->getRect((int)_em->getEnemy()[i]->getType())) && (jjin||reJump||_down))
					{
						jump = false;
						jjin = false;
						reJump = true;
						_em->getEnemy()[i]->hit();
						_gr = 0;
						_player.frameX = 0;


					}
					else if (IntersectRect(&RC, &_player.playerRc, &_em->getEnemy()[i]->getRect((int)_em->getEnemy()[i]->getType())) && reJump)
					{
						reJump = false;
						_em->getEnemy()[i]->hit();
						_gr = 0;
						_player.frameX = 0;
						reJump = true;
					}
				}
			}
			//������


			//�ȼ��浹
			for (int i = _player.playerY + 35; i < _player.playerY + 40; i++)
			{
				COLORREF color = GetPixel(IMAGEMANAGER->findImage("�Ƹ�ī��")->getMemDC(), _player.playerX, i);
				int r = GetRValue(color);
				int g = GetGValue(color);
				int b = GetBValue(color);


				if (!(r == 255 && g == 0 && b == 255) && jjin)
				{
					jump = false;
					jjin = false;
					_gr = 0;
					_player.frameX = 0;
					_player.playerY = i - 40;
					_player.stat = normal;
					break;
				}
				if (!(r == 255 && g == 0 && b == 255) && reJump)
				{
					reJump = false;
					jjin = false;
					_gr = 0;
					_player.frameX = 0;
					_player.playerY = i - 40;
					_player.stat = normal;
					break;
				}
				//else if (!(r == 255 && g == 0 && b == 255))
				//{
				//	_gr = 0;
				//	jump = false;
				//	jjin = false;
				//	_player.frameX = 0;
				//	_player.playerY = i - 40;
				//	_player.stat = normal;
				//	break;
				//}
				if ((r == 255 && g == 0 && b == 255))
				{
					_gr += 1;
					_player.playerY = _player.playerY + _gr;
					_down = true;
					break;
				}
				else
				{
					_down = false;
				}


			}
			//�ȼ��浹

			//�ҹ�Ⱑ ���մ�ģ���� ������ 
			//for (int i = _player.playerY - 40; i < _player.playerY - 30; i++)
			//{
			//	COLORREF color = GetPixel(IMAGEMANAGER->findImage("�Ƹ�ī��")->getMemDC(), _player.playerX, i);
			//	int r = GetRValue(color);
			//	int g = GetGValue(color);
			//	int b = GetBValue(color);
			//
			//
			//	if (!(r == 255 && g == 0 && b == 255)&&!jjin)
			//	{
			//		jump = false;
			//		_player.playerY = i + 40;
			//		break;
			//	}
			//
			//}
			//�ҹ�Ⱑ ���մ� ģ�� ������

			//�տ��� ��������

			//_vEnemy[i]->getRect(int)_vEnemy[i]->getType();
			for (int i = 0; i < _em->getEnemy().size(); i++)
			{
				if (IntersectRect(&RC, &_player.playerRc, &_em->getEnemy()[i]->getRect((int)_em->getEnemy()[i]->getType())) && !jjin)
				{
					_player.stat = die;
				}
			}
			//�տ��� �� ������


			//�ݵ�����
			if (reJump)
			{
				_player.playerY = _player.playerY - sinf(3.141592 / 180 * 90) * 15;
				_player.stat = jumping;
				if (_player.frameY % 2 == 0)
				{
					_player.frameX = 0;
				}
				else
				{
					_player.frameX = 1;
				}
			}
			//�ݵ�����






			_player.playerRc = RectMakeCenter(_player.playerX, _player.playerY, 80, 80);
			_player.cameraRc = RectMakeCenter(_player.playerX, _player.playerY, 400, 400);

			//if (_player.cameraRc.left <= 0)
			//{
			//	if (winX > 0)
			//	{
			//		winX -= 3;
			//	}
			//}
			//if (_player.cameraRc.right >= 800)
			//{
			//	if (winX < 3200)
			//	{
			//		winX += 3;
			//	}
			//}
			//if (_player.cameraRc.top <= 0)
			//{
			//	if (winY >0)
			//	{
			//		winY -= 3;
			//	}
			//}
			//if (_player.cameraRc.bottom >= 800)
			//{
			//	if (winY < 200)
			//	{
			//		winY += 3;
			//	}
			//}


			//if (_idle != nullptr)
			//{
			//	_idle->setX(_x);
			//	_idle->setY(_y);
			//}

				//��������
			_collisionRect[(int)mario] = RectMake(_x + 10, _y, IMAGEMANAGER->findImage("������")->getWidth() - 26, IMAGEMANAGER->findImage("������")->getHeight() / 2);
			//������
			_collisionRect[(int)realmario] = RectMake(_x + 19, _y + 10, IMAGEMANAGER->findImage("������")->getWidth() - 40, IMAGEMANAGER->findImage("������")->getHeight() / 2 - 10);
			//��������
			_collisionRect[(int)toad] = RectMake(_x + 19, _y + 10, IMAGEMANAGER->findImage("������")->getWidth() - 36, IMAGEMANAGER->findImage("������")->getHeight() / 2 - 10);
			//������
			_collisionRect[(int)luigi] = RectMake(_x + 19, _y + 5, IMAGEMANAGER->findImage("������")->getWidth() - 40, IMAGEMANAGER->findImage("������")->getHeight() / 2 - 5);
		}
	}
}

void player::render()
{
	IMAGEMANAGER->findImage("�Ƹ�ī��")->render(getMemDC(), 0, 0);
	
	if(_setting)
		FrameRect(getMemDC(), _collisionRect[(int)_player.champ], RGB(255, 0, 0));
	
	if (_setting)
	{
		switch (_player.stat)
		{
		case normal:
			IMAGEMANAGER->findImage("������")->frameRender(getMemDC(), _player.playerRc.left, _player.playerRc.top, _player.frameX, _player.frameY);
			break;
		case jumping:
			IMAGEMANAGER->findImage("����������")->frameRender(getMemDC(), _player.playerRc.left, _player.playerRc.top, _player.frameX, _player.frameY);
			break;
		case walk:
			IMAGEMANAGER->findImage("�������ȱ�")->frameRender(getMemDC(), _player.playerRc.left, _player.playerRc.top, _player.frameX, _player.frameY);
			break;
		case die:
			break;
		}
	}


	//if (_idle != nullptr)
	//{
	//	//_idle->render(IMAGEMANAGER->findImage("collisionMap")->getMemDC(), _idle->getX(), _idle->getY());
	//	_idle->frameRender(getMemDC(), _idle->getX(), _idle->getY(), 0, 0);
	//	FrameRect(getMemDC(), _collisionRect[(int)_type], RGB(255, 0, 0));
	//}
	////TextOut(getMemDC(), 500, 500, str, strlen(str));	
	
}

void player::playerSetting()
{
	sprintf(str, "%d", (int)_player.champ);
	SetWindowText(_hWnd, str);
	switch (_player.champ)
	{
	case realmario:
		IMAGEMANAGER->addFrameImage("�������ȱ�", "RealMarioWalk.bmp", 160, 160, 2, 2);
		IMAGEMANAGER->addFrameImage("������", "RealMarioidle.bmp", 80, 160, 1, 2);
		IMAGEMANAGER->addFrameImage("����������", "RealMarioJump.bmp", 160, 160, 2, 2);
		break;
	case mario:
		IMAGEMANAGER->addFrameImage("�������ȱ�", "MarioWalk.bmp", 160, 160, 2, 2);
		IMAGEMANAGER->addFrameImage("������", "Marioidle.bmp", 80, 160, 1, 2);
		IMAGEMANAGER->addFrameImage("����������", "MarioJump.bmp", 160, 160, 2, 2);
		break;
	case luigi:
		IMAGEMANAGER->addFrameImage("�������ȱ�", "LuigiWalk.bmp", 160, 160, 2, 2);
		IMAGEMANAGER->addFrameImage("������", "Luigiidle.bmp", 80, 160, 1, 2);
		IMAGEMANAGER->addFrameImage("����������", "LuigiJump.bmp", 160, 160, 2, 2);
		break;
	case toad:
		IMAGEMANAGER->addFrameImage("�������ȱ�", "ToadWalk.bmp", 160, 160, 2, 2);
		IMAGEMANAGER->addFrameImage("������", "Toadidle.bmp", 80, 160, 1, 2);
		IMAGEMANAGER->addFrameImage("����������", "ToadJump.bmp", 160, 160, 2, 2);
		break;
	}
	_setting = true;
}

void player::hit()
{
}
