#include "stdafx.h"
#include "saveLoad.h"

HRESULT saveLoad::init()
{

	//���� �ΰ���ȭ�� ��Ʈ �ʱ�ȭ
	for (int i = 0; i < TILEY; i++)
	{
		for (int j = 0; j < TILEX; j++)
		{
			_tiles[i * TILEX + j].rc = RectMake(j * TILESIZE, i * TILESIZE, TILESIZE, TILESIZE);
		}
	}

	_testRect = RectMake(0, 0, TILESIZE, TILESIZE);
	_gravity = 5.0;
	_proveY = _testRect.bottom;
	_load = false;

	//���ʹ� Ÿ�� ���ʿ� ���°ŷ�
	for (int i = 0; i < ENEMYSIZE; i++)
	{
		_enemy[i].setType(None);
	}

	//��� �ʱ�ȭ
	_bg = IMAGEMANAGER->addImage("�׽�Ʈ���", "testBg.bmp", 800, 800);

	return S_OK;
}

void saveLoad::release()
{
}

void saveLoad::update()
{
	if (!_load)
	{
		_load = true;
		this->load();
	}

	if (INPUT->GetKey(VK_UP))
	{
		_testRect.top -= 5.0f;
		_testRect.bottom -= 5.0f;
	}
	if (INPUT->GetKey(VK_DOWN))
	{
		_testRect.top += 5.0f;
		_testRect.bottom += 5.0f;
	}
	if (INPUT->GetKey(VK_LEFT))
	{
		_testRect.left -= 5.0f;
		_testRect.right -= 5.0f;
	}
	if (INPUT->GetKey(VK_RIGHT))
	{
		_testRect.left += 5.0f;
		_testRect.right += 5.0f;
	}

	RECT _rc;

	for (int i = _proveY - 20; i < _proveY; i++)
	{
		COLORREF color = GetPixel(IMAGEMANAGER->findImage("tilemap")->getMemDC(), _testRect.left + (_testRect.right - _testRect.left) / 2, i);

		int r = GetRValue(color);
		int g = GetGValue(color);
		int b = GetBValue(color);

		if (!(r == 255 && g == 0 && b == 255))
		{
			_testRect.top = i - 20;
			_testRect.bottom = i;
		}
		else
		{
			_testRect.top += 5.0f;
			_testRect.bottom += 5.0f;
		}
	}

	//���ʹ� ������Ʈ
	for (int i = 0; i < ENEMYSIZE; i++)
	{
		_enemy[i].update();
	}
}

void saveLoad::render()
{
	//�ΰ���ȭ�� ������ �׸���
	for (int i = 0; i < TILEX * TILEY; i++)
	{
		IMAGEMANAGER->frameRender("tilemap", getMemDC(), _tiles[i].rc.left, _tiles[i].rc.top,
			_tiles[i].terrainFrameX, _tiles[i].terrainFrameY);
	}

	//�ΰ���ȭ�� ������Ʈ�� �׸���
	for (int i = 0; i < TILEX * TILEY; i++)
	{
		if (_tiles[i].obj == OBJ_NONE) continue;

		IMAGEMANAGER->frameRender("tilemap", getMemDC(), _tiles[i].rc.left, _tiles[i].rc.top,
			_tiles[i].objFrameX, _tiles[i].objFrameY);
	}

	Rectangle(getMemDC(), _testRect);

	//���ʹ� ������ ���� �ʿ� ����
	for (int i = 0; i < ENEMYSIZE; i++)
	{
		if (_enemy[i].getType() != None)
		{
			_enemy[i].render();
		}
	}

	//��� ����
	_bg->render(getMemDC(), 0, 0);
}

TERRAIN saveLoad::terrainSelect(int frameX, int frameY)
{
	//�ø�Ʈ
	if (frameX == 1 && frameY == 0)
	{
		return TR_CEMENT;
	}
	//��
	if (frameX == 2 && frameY == 0)
	{
		return TR_GROUND;
	}
	//�ܵ�
	if (frameX == 3 && frameY == 0)
	{
		return TR_GRASS;
	}
	//��
	if (frameX == 4 && frameY == 0)
	{
		return TR_WATER;
	}

	//��Ÿ
	return TR_GROUND;
}

OBJECT saveLoad::objectSelect(int frameX, int frameY)
{
	return OBJ_BLOCKS;
}

void saveLoad::load()
{
	HANDLE file;
	DWORD read;

	file = CreateFile("save.map", GENERIC_READ, 0, NULL, OPEN_EXISTING,
		FILE_ATTRIBUTE_NORMAL, NULL);
	ReadFile(file, _tiles, sizeof(tagTile) * TILEX * TILEY, &read, NULL);
	CloseHandle(file);
	file = CreateFile("saveEnemy.map", GENERIC_READ, 0, NULL, OPEN_EXISTING,
		FILE_ATTRIBUTE_NORMAL, NULL);
	ReadFile(file, _enemy, sizeof(enemy) * ENEMYSIZE, &read, NULL);
	CloseHandle(file);
	for (int i = 0; i < 10; i++)
	{
		_enemy[i].setImage();
	}
}

