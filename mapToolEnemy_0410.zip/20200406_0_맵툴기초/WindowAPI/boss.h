#pragma once
#include "enemy.h"
class boss :
	public enemy
{
};

