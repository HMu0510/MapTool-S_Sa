#pragma once

enum ENEMYTYPE
{
	None,
	Ggul,
	GreenTurtle,
	MiniCupa,
	MiniTurtle,
	Mushroom,
	RedTurtle,
	Skeleton,
	Wall
};

enum PLAYERTYPE
{
	Mario,
	MushGirl
};

typedef struct playerData
{
	float x, y;
	PLAYERTYPE type;
}PLAYERDATA;

typedef struct enemyData
{
	float x, y;
	ENEMYTYPE type;
}ENEMYDATA;