#include "stdafx.h"
#include "inGameScene.h"
HRESULT inGameScene::init()
{
	this->load();
	SOUNDMANAGER->addSound("1�����", "1�������.mp3", true, true);
	SOUNDMANAGER->addSound("2�����", "2�������.mp3", true, true);
	SOUNDMANAGER->addSound("3�����", "3�������.mp3", true, true);
	SOUNDMANAGER->addSound("4�����", "4�������.mp3", true, true);
	SOUNDMANAGER->addSound("5�����", "5�������.mp3", true, true);
	SOUNDMANAGER->addSound("6�����", "6�������.mp3", true, true);
	
	_collision = IMAGEMANAGER->findImage("collision");
	for (int i = 0; i < TILEY; i++)
	{
		for (int j = 0; j < TILEX; j++)
		{
			_tiles[i * TILEX + j].rc = RectMake(j * TILESIZE, i * TILESIZE, TILESIZE, TILESIZE);
		}
	}
	
	_rc = RectMakeCenter(100, 100, 100, 100);
	
	if (isSelectBg[0])SOUNDMANAGER->play("1�����", 0.5f);
	else if (isSelectBg[1])SOUNDMANAGER->play("2�����", 0.5f);
	else if (isSelectBg[2])SOUNDMANAGER->play("3�����", 0.5f);
	else if (isSelectBg[3])SOUNDMANAGER->play("4�����", 0.5f);
	else if (isSelectBg[4])SOUNDMANAGER->play("5�����", 0.5f);
	else if (isSelectBg[5])SOUNDMANAGER->play("6�����", 0.5f);
	
	return S_OK;
}

void inGameScene::release()
{
}

void inGameScene::update()
{
	if (INPUT->GetKey(VK_DOWN))
	{
		_rc.bottom += 5.0f;
		_rc.top += 5.0f;
	}
	if (INPUT->GetKey(VK_UP))
	{
		_rc.bottom -= 5.0f;
		_rc.top -= 5.0f;
	}
	if (INPUT->GetKey(VK_RIGHT))
	{
		_rc.right += 5.0f;
		_rc.left += 5.0f;
	}
	if (INPUT->GetKey(VK_LEFT))
	{
		_rc.right -= 5.0f;
		_rc.left -= 5.0f;
	}
	_probeY = _rc.bottom;
	for (int i = _probeY - 5; i < _probeY + 5; i++)
	{
		COLORREF color = GetPixel(_collision->getMemDC(), _rc.left + (_rc.right - _rc.left) / 2, i);
		int r = GetRValue(color);
		int g = GetGValue(color);
		int b = GetBValue(color);
		if (!(r == 255 && g == 0 && b == 255))
		{
			_rc.top = i - 100;
			_rc.bottom = i;
			break;
		}
	}
}

void inGameScene::render()
{
	RECT rc;
	for (int i = 0; i < TILEX * TILEY; i++)
	{
		//������Ʈ �������� �ٸ� �̹��� Ÿ�� ��Ÿ����
		if (_tiles[i].obj == OBJ_OBJECT1)
		{
			IMAGEMANAGER->frameRender("basic", _collision->getMemDC(), _tiles[i].rc.left, _tiles[i].rc.top,
				_tiles[i].objFrameX, _tiles[i].objFrameY);
		}
		if (_tiles[i].obj == OBJ_OBJECT2)
		{
			IMAGEMANAGER->frameRender("snow", _collision->getMemDC(), _tiles[i].rc.left, _tiles[i].rc.top,
				_tiles[i].objFrameX, _tiles[i].objFrameY);
		}
		if (_tiles[i].obj == OBJ_OBJECT3)
		{
			IMAGEMANAGER->frameRender("sky", _collision->getMemDC(), _tiles[i].rc.left, _tiles[i].rc.top,
				_tiles[i].objFrameX, _tiles[i].objFrameY);
		}
		if (_tiles[i].obj == OBJ_OBJECT4)
		{
			IMAGEMANAGER->frameRender("object", _collision->getMemDC(), _tiles[i].rc.left, _tiles[i].rc.top,
				_tiles[i].objFrameX, _tiles[i].objFrameY);
		}
		if (_tiles[i].obj == OBJ_OBJECT5)
		{
			IMAGEMANAGER->frameRender("basement", _collision->getMemDC(), _tiles[i].rc.left, _tiles[i].rc.top,
				_tiles[i].objFrameX, _tiles[i].objFrameY);
		}
	}
	for (int i = 0; i < 6; i++)
	{
		if (isSelectBg[i])
			switch (i)
			{
			case 0:
				IMAGEMANAGER->render("cloud", getMemDC());
				break;
			case 1:
				IMAGEMANAGER->render("mountain", getMemDC());
				break;
			case 2:
				IMAGEMANAGER->render("forest", getMemDC());
				break;
			case 3:
				IMAGEMANAGER->render("sea", getMemDC());
				break;
			case 4:
				IMAGEMANAGER->render("jungle", getMemDC());
				break;
			case 5:
				IMAGEMANAGER->render("sky_bg", getMemDC());
				break;
			}
	}
	IMAGEMANAGER->render("collision", getMemDC(), 0, 0);
	Rectangle(getMemDC(), _rc);

	CHAR str[128];
	sprintf(str, "%d", _rc.top);
	TextOut(getMemDC(), 100, 100, str, strlen(str));
}
void inGameScene::save()
{
	HANDLE file;
	DWORD write;

	file = CreateFile("save.map", GENERIC_WRITE, 0, NULL, CREATE_ALWAYS,
		FILE_ATTRIBUTE_NORMAL, NULL);
	WriteFile(file, _tiles, sizeof(tagTile) * TILEX * TILEY, &write, NULL);
	WriteFile(file, isSelectBg, sizeof(isSelectBg)*6, &write, NULL);
	CloseHandle(file);
}

void inGameScene::load()
{
	HANDLE file;
	DWORD read;

	file = CreateFile("save.map", GENERIC_READ, 0, NULL, OPEN_EXISTING,
		FILE_ATTRIBUTE_NORMAL, NULL);
	ReadFile(file, _tiles, sizeof(tagTile) * TILEX * TILEY, &read, NULL);
	ReadFile(file, isSelectBg, sizeof(isSelectBg)*6, &read, NULL);
	CloseHandle(file);
}

