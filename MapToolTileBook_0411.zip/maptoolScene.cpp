#include "stdafx.h"
#include "maptoolScene.h"

HRESULT maptoolScene::init()
{

	
	//������ ī��Ʈ ���� �ʱ�ȭ
	pageCount = 0;

	//BnOå�ڸ� ��� ����â���� �����ϱ�
	_kindSelect = KIND_BG;

	//PnEå�ڸ� �÷��̾� ����â���� �����ϱ�
	_charSelect = CHARACTER_PLAYER;

	//��� ���� �̹��� 
	IMAGEMANAGER->addImage("sampleCloud", "��������.bmp", 100, 200);
	IMAGEMANAGER->addImage("sampleMountain", "�����.bmp", 100, 200);
	IMAGEMANAGER->addImage("sampleForest", "������.bmp", 100, 200);
	IMAGEMANAGER->addImage("sampleSea", "���ػ���.bmp", 100, 200);
	IMAGEMANAGER->addImage("sampleJungle", "���ۻ���.bmp", 100, 200);
	IMAGEMANAGER->addImage("sampleSky", "�ϴû���.bmp", 100, 200);


	//��� �̹��� 
	IMAGEMANAGER->addImage("cloud", "����.bmp", 4000, 1000);
	IMAGEMANAGER->addImage("mountain", "��.bmp", 4000, 1000);
	IMAGEMANAGER->addImage("forest", "��.bmp", 4000, 1000);
	IMAGEMANAGER->addImage("sea", "����.bmp", 4000, 1000);
	IMAGEMANAGER->addImage("jungle", "����.bmp", 4000, 1000);
	IMAGEMANAGER->addImage("sky_bg", "�ϴù��.bmp", 4000, 1000);

	//ó�� ����̹����� �ϴù������ �ʱ�ȭ
	for (int i = 0; i < 5; i++)
	{
		isSelectBg[i] = false;
	}

	//������Ʈ Ÿ�� �̹��� 
	IMAGEMANAGER->addFrameImage("basic", "�⺻��.bmp", 320, 360, SAMPLETILEX, SAMPLETILEY);		//�⺻��
	IMAGEMANAGER->addFrameImage("snow", "����.bmp", 320, 360, SAMPLETILEX, SAMPLETILEY);			//����
	IMAGEMANAGER->addFrameImage("sky", "�ϴ�.bmp", 320, 360, SAMPLETILEX, SAMPLETILEY);		    //�ϴ�
	IMAGEMANAGER->addFrameImage("object", "��ü.bmp", 320, 360, SAMPLETILEX, SAMPLETILEY);		//��ü
	IMAGEMANAGER->addFrameImage("basement", "���϶�.bmp", 320, 360, SAMPLETILEX, SAMPLETILEY);	//����

	//�÷��̾� �̹���
	IMAGEMANAGER->addImage("mario", "MarioIdle.bmp", 80, 80); //��������
	IMAGEMANAGER->addFrameImage("realMario", "RealMarioIdle.bmp", 80, 160, 1, 2); //�� ������
	IMAGEMANAGER->addFrameImage("luigi", "LuigiIdle.bmp", 80, 160, 1, 2); // ������
	IMAGEMANAGER->addFrameImage("toad", "ToadIdle.bmp", 80, 160, 1, 2); //��������

	for (int i = 0; i < 4; i++)
	{
		isSelectPlayer[i] = false;
		isRenderPlayer[i] = false;
		playerIndex[i] = 0;
	}

	//���ʹ� �̹���
	IMAGEMANAGER->addImage("wall", "WallMove1.bmp", 60, 80);
	IMAGEMANAGER->addImage("skeleton", "SkeletonMove1.bmp", 48, 64);
	IMAGEMANAGER->addImage("redTurtle", "RedTurtle1.bmp", 40, 80);
	IMAGEMANAGER->addImage("mushroom", "MushroomMove1.bmp", 40, 40);
	IMAGEMANAGER->addImage("miniTurtle", "MiniTurtleIdle.bmp", 40, 40);
	IMAGEMANAGER->addImage("miniCupa", "MiniCupaIdle.bmp", 64, 64);
	IMAGEMANAGER->addImage("ggul", "GgulMove1.bmp", 40, 40);
	IMAGEMANAGER->addImage("greenTurtle", "GreenTurtleMove1.bmp", 40, 60);
	IMAGEMANAGER->addImage("boss", "BossIdle.bmp", 160, 160);

	for (int i = 0; i < 9; i++)
	{
		isSelectEnemy[i] = false;
		
	}
	//�ʿ� �׷��� ���� �ε��� �ʱ�ȭ
	bossIndex = 0;
	//���� ���� �Һ��� �ʱ�ȭ
	isRenderBoss = false;

	//�޴��� ��Ʈ �ʱ�ȭ
	_rcMenu = RectMake(800, 0, 400, 600);
	//�޴��� �̹���
	IMAGEMANAGER->addImage("menu", "�޴���.bmp", 400, 600);

	//������(BnO) ��Ʈ �ʱ�ȭ
	_rcPageBnO = RectMake(800, 0, 400, 600);	
	//������(BnO) �̹���
	IMAGEMANAGER->addImage("tileBookBnO", "å��(BnO).bmp", 400, 600);

	//������(PnE) ��Ʈ �ʱ�ȭ
	_rcPagePnE = RectMake(800, 0, 400, 600);
	//������(PnE) �̹���
	IMAGEMANAGER->addImage("tileBookPnE", "å��(PnE).bmp", 400, 600);

	//�޴���ư �̹���
	IMAGEMANAGER->addFrameImage("button", "��ư.bmp", 131, 160, 1, 5);

	
	//��������
	this->maptoolSetup();
                                                                                                                                                                                                                
	
	return S_OK;
}

void maptoolScene::release()
{
}

void maptoolScene::update()
{

	//��� ���� �̹��� ��ǥ ������Ʈ
	//IMAGEMANAGER->findImage("sampleCloud")->setX(_rcPageBnO.left + 35);
	//IMAGEMANAGER->findImage("sampleCloud")->setY(_rcPageBnO.top + 83);
	//IMAGEMANAGER->findImage("sampleMountain")->setX(_rcPageBnO.left + 150);
	//IMAGEMANAGER->findImage("sampleMountain")->setY(_rcPageBnO.top + 83);
	//IMAGEMANAGER->findImage("sampleForest")->setX(_rcPageBnO.left + 265);
	//IMAGEMANAGER->findImage("sampleForest")->setY(_rcPageBnO.top + 83);
	//IMAGEMANAGER->findImage("sampleSea")->setX(_rcPageBnO.left + 35);
	//IMAGEMANAGER->findImage("sampleSea")->setY(_rcPageBnO.top + 303);
	//IMAGEMANAGER->findImage("sampleJungle")->setX(_rcPageBnO.left + 150);
	//IMAGEMANAGER->findImage("sampleJungle")->setY(_rcPageBnO.top + 303);
	//IMAGEMANAGER->findImage("sampleSky")->setX(_rcPageBnO.left + 265);
	//IMAGEMANAGER->findImage("sampleSky")->setY(_rcPageBnO.top + 303);

	//�÷��̾� ���� �̹��� ��ǥ ������Ʈ
	IMAGEMANAGER->findImage("mario")->setX(_rcPagePnE.left + 80);
	IMAGEMANAGER->findImage("mario")->setY(_rcPagePnE.top + 150);
	IMAGEMANAGER->findImage("realMario")->setX(_rcPagePnE.left + 230);
	IMAGEMANAGER->findImage("realMario")->setY(_rcPagePnE.top + 150);
	IMAGEMANAGER->findImage("luigi")->setX(_rcPagePnE.left + 80);
	IMAGEMANAGER->findImage("luigi")->setY(_rcPagePnE.top + 300);
	IMAGEMANAGER->findImage("toad")->setX(_rcPagePnE.left + 230);
	IMAGEMANAGER->findImage("toad")->setY(_rcPagePnE.top + 300);

	//���ʹ� ���� �̹��� ��ǥ ������Ʈ
	IMAGEMANAGER->findImage("wall")->setX(_rcPagePnE.left + 60);
	IMAGEMANAGER->findImage("wall")->setY(_rcPagePnE.top + 100);
	IMAGEMANAGER->findImage("skeleton")->setX(_rcPagePnE.left + 180);
	IMAGEMANAGER->findImage("skeleton")->setY(_rcPagePnE.top + 100);
	IMAGEMANAGER->findImage("redTurtle")->setX(_rcPagePnE.left + 300);
	IMAGEMANAGER->findImage("redTurtle")->setY(_rcPagePnE.top + 100);
	IMAGEMANAGER->findImage("mushroom")->setX(_rcPagePnE.left + 60);
	IMAGEMANAGER->findImage("mushroom")->setY(_rcPagePnE.top + 250);
	IMAGEMANAGER->findImage("boss")->setX(_rcPagePnE.left + 135);
	IMAGEMANAGER->findImage("boss")->setY(_rcPagePnE.top + 160);
	IMAGEMANAGER->findImage("miniTurtle")->setX(_rcPagePnE.left + 300);
	IMAGEMANAGER->findImage("miniTurtle")->setY(_rcPagePnE.top + 250);
	IMAGEMANAGER->findImage("miniCupa")->setX(_rcPagePnE.left + 60);
	IMAGEMANAGER->findImage("miniCupa")->setY(_rcPagePnE.top + 400);
	IMAGEMANAGER->findImage("ggul")->setX(_rcPagePnE.left + 180);
	IMAGEMANAGER->findImage("ggul")->setY(_rcPagePnE.top + 400);
	IMAGEMANAGER->findImage("greenTurtle")->setX(_rcPagePnE.left + 300);
	IMAGEMANAGER->findImage("greenTurtle")->setY(_rcPagePnE.top + 400);
	
	
	//å�� ������ �̵� ��ư ��ǥ ������Ʈ
	_rcPrev = RectMake(_rcPageBnO.left + 38, _rcPageBnO.top + 511, 44, 44);		//���� ��ư ��Ʈ
	_rcNext = RectMake(_rcPageBnO.left + 318, _rcPageBnO.top + 511, 44, 44);	//���� ��ư ��Ʈ

	//BG, Obj ��ư ��Ʈ
	_rcBackGround = RectMake(_rcPageBnO.left + 77, _rcPageBnO.top + 37, 55, 30);
	_rcObject = RectMake(_rcPageBnO.left + 242, _rcPageBnO.top + 37, 80, 30);

	//player, enemy ��ư ��Ʈ
	_rcPlayer = RectMake(_rcPagePnE.left + 37, _rcPagePnE.top + 37, 160, 32);
	_rcEnemy = RectMake(_rcPagePnE.left + 231, _rcPagePnE.top + 37, 135, 32);


	//��漱��
	if (_kindSelect == KIND_BG)
	{
		//������� ������ ���
		if (PtInRect(&(IMAGEMANAGER->findImage("sampleCloud")->boudingBox()), _ptMouse))
		{
			if (INPUT->GetKey(VK_LBUTTON))
			{
				isSelectBg[0] = true;
				isSelectBg[1] = false;
				isSelectBg[2] = false;
				isSelectBg[3] = false;
				isSelectBg[4] = false;
				isSelectBg[5] = false;
			}
		}
		//���� ������ ���
		if (PtInRect(&(IMAGEMANAGER->findImage("sampleMountain")->boudingBox()), _ptMouse))
		{
			if (INPUT->GetKey(VK_LBUTTON))
			{
				isSelectBg[1] = true;
				isSelectBg[0] = false;
				isSelectBg[2] = false;
				isSelectBg[3] = false;
				isSelectBg[4] = false;
				isSelectBg[5] = false;
			}
		}
		//����� ������ ���
		if (PtInRect(&(IMAGEMANAGER->findImage("sampleForest")->boudingBox()), _ptMouse))
		{
			if (INPUT->GetKey(VK_LBUTTON))
			{
				isSelectBg[2] = true;
				isSelectBg[0] = false;
				isSelectBg[1] = false;
				isSelectBg[3] = false;
				isSelectBg[4] = false;
				isSelectBg[5] = false;
			}
		}
		//���ع�� ������ ���
		if (PtInRect(&(IMAGEMANAGER->findImage("sampleSea")->boudingBox()), _ptMouse))
		{
			if (INPUT->GetKey(VK_LBUTTON))
			{
				isSelectBg[3] = true;
				isSelectBg[0] = false;
				isSelectBg[1] = false;
				isSelectBg[2] = false;
				isSelectBg[4] = false;
				isSelectBg[5] = false;
			}
		}
		//���۹�� ������ ���
		if (PtInRect(&(IMAGEMANAGER->findImage("sampleJungle")->boudingBox()), _ptMouse))
		{
			if (INPUT->GetKey(VK_LBUTTON))
			{
				isSelectBg[4] = true;
				isSelectBg[0] = false;
				isSelectBg[1] = false;
				isSelectBg[2] = false;
				isSelectBg[3] = false;
				isSelectBg[5] = false;
			}
		}
		//�ϴù�� ������ ���
		if (PtInRect(&(IMAGEMANAGER->findImage("sampleSky")->boudingBox()), _ptMouse))
		{
			if (INPUT->GetKey(VK_LBUTTON))
			{
				isSelectBg[5] = true;
				isSelectBg[1] = false;
				isSelectBg[2] = false;
				isSelectBg[3] = false;
				isSelectBg[4] = false;
				isSelectBg[0] = false;
			}
		}
	}

	//�÷��̾��
	if (_charSelect == CHARACTER_PLAYER)
	{
		if (PtInRect(&(IMAGEMANAGER->findImage("mario")->boudingBox()), _ptMouse))
		{
			if (INPUT->GetKey(VK_LBUTTON))
			{
				isSelectPlayer[0] = true;
				isSelectPlayer[1] = false;
				isSelectPlayer[2] = false;
				isSelectPlayer[3] = false;
			}
		}
		if (PtInRect(&(IMAGEMANAGER->findImage("realMario")->boudingBox()), _ptMouse))
		{
			if (INPUT->GetKey(VK_LBUTTON))
			{
				isSelectPlayer[1] = true;
				isSelectPlayer[0] = false;
				isSelectPlayer[2] = false;
				isSelectPlayer[3] = false;
			}
		}
		if (PtInRect(&(IMAGEMANAGER->findImage("luigi")->boudingBox()), _ptMouse))
		{
			if (INPUT->GetKey(VK_LBUTTON))
			{
				isSelectPlayer[2] = true;
				isSelectPlayer[1] = false;
				isSelectPlayer[0] = false;
				isSelectPlayer[3] = false;
			}
		}
		if (PtInRect(&(IMAGEMANAGER->findImage("toad")->boudingBox()), _ptMouse))
		{
			if (INPUT->GetKey(VK_LBUTTON))
			{
				isSelectPlayer[3] = true;
				isSelectPlayer[0] = false;
				isSelectPlayer[2] = false;
				isSelectPlayer[1] = false;
			}
		}
		
	}
	//���ʹ̼���
	if (_charSelect == CHARACTER_ENEMY)
	{
		if (PtInRect(&(IMAGEMANAGER->findImage("wall")->boudingBox()), _ptMouse))
		{
			if (INPUT->GetKey(VK_LBUTTON))
			{
				isSelectEnemy[0] = true;
				isSelectEnemy[1] = false;
				isSelectEnemy[2] = false;
				isSelectEnemy[3] = false;
				isSelectEnemy[4] = false;
				isSelectEnemy[5] = false;
				isSelectEnemy[6] = false;
				isSelectEnemy[7] = false;
				isSelectEnemy[8] = false;

				

			}
		}
		if (PtInRect(&(IMAGEMANAGER->findImage("skeleton")->boudingBox()), _ptMouse))
		{
			if (INPUT->GetKey(VK_LBUTTON))
			{
				isSelectEnemy[1] = true;
				isSelectEnemy[0] = false;
				isSelectEnemy[2] = false;
				isSelectEnemy[3] = false;
				isSelectEnemy[4] = false;
				isSelectEnemy[5] = false;
				isSelectEnemy[6] = false;
				isSelectEnemy[7] = false;
				isSelectEnemy[8] = false;
				
				
			}
		}
		if (PtInRect(&(IMAGEMANAGER->findImage("redTurtle")->boudingBox()), _ptMouse))
		{
			if (INPUT->GetKey(VK_LBUTTON))
			{
				isSelectEnemy[2] = true;
				isSelectEnemy[0] = false;
				isSelectEnemy[1] = false;
				isSelectEnemy[3] = false;
				isSelectEnemy[4] = false;
				isSelectEnemy[5] = false;
				isSelectEnemy[6] = false;
				isSelectEnemy[7] = false;
				isSelectEnemy[8] = false;

				
			}
		}
		if (PtInRect(&(IMAGEMANAGER->findImage("mushroom")->boudingBox()), _ptMouse))
		{
			if (INPUT->GetKey(VK_LBUTTON))
			{
				isSelectEnemy[3] = true;
				isSelectEnemy[0] = false;
				isSelectEnemy[2] = false;
				isSelectEnemy[1] = false;
				isSelectEnemy[4] = false;
				isSelectEnemy[5] = false;
				isSelectEnemy[6] = false;
				isSelectEnemy[7] = false;
				isSelectEnemy[8] = false;
				
			}
		}
		if (PtInRect(&(IMAGEMANAGER->findImage("miniTurtle")->boudingBox()), _ptMouse))
		{
			if (INPUT->GetKey(VK_LBUTTON))
			{
				isSelectEnemy[4] = true;
				isSelectEnemy[0] = false;
				isSelectEnemy[2] = false;
				isSelectEnemy[3] = false;
				isSelectEnemy[1] = false;
				isSelectEnemy[5] = false;
				isSelectEnemy[6] = false;
				isSelectEnemy[7] = false;
				isSelectEnemy[8] = false;
				
			}
		}
		if (PtInRect(&(IMAGEMANAGER->findImage("miniCupa")->boudingBox()), _ptMouse))
		{
			if (INPUT->GetKey(VK_LBUTTON))
			{
				isSelectEnemy[5] = true;
				isSelectEnemy[0] = false;
				isSelectEnemy[2] = false;
				isSelectEnemy[3] = false;
				isSelectEnemy[4] = false;
				isSelectEnemy[1] = false;
				isSelectEnemy[6] = false;
				isSelectEnemy[7] = false;
				isSelectEnemy[8] = false;
				
			}
		}
		if (PtInRect(&(IMAGEMANAGER->findImage("ggul")->boudingBox()), _ptMouse))
		{
			if (INPUT->GetKey(VK_LBUTTON))
			{
				isSelectEnemy[6] = true;
				isSelectEnemy[0] = false;
				isSelectEnemy[2] = false;
				isSelectEnemy[3] = false;
				isSelectEnemy[4] = false;
				isSelectEnemy[5] = false;
				isSelectEnemy[1] = false;
				isSelectEnemy[7] = false;
				isSelectEnemy[8] = false;
				
			}
		}
		if (PtInRect(&(IMAGEMANAGER->findImage("greenTurtle")->boudingBox()), _ptMouse))
		{
			if (INPUT->GetKey(VK_LBUTTON))
			{
				isSelectEnemy[7] = true;
				isSelectEnemy[0] = false;
				isSelectEnemy[2] = false;
				isSelectEnemy[3] = false;
				isSelectEnemy[4] = false;
				isSelectEnemy[5] = false;
				isSelectEnemy[6] = false;
				isSelectEnemy[1] = false;
				isSelectEnemy[8] = false;
				
			}
		}
		if (PtInRect(&(IMAGEMANAGER->findImage("boss")->boudingBox()), _ptMouse))
		{
			if (INPUT->GetKey(VK_LBUTTON))
			{
				isSelectEnemy[8] = true;
				isSelectEnemy[0] = false;
				isSelectEnemy[2] = false;
				isSelectEnemy[3] = false;
				isSelectEnemy[4] = false;
				isSelectEnemy[5] = false;
				isSelectEnemy[6] = false;
				isSelectEnemy[7] = false;
				isSelectEnemy[1] = false;
			
			}
		}
	}

	if (INPUT->GetKey(VK_LBUTTON)) this->setMap();
		
	
	if (INPUT->GetKeyDown(VK_LBUTTON))
	{
		if (PtInRect(&_rcSave, _ptMouse))
		{
			_ctrlSelect = CTRL_SAVE;
			this->save();
		}
		if (PtInRect(&_rcLoad, _ptMouse))
		{
			_ctrlSelect = CTRL_LOAD;
			this->load();
		}
		if (PtInRect(&_rcBackGround, _ptMouse))
		{
			_ctrlSelect = CTRL_NONE;
			_kindSelect = KIND_BG;				//Ÿ�� ���� = ���	
		}
		if (PtInRect(&_rcObject, _ptMouse))
		{
			_ctrlSelect = CTRL_NONE;
			_kindSelect = KIND_OBJECT;			//Ÿ�� ���� = ������Ʈ
		}
		if (PtInRect(&_rcPlayer, _ptMouse))
		{
			_ctrlSelect = CTRL_NONE;
			_charSelect = CHARACTER_PLAYER;		//�÷��̾�
		}
		if (PtInRect(&_rcEnemy, _ptMouse))
		{
			_ctrlSelect = CTRL_NONE;
			_charSelect = CHARACTER_ENEMY;		//���ʹ�
		}
		if (PtInRect(&_rcEraser, _ptMouse))
		{
			_ctrlSelect = CTRL_ERASER;

		}

		//������ �ѱ��
		//����ȭ��ǥ Ŭ��
		if (PtInRect(&_rcPrev, _ptMouse))
		{
			if (pageCount > 0) pageCount--;
		}
		//����ȭ��ǥ Ŭ��
		if (PtInRect(&_rcNext, _ptMouse))
		{
			if (pageCount < 4) pageCount++;
		}

	}

	//������ ������ ��� ���
	if (pageCount < 0) pageCount = 0;
	if (pageCount > 4) pageCount = 4;

	
	
}

void maptoolScene::render()
{
	
	////���õ� ��� �̹��� ���
	//for (int i = 0; i < 6; i++)
	//{
	//	if(isSelectBg[i])
	//		switch (i)
	//		{
	//		case 0:
	//			IMAGEMANAGER->render("cloud", getMemDC(), 0, 0);
	//			break;
	//		case 1:
	//			IMAGEMANAGER->render("mountain", getMemDC(), 0, 0);
	//			break;
	//		case 2:
	//			IMAGEMANAGER->render("forest", getMemDC(), 0, 0);
	//			break;
	//		case 3:
	//			IMAGEMANAGER->render("sea", getMemDC(), 0, 0);
	//			break;
	//		case 4:
	//			IMAGEMANAGER->render("jungle", getMemDC(), 0, 0);
	//			break;
	//		case 5:
	//			IMAGEMANAGER->render("sky_bg", getMemDC(), 0, 0);
	//			break;
	//		}
	//}
	
	////�޴��� ��Ʈ ���
	//Rectangle(getMemDC(), _rcMenu);
	////�޴��� �̹��� ���
	//IMAGEMANAGER->render("menu", getMemDC(), _rcMenu.left, _rcMenu.top);
	//
	////������(BnO)��Ʈ ���
	//Rectangle(getMemDC(), _rcPageBnO);
	////������(BnO) �̹��� ���
	//IMAGEMANAGER->render("tileBookBnO", getMemDC(), _rcPageBnO.left, _rcPageBnO.top);

	//������(PnE)��Ʈ ���
	Rectangle(getMemDC(), _rcPagePnE);
	//������(PnE) �̹��� ���
	IMAGEMANAGER->render("tileBookPnE", getMemDC(), _rcPagePnE.left, _rcPagePnE.top);
	
	////��� ���� �̹��� ���
	//if (_kindSelect == KIND_BG)
	//{
	//	IMAGEMANAGER->render("sampleCloud", getMemDC(),IMAGEMANAGER->findImage("sampleCloud")->getX(), IMAGEMANAGER->findImage("sampleCloud")->getY());
	//	IMAGEMANAGER->render("sampleMountain", getMemDC(),IMAGEMANAGER->findImage("sampleMountain")->getX(), IMAGEMANAGER->findImage("sampleMountain")->getY());
	//	IMAGEMANAGER->render("sampleForest", getMemDC(),IMAGEMANAGER->findImage("sampleForest")->getX(), IMAGEMANAGER->findImage("sampleForest")->getY());
	//	IMAGEMANAGER->render("sampleJungle", getMemDC(),IMAGEMANAGER->findImage("sampleJungle")->getX(), IMAGEMANAGER->findImage("sampleJungle")->getY());
	//	IMAGEMANAGER->render("sampleSea", getMemDC(),IMAGEMANAGER->findImage("sampleSea")->getX(), IMAGEMANAGER->findImage("sampleSea")->getY());
	//	IMAGEMANAGER->render("sampleSky", getMemDC(),IMAGEMANAGER->findImage("sampleSky")->getX(), IMAGEMANAGER->findImage("sampleSky")->getY());
	//
	//}

	////������Ʈ ���� �̹��� ���
	//if (_kindSelect == KIND_OBJECT)
	//{
	//	////�������̵� ȭ��ǥ ��Ʈ ���
	//	//Rectangle(getMemDC(), _rcPrev);	//����
	//	//Rectangle(getMemDC(), _rcNext);	//����
	//	
	//	//������ �̵��� ���� ��� ��ȭ
	//	switch (pageCount)
	//	{case 0:
	//	{
	//		IMAGEMANAGER->render("basic", getMemDC(), _sampleTile[0].rc.left, _sampleTile[0].rc.top);
	//		
	//		break;
	//	}
	//	case 1:
	//	{
	//		IMAGEMANAGER->render("snow", getMemDC(), _sampleTile[0].rc.left, _sampleTile[0].rc.top);
	//		
	//		break;
	//	}
	//	case 2:
	//	{
	//		IMAGEMANAGER->render("sky", getMemDC(), _sampleTile[0].rc.left, _sampleTile[0].rc.top);
	//		
	//		break;
	//	}
	//	case 3:
	//	{
	//
	//		IMAGEMANAGER->render("object", getMemDC(), _sampleTile[0].rc.left, _sampleTile[0].rc.top);
	//		
	//		break;
	//	}
	//	case 4:
	//	{
	//		IMAGEMANAGER->render("basement", getMemDC(), _sampleTile[0].rc.left, _sampleTile[0].rc.top);
	//		
	//		break;
	//
	//	}
	//	}
	//	
	//}
	
	//�÷��̾� ���� �̹��� ���
	if (_charSelect == CHARACTER_PLAYER)
	{
		IMAGEMANAGER->render("mario", getMemDC(), IMAGEMANAGER->findImage("mario")->getX(), IMAGEMANAGER->findImage("mario")->getY());
		IMAGEMANAGER->frameRender("realMario", getMemDC(), IMAGEMANAGER->findImage("realMario")->getX(), IMAGEMANAGER->findImage("realMario")->getY(),0,0);
		IMAGEMANAGER->frameRender("luigi", getMemDC(), IMAGEMANAGER->findImage("luigi")->getX(), IMAGEMANAGER->findImage("luigi")->getY(), 0, 0);
		IMAGEMANAGER->frameRender("toad", getMemDC(), IMAGEMANAGER->findImage("toad")->getX(), IMAGEMANAGER->findImage("toad")->getY(), 0, 0);
	}

	//���ʹ� ���� �̹��� ���
	if (_charSelect == CHARACTER_ENEMY)
	{
		IMAGEMANAGER->render("wall", getMemDC(), IMAGEMANAGER->findImage("wall")->getX(), IMAGEMANAGER->findImage("wall")->getY());
		IMAGEMANAGER->render("skeleton", getMemDC(), IMAGEMANAGER->findImage("skeleton")->getX(), IMAGEMANAGER->findImage("skeleton")->getY());
		IMAGEMANAGER->render("redTurtle", getMemDC(), IMAGEMANAGER->findImage("redTurtle")->getX(), IMAGEMANAGER->findImage("redTurtle")->getY());
		IMAGEMANAGER->render("mushroom", getMemDC(), IMAGEMANAGER->findImage("mushroom")->getX(), IMAGEMANAGER->findImage("mushroom")->getY());
		IMAGEMANAGER->render("miniTurtle", getMemDC(), IMAGEMANAGER->findImage("miniTurtle")->getX(), IMAGEMANAGER->findImage("miniTurtle")->getY());
		IMAGEMANAGER->render("miniCupa", getMemDC(), IMAGEMANAGER->findImage("miniCupa")->getX(), IMAGEMANAGER->findImage("miniCupa")->getY());
		IMAGEMANAGER->render("ggul", getMemDC(), IMAGEMANAGER->findImage("ggul")->getX(), IMAGEMANAGER->findImage("ggul")->getY());
		IMAGEMANAGER->render("greenTurtle", getMemDC(), IMAGEMANAGER->findImage("greenTurtle")->getX(), IMAGEMANAGER->findImage("greenTurtle")->getY());
		IMAGEMANAGER->render("boss", getMemDC(), IMAGEMANAGER->findImage("boss")->getX(), IMAGEMANAGER->findImage("boss")->getY());
	}

//	//�ΰ���ȭ�� ������Ʈ�� �׸���
//	for (int i = 0; i < TILEX * TILEY; i++)
//	{
//		if (_tiles[i].obj == OBJ_NONE) continue;
//
//		//������Ʈ �������� �ٸ� �̹��� Ÿ�� ��Ÿ����
//		if (_tiles[i].obj == OBJ_OBJECT1)
//		{
//			IMAGEMANAGER->frameRender("basic", getMemDC(), _tiles[i].rc.left, _tiles[i].rc.top,
//				_tiles[i].objFrameX, _tiles[i].objFrameY);
//		}
//		if (_tiles[i].obj == OBJ_OBJECT2)
//		{
//			IMAGEMANAGER->frameRender("snow", getMemDC(), _tiles[i].rc.left, _tiles[i].rc.top,
//				_tiles[i].objFrameX, _tiles[i].objFrameY);
//		}
//		if (_tiles[i].obj == OBJ_OBJECT3)
//		{
//			IMAGEMANAGER->frameRender("sky", getMemDC(), _tiles[i].rc.left, _tiles[i].rc.top,
//				_tiles[i].objFrameX, _tiles[i].objFrameY);
//		}
//		if (_tiles[i].obj == OBJ_OBJECT4)
//		{
//			IMAGEMANAGER->frameRender("object", getMemDC(), _tiles[i].rc.left, _tiles[i].rc.top,
//				_tiles[i].objFrameX, _tiles[i].objFrameY);
//		}
//		if (_tiles[i].obj == OBJ_OBJECT5)
//		{
//			IMAGEMANAGER->frameRender("basement", getMemDC(), _tiles[i].rc.left, _tiles[i].rc.top,
//				_tiles[i].objFrameX, _tiles[i].objFrameY);
//		}
//	}
	
	//�÷��̾� �ʿ� �׸���
	//��������
	if(isRenderPlayer[0])
		IMAGEMANAGER->render("mario", getMemDC(), _tiles[playerIndex[0]].rc.left, _tiles[playerIndex[0]].rc.top);
	//�𸶸���
	if (isRenderPlayer[1])
		IMAGEMANAGER->frameRender("realMario", getMemDC(), _tiles[playerIndex[1]].rc.left, _tiles[playerIndex[1]].rc.top,0,0);
	//������
	if (isRenderPlayer[2])
		IMAGEMANAGER->frameRender("luigi", getMemDC(), _tiles[playerIndex[2]].rc.left, _tiles[playerIndex[2]].rc.top,0,0);
	//��������
	if (isRenderPlayer[3])
		IMAGEMANAGER->frameRender("toad", getMemDC(), _tiles[playerIndex[3]].rc.left, _tiles[playerIndex[3]].rc.top,0,0);

	//���ʹ� �ʿ� �׸���
	//wall
	for (int i = 0; i < enemyIndex[0].size(); i++)
	{
		IMAGEMANAGER->render("wall", getMemDC(), _tiles[enemyIndex[0][i]].rc.left, _tiles[enemyIndex[0][i]].rc.top);
	}
	//skeleton
	for (int i = 0; i < enemyIndex[1].size(); i++)
	{
		IMAGEMANAGER->render("skeleton", getMemDC(), _tiles[enemyIndex[1][i]].rc.left, _tiles[enemyIndex[1][i]].rc.top);
	}
	//redTurtle
	for (int i = 0; i < enemyIndex[2].size(); i++)
	{
		IMAGEMANAGER->render("redTurtle", getMemDC(), _tiles[enemyIndex[2][i]].rc.left, _tiles[enemyIndex[2][i]].rc.top);
	}
	//mushroom
	for (int i = 0; i < enemyIndex[3].size(); i++)
	{
		IMAGEMANAGER->render("mushroom", getMemDC(), _tiles[enemyIndex[3][i]].rc.left, _tiles[enemyIndex[3][i]].rc.top);
	}
	//miniTurtle
	for (int i = 0; i < enemyIndex[4].size(); i++)
	{
		IMAGEMANAGER->render("miniTurtle", getMemDC(), _tiles[enemyIndex[4][i]].rc.left, _tiles[enemyIndex[4][i]].rc.top);
	}
	//miniCupa
	for (int i = 0; i < enemyIndex[5].size(); i++)
	{
		IMAGEMANAGER->render("miniCupa", getMemDC(), _tiles[enemyIndex[5][i]].rc.left, _tiles[enemyIndex[5][i]].rc.top);
	}
	//ggul
	for (int i = 0; i < enemyIndex[6].size(); i++)
	{
		IMAGEMANAGER->render("ggul", getMemDC(), _tiles[enemyIndex[6][i]].rc.left, _tiles[enemyIndex[6][i]].rc.top);
	}
	//greenTurtle
	for (int i = 0; i < enemyIndex[7].size(); i++)
	{
		IMAGEMANAGER->render("greenTurtle", getMemDC(), _tiles[enemyIndex[7][i]].rc.left, _tiles[enemyIndex[7][i]].rc.top);
	}
	
	//boss
	if (isRenderBoss)
		IMAGEMANAGER->render("boss", getMemDC(), _tiles[bossIndex].rc.left, _tiles[bossIndex].rc.top);
	
	//���� ����ȭ�� �� ������ ����Ÿ�� ��Ʈ �����ֱ�
	if (INPUT->GetToggleKey(VK_F1))
	{
		for (int i = 0; i < TILEX * TILEY; i++)
		{
			
			FrameRect(getMemDC(), _tiles[i].rc, RGB(255, 255, 0));
		}

		if (_kindSelect == KIND_OBJECT)
		{
			for (int i = 0; i < SAMPLETILEX * SAMPLETILEY; i++)
			{

				FrameRect(getMemDC(), _sampleTile[i].rc, RGB(255, 255, 0));
			}
		}
	}

	

	////��Ʈ�� ��ư �̹��� ���
	Rectangle(getMemDC(), _rcEraser);
	IMAGEMANAGER->frameRender("button", getMemDC(), _rcEraser.left, _rcEraser.top, 0, 0);
	//IMAGEMANAGER->frameRender("button", getMemDC(), _rcPnE.left, _rcPnE.top, 0, 1);
	//IMAGEMANAGER->frameRender("button", getMemDC(), _rcLoad.left, _rcLoad.top, 0, 2);
	//IMAGEMANAGER->frameRender("button", getMemDC(), _rcSave.left, _rcSave.top, 0, 3);
	//IMAGEMANAGER->frameRender("button", getMemDC(), _rcBnO.left, _rcBnO.top, 0, 4);
	
	//Rectangle(getMemDC(), _rcPlayer);
	//Rectangle(getMemDC(), _rcEnemy);
	
	
}

void maptoolScene::maptoolSetup()
{
	

	//���� �ΰ���ȭ�� ��Ʈ �ʱ�ȭ
	for (int i = 0; i < TILEY; i++)
	{
		for (int j = 0; j < TILEX; j++)
		{
			_tiles[i * TILEX + j].rc = RectMake(j * TILESIZE, i * TILESIZE, TILESIZE, TILESIZE);
		}
	}

	//������ ����Ÿ�� ��Ʈ �ʱ�ȭ
	for (int i = 0; i < SAMPLETILEY; i++)
	{
		for (int j = 0; j < SAMPLETILEX; j++)
		{
			_sampleTile[i * SAMPLETILEX + j].rc = RectMake(_rcPageBnO.left + 40 + j * TILESIZE, _rcPageBnO.top + 100 + i * TILESIZE, TILESIZE, TILESIZE);
		
			_sampleTile[i * SAMPLETILEX + j].objFrameX = j;
			_sampleTile[i * SAMPLETILEX + j].objFrameY = i;
		}
	}

	
	////��Ʈ�ѹ�ư ��Ʈ ��ġ �ʱ�ȭ (�޴��� ��ư)
	//_rcSave = RectMakeCenter(_rcMenu.left + 120, _rcMenu.top + 230, 131, 32);
	//_rcLoad = RectMakeCenter(_rcMenu.left + 270, _rcMenu.top + 230, 131, 32);
	//_rcBnO = RectMakeCenter(_rcMenu.left + 120, _rcMenu.top + 330, 131, 32);
	//_rcPnE = RectMakeCenter(_rcMenu.left + 270, _rcMenu.top + 330, 131, 32);
	//_rcEraser = RectMakeCenter(_rcMenu.left + 135, _rcMenu.top + 430, 131, 32);
	_rcEraser = RectMakeCenter(WINSIZEX-300, WINSIZEY-100 , 131, 32);
	

}

void maptoolScene::setMap()
{
	//������Ʈ ����
	if (_kindSelect == KIND_OBJECT)
	{
		for (int i = 0; i < SAMPLETILEX * SAMPLETILEY; i++)
		{
			if (PtInRect(&_sampleTile[i].rc, _ptMouse))
			{
				_currentTile.x = _sampleTile[i].objFrameX;
				_currentTile.y = _sampleTile[i].objFrameY;
				break;
			}
		}

		//�ΰ���ȭ�� ��ƮƲ�� �浹�߳�?
		for (int i = 0; i < TILEX * TILEY; i++)
		{
			if (PtInRect(&_tiles[i].rc, _ptMouse))
			{
				//�����ư�� ������Ʈ�� ���
				if (_kindSelect == KIND_OBJECT)
				{
					_tiles[i].objFrameX = _currentTile.x;
					_tiles[i].objFrameY = _currentTile.y;

					//���������� ������Ʈ ���� ������
					switch (pageCount)
					{
					case 0:
						_tiles[i].obj = OBJ_OBJECT1;
						break;
					case 1:
						_tiles[i].obj = OBJ_OBJECT2;
						break;
					case 2:
						_tiles[i].obj = OBJ_OBJECT3;
						break;
					case 3:
						_tiles[i].obj = OBJ_OBJECT4;
						break;
					case 4:
						_tiles[i].obj = OBJ_OBJECT5;
						break;
					}
				}
			}
		}
	}
	//�÷��̾� ����
	if (_charSelect == CHARACTER_PLAYER)
	{
		//��������
		if (isSelectPlayer[0])
		{
			for (int i = 0; i < TILEX * TILEY; i++)
			{
				if (PtInRect(&_tiles[i].rc, _ptMouse))
				{
					if (i % 20 == 19 || i >= 380)continue;
					playerIndex[0] = i;
					isRenderPlayer[0] = true;
					isRenderPlayer[1] = false;
					isRenderPlayer[2] = false;
					isRenderPlayer[3] = false;
					break;
					
				}

			}
		}
		//�𸶸���
		if (isSelectPlayer[1])
		{

			for (int i = 0; i < TILEX * TILEY; i++)
			{
				if (PtInRect(&_tiles[i].rc, _ptMouse))
				{
					if (i % 20 == 19 || i >= 380)continue;
					playerIndex[1] = i;
					isRenderPlayer[1] = true;
					isRenderPlayer[0] = false;
					isRenderPlayer[2] = false;
					isRenderPlayer[3] = false;
					break;

				}

			}
		}

		//������
		if (isSelectPlayer[2])
		{

			for (int i = 0; i < TILEX * TILEY; i++)
			{
				if (i % 20 == 19 || i >= 380)continue;
				if (PtInRect(&_tiles[i].rc, _ptMouse))
				{
					playerIndex[2] = i;
					isRenderPlayer[2] = true;
					isRenderPlayer[0] = false;
					isRenderPlayer[1] = false;
					isRenderPlayer[3] = false;
					break;

				}

			}
		}
		//��������
		if (isSelectPlayer[3])
		{

			for (int i = 0; i < TILEX * TILEY; i++)
			{
				if (PtInRect(&_tiles[i].rc, _ptMouse))
				{
					if (i % 20 == 19 || i >= 380)continue;
					playerIndex[3] = i;
					isRenderPlayer[3] = true;
					isRenderPlayer[0] = false;
					isRenderPlayer[2] = false;
					isRenderPlayer[1] = false;
					break;

				}

			}
		}

	}

	//���ʹ� ����
	if (_charSelect == CHARACTER_ENEMY )
	{
		//wall
		if (isSelectEnemy[0])
		{
			for (int i = 0; i < TILEX * TILEY; i++)
			{
				if (PtInRect(&_tiles[i].rc, _ptMouse))
				{
					if (i % 20 == 19 || i >= 380)continue;
					enemyIndex[0].push_back(i);
				
				}

			}
		}
		//skeleton
		if (isSelectEnemy[1])
		{
			for (int i = 0; i < TILEX * TILEY; i++)
			{
				if (PtInRect(&_tiles[i].rc, _ptMouse))
				{
					if (i % 20 == 19 || i >= 380)continue;
					enemyIndex[1].push_back(i);
	
				}
	
			}
		}
		//redTurtle
		if (isSelectEnemy[2])
		{
			for (int i = 0; i < TILEX * TILEY; i++)
			{
				if (PtInRect(&_tiles[i].rc, _ptMouse))
				{
					if (i>= 380)continue;
					enemyIndex[2].push_back(i);
	
				}
	
			}
		}
		//mushroom
		if (isSelectEnemy[3])
		{
			for (int i = 0; i < TILEX * TILEY; i++)
			{
				
				if (PtInRect(&_tiles[i].rc, _ptMouse))
				{
					
					enemyIndex[3].push_back(i);
	
				}
	
			}
		}
		//miniTurtle
		if (isSelectEnemy[4])
		{
			for (int i = 0; i < TILEX * TILEY; i++)
			{
				
				if (PtInRect(&_tiles[i].rc, _ptMouse))
				{
					
					enemyIndex[4].push_back(i);
	
				}
	
			}
		}
		//miniCupa
		if (isSelectEnemy[5])
		{
			for (int i = 0; i < TILEX * TILEY; i++)
			{
				if (PtInRect(&_tiles[i].rc, _ptMouse))
				{
					if (i % 20 == 19 || i >= 380)continue;
					enemyIndex[5].push_back(i);
	
				}
	
			}
		}
		//ggul
		if (isSelectEnemy[6])
		{
			for (int i = 0; i < TILEX * TILEY; i++)
			{
				if (PtInRect(&_tiles[i].rc, _ptMouse))
				{
					enemyIndex[6].push_back(i);
	
				}
	
			}
		}
		//greenTurtle
		if (isSelectEnemy[7])
		{
			for (int i = 0; i < TILEX * TILEY; i++)
			{
				if (PtInRect(&_tiles[i].rc, _ptMouse))
				{
					if (i >= 380)continue;
					enemyIndex[7].push_back(i);
	
				}
	
			}
		}
		//boss
		if (isSelectEnemy[8])
		{
			for (int i = 0; i < TILEX * TILEY; i++)
			{
				if (PtInRect(&_tiles[i].rc, _ptMouse))
				{
					bossIndex = i;
					isRenderBoss = true;
	
				}
	
			}
		}
	}

	
	for (int i = 0; i < TILEX * TILEY; i++)
	{
		//�����ư�� ���찳��?
		if (_ctrlSelect == CTRL_ERASER)
		{
			_tiles[i].objFrameX = 0;
			_tiles[i].objFrameY = 0;
			_tiles[i].obj = OBJ_NONE;

			//if (_charSelect == CHARACTER_ENEMY)
			//{
			//	for (int j = 0; j < enemyIndex[0].size(); j++)
			//	{
			//		if (enemyIndex[0][j] == i)
			//			enemyIndex[0].erase(enemyIndex[0].begin()+j);
			//		break;
			//	}
			//}
		}
	
	}
		
	

}

void maptoolScene::save()
{
	HANDLE file;
	DWORD write;

	file = CreateFile("save.map", GENERIC_WRITE, 0, NULL, CREATE_ALWAYS,
		FILE_ATTRIBUTE_NORMAL, NULL);
	WriteFile(file, _tiles, sizeof(tagTile) * TILEX * TILEY, &write, NULL);
	CloseHandle(file);
}

void maptoolScene::load()
{
	HANDLE file;
	DWORD read;

	file = CreateFile("save.map", GENERIC_READ, 0, NULL, OPEN_EXISTING,
		FILE_ATTRIBUTE_NORMAL, NULL);
	ReadFile(file, _tiles, sizeof(tagTile) * TILEX * TILEY, &read, NULL);
	CloseHandle(file);
}


//BACKGROUND maptoolScene::bgSelect(int frameX, int frameY)
//{
//	
//}

//OBJECT maptoolScene::objectSelect(int frameX, int frameY)
//{
//	
//}
//