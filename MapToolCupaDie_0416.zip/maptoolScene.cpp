#include "stdafx.h"
#include "maptoolScene.h"

HRESULT maptoolScene::init()
{

	//���� �ؾ��Ұ͵�
	//�̷�������(,....���� ��)
	//��׶��弱�� �̳����� ����(���� ��)
	//���������� �Һ����� �ʹ�����. �����Ϸ��� �̳����� �ؾ��ϳ� �ð��̾���.

	//�Ѱ͵�
		//Ŭ���� ����(80%)-�ݱ��ư���� �ٵ�?
		//PnE or BnO â �����־ ����Ȳ���� â�� �����־ ������ ��ģ��
		//������ ��Ʈ�ȿ����� ��Ű�ϱ� �巡���ʱ�ɿ��۵�
		//(ī�޶� ���������� �׺κ��� ��ä����  �¸��� �ΰ��� ������ �ذᰡ���ҵ�)
		//���ʹ� �÷��̾� ��ġ(���̲����� ��)
		//�巡�׼��ñ�� ����(ä������ ��)(������)
		//�̴ϸ� ����(��/�̷�����ÿ��� ä�����¿��� ��ƾ��� ��)
		//å�� ī�޶�Ʈ�ȿ��� �����϶� �巡���ʱ�� �۵����ϰ�(��)


	IMAGEMANAGER->addImage("���콺", "Images/���콺.bmp", 34, 40);
	IMAGEMANAGER->addImage("���찳", "Images/���찳.bmp", 58, 43);

	ShowCursor(false);

	//�������� ����
	SetWindowPos(_hWnd, NULL, 50, 50, WINSIZEX + 15, WINSIZEY + 38, 0);
	//�� UI(�׵θ�)
	IMAGEMANAGER->addImage("FrontUI", "Images/FrontUI.bmp",1260,860);
	IMAGEMANAGER->addImage("collision", "collsion.bmp", 4000, 1000);
	//�⺻�������� ����
	//_kindSelect = KIND_BG;
	_ctrlSelect = CTRL_NONE;
	//_charSelect = CHARACTER_PLAYER;

	_temp = false;			//�Ͻ������� Ŭ����ġ�����ϱ����� ���Լ�
	_save = false;
	_paint = false;
	//ī�޶� INIT
	{
		winX = 0;//���� ������
		winY = 0;//���� ������
		_bar = 20;//�׵θ��� ũ��

		_cameraRc = RectMake(20, 20, 800, 820); //ī�޶� ��Ʈ �ʱ�ȭ
		_mouseRc = RectMakeCenter(_ptMouse.x, _ptMouse.y, 100, 100); //���콺�� ����ٴϴ� ��Ʈ �ʱ�ȭ
		_mouseB = false; // ���콺�� ī�޶� �ȿ��ִ��� Ȯ�����ִ� �Һ���
		_mouseMove = false;
		_miniPlayer = RectMake(820, 620, 80, 160);// �̴ϸ��� �þ�
	}
	//å�� INIT
	{

		//å INIT
		{
			//å �׸� ��ġ �ʱ�ȭ
			_rcBook = RectMake(840, 0, 600, 400);
			//��Ʈ�ѹ�ư ��Ʈ ��ġ �ʱ�ȭ
			_rcBnO = RectMakeCenter(_rcBook.left + 120, _rcBook.top + 330, 131, 32);
			_rcPnE = RectMakeCenter(_rcBook.left + 300, _rcBook.top + 330, 131, 32);
			_rcEraser = RectMakeCenter(_rcBook.left + 125, _rcBook.top + 430, 131, 32);
			//_rcOpen = RectMakeCenter(_book.left + 200, _book.top + 250, 131, 32);
			_rcLoad = RectMakeCenter(_rcBook.left + 300, _rcBook.top + 230, 131, 32);
			_rcSave = RectMakeCenter(_rcBook.left + 120, _rcBook.top + 230, 131, 32);
			_rcStart = RectMakeCenter(_rcBook.left + 120, _rcBook.top + 530, 131, 32);
			_isBnOOpen = false;
			_isPnEOpen = false;
			_isBnOOpen = false;
			//å�����̱� ���� �ʿ���
			_isBnOMove = false;
			_isPnEMove = false;
			_once = false;
			_isClick = false;

		}

		//������ ī��Ʈ ���� �ʱ�ȭ
		pageCount = 0;

		//Ÿ���� ������ ������� �����ϱ�
		//_kindSelect = KIND_BG;
		//��� ���� �̹��� 
		{
			IMAGEMANAGER->addImage("sampleCloud", "Images/��������.bmp", 100, 200);
			IMAGEMANAGER->addImage("sampleMountain", "Images/�����.bmp", 100, 200);
			IMAGEMANAGER->addImage("sampleForest", "Images/������.bmp", 100, 200);
			IMAGEMANAGER->addImage("sampleSea", "Images/���ػ���.bmp", 100, 200);
			IMAGEMANAGER->addImage("sampleJungle", "Images/���ۻ���.bmp", 100, 200);
			IMAGEMANAGER->addImage("sampleSky", "Images/�ϴû���.bmp", 100, 200);
		}
		//��� �̹��� 
		{
			IMAGEMANAGER->addImage("cloud", "Images/����.bmp", 4000, 1020);
			IMAGEMANAGER->addImage("mountain", "Images/��.bmp", 4000, 1020);
			IMAGEMANAGER->addImage("forest", "Images/��.bmp", 4000, 1020);
			IMAGEMANAGER->addImage("sea", "Images/����.bmp", 4000, 1020);
			IMAGEMANAGER->addImage("jungle", "Images/����.bmp", 4000, 1020);
			IMAGEMANAGER->addImage("sky_bg", "Images/�ϴù��.bmp", 4000, 1020);
		}
		//ó�� ����̹����� �ϴù������ �ʱ�ȭ
		for (int i = 0; i < 5; i++)   
		{
			isSelectBg[i] = false;
		}
		
		//������Ʈ Ÿ�� �̹��� 
		{
			IMAGEMANAGER->addFrameImage("basic", "Images/�⺻��.bmp", 320, 360, SAMPLETILEX, SAMPLETILEY);		//�⺻��
			IMAGEMANAGER->addFrameImage("snow", "Images/����.bmp", 320, 360, SAMPLETILEX, SAMPLETILEY);			//����
			IMAGEMANAGER->addFrameImage("sky", "Images/�ϴ�.bmp", 320, 360, SAMPLETILEX, SAMPLETILEY);		    //�ϴ�
			IMAGEMANAGER->addFrameImage("object", "Images/��ü.bmp", 320, 360, SAMPLETILEX, SAMPLETILEY);		//��ü
			IMAGEMANAGER->addFrameImage("basement", "Images/���϶�.bmp", 320, 360, SAMPLETILEX, SAMPLETILEY);	//����
		}

		//�÷��̾� �̹���
		{
			IMAGEMANAGER->addImage("mario", "Images/MarioIdle.bmp", 80, 80); //��������
			IMAGEMANAGER->addFrameImage("realMario", "Images/RealMarioIdle.bmp", 80, 160, 1, 2); //�� ������
			IMAGEMANAGER->addFrameImage("luigi", "Images/LuigiIdle.bmp", 80, 160, 1, 2); // ������
			IMAGEMANAGER->addFrameImage("toad", "Images/ToadIdle.bmp", 80, 160, 1, 2); //��������

			for (int i = 0; i < 4; i++)
			{
				isSelectPlayer[i] = false;
				isRenderPlayer[i] = false;
				playerIndex[i] = 0;
				playerPrev[i] = false;
			}
		}
		//���ʹ� �̹���
		{
			{
				//�� �̹���
				IMAGEMANAGER->addImage("GgulIdle", "EnemyImages/GgulIdle.bmp", 40, 40);
				IMAGEMANAGER->addFrameImage("GgulMove", "EnemyImages/GgulMove.bmp", 80, 80, 2, 2);
				IMAGEMANAGER->addImage("GgulDie", "EnemyImages/GgulDie.bmp", 40, 40);
				//�ӽ��� �̹���
				IMAGEMANAGER->addImage("MushroomIdle", "EnemyImages/MushroomIdle.bmp", 40, 40);
				IMAGEMANAGER->addFrameImage("MushroomMove", "EnemyImages/MushroomMove.bmp", 80, 80, 2, 2);
				IMAGEMANAGER->addImage("MushroomDie", "EnemyImages/MushroomDie.bmp", 40, 40);
				//������Ʋ �̹���
				IMAGEMANAGER->addImage("RedTurtleIdle", "EnemyImages/RedTurtleIdle.bmp", 40, 80);
				IMAGEMANAGER->addFrameImage("RedTurtleMove", "EnemyImages/RedTurtleMove.bmp", 80, 160, 2, 2);
				IMAGEMANAGER->addFrameImage("RedTurtleHit", "EnemyImages/RedTurtleHit.bmp", 80, 160, 2, 2);
				IMAGEMANAGER->addImage("RedTurtleDie", "EnemyImages/RedTurtleDie.bmp", 40, 80);
				//�̴���Ʋ �̹���
				IMAGEMANAGER->addImage("MiniTurtleIdle", "EnemyImages/MiniTurtleIdle.bmp", 40, 40);
				IMAGEMANAGER->addFrameImage("MiniTurtleMove", "EnemyImages/MiniTurtleMove.bmp", 80, 80, 2, 2);
				//�׸���Ʋ �̹���
				IMAGEMANAGER->addImage("GreenTurtleIdle", "EnemyImages/GreenTurtleIdle.bmp", 40, 60);
				IMAGEMANAGER->addFrameImage("GreenTurtleMove", "EnemyImages/GreenTurtleMove.bmp", 80, 120, 2, 2);
				IMAGEMANAGER->addImage("GreenTurtleDie", "EnemyImages/GreenTurtleDie.bmp", 40, 60);
				//���̷��� �̹���
				IMAGEMANAGER->addImage("SkeletonIdle", "EnemyImages/SkeletonIdle.bmp", 48, 64);
				IMAGEMANAGER->addFrameImage("SkeletonMove", "EnemyImages/SkeletonMove.bmp", 96, 128, 2, 2);
				IMAGEMANAGER->addFrameImage("SkeletonHit", "EnemyImages/SkeletonHit.bmp", 96, 128, 2, 2);
				//�̴����� �̹���
				IMAGEMANAGER->addImage("MiniCupaIdle", "EnemyImages/MiniCupaIdle.bmp", 64, 64);
				IMAGEMANAGER->addFrameImage("MiniCupaMove", "EnemyImages/MiniCupaMove.bmp", 128, 128, 2, 2);
				IMAGEMANAGER->addFrameImage("MiniCupaDie", "EnemyImages/MiniCupaDie.bmp", 128, 64, 2, 1);
				//�� �̹���
				IMAGEMANAGER->addImage("WallIdle", "EnemyImages/WallIdle.bmp", 60, 80);
				IMAGEMANAGER->addFrameImage("WallMove", "EnemyImages/WallMove.bmp", 120, 160, 2, 2);
				IMAGEMANAGER->addFrameImage("WallAttack", "EnemyImages/WallAttack.bmp", 120, 160, 2, 2);
				//���� �̹���
				IMAGEMANAGER->addImage("CupaIdle", "EnemyImages/CupaIdle.bmp", 160, 160);
				IMAGEMANAGER->addFrameImage("CupaMove", "EnemyImages/CupaMove.bmp", 640, 320, 4, 2);
				IMAGEMANAGER->addFrameImage("CupaAttack", "EnemyImages/CupaAttack.bmp", 320, 320, 2, 2);
				IMAGEMANAGER->addFrameImage("CupaFire", "EnemyImages/CupaFire.bmp", 120, 80, 2, 2);
				IMAGEMANAGER->addFrameImage("CupaDie", "EnemyImages/CupaDie.bmp", 320, 160, 2, 1);
			}
			for (int i = 0; i < 9; i++)
			{
				isSelectEnemy[i] = false;
				enemyPrev[i] = false;

			}
		}
		//�ʿ� �׷��� ���� �ε��� �ʱ�ȭ
		bossIndex = 0;
		//���� ���� �Һ��� �ʱ�ȭ
		isRenderBoss = false;
		//������ ��Ʈ �ʱ�ȭ
		_rcPage = RectMake(840, 20, 400, 600);
		//������(BnO) ��Ʈ �ʱ�ȭ
		_rcPageBnO = RectMake(840, 20, 400, 600);
		//������(BnO) �̹���
		IMAGEMANAGER->addImage("tileBookBnO", "Images/å��(BnO).bmp", 400, 600);
		//BG��ư �̹���
		IMAGEMANAGER->addFrameImage("bgButton", "Images/BG��ư.bmp", 55, 61, 1, 2);
		//OBJ��ư �̹���
		IMAGEMANAGER->addFrameImage("objButton", "Images/OBJ��ư.bmp", 84, 61, 1, 2);

		//������(PnE) ��Ʈ �ʱ�ȭ
		_rcPagePnE = RectMake(840, 20, 400, 600);
		//������(PnE) �̹���
		IMAGEMANAGER->addImage("tileBookPnE", "Images/å��(PnE).bmp", 400, 600);
		//player��ư �̹���
		IMAGEMANAGER->addFrameImage("playerButton", "Images/�÷��̾��ư.bmp", 160, 65, 1, 2);
		//enemy��ư �̹���
		IMAGEMANAGER->addFrameImage("enemyButton", "Images/���ʹ̹�ư.bmp", 134, 63, 1, 2);
		//���� ȭ��ǥ��ư �̹���
		IMAGEMANAGER->addFrameImage("leftButton", "Images/���ʹ�ư.bmp", 46, 89, 1, 2);
		//������ ȭ��ǥ ��ư �̹���
		IMAGEMANAGER->addFrameImage("rightButton", "Images/�����ʹ�ư.bmp", 46, 89, 1, 2);

		//�޴���ư �̹���
		IMAGEMANAGER->addFrameImage("button", "Images/��ư.bmp", 131, 192, 1, 6);
		//�޴���ư Ŭ�� �̹���
		IMAGEMANAGER->addFrameImage("button2", "Images/��ưŬ��.bmp", 133, 193, 1, 6);

		isClickOpen = false;
		//�޴���
		IMAGEMANAGER->addImage("MENU", "Images/��޴���.bmp", 400, 600);
		IMAGEMANAGER->addImage("EST", "Images/�̽��Ϳ���.bmp", 400, 600);
		_Est = false;
		_EE = RectMakeCenter(1050, 100, 100, 100);
	}

	//��������
	this->maptoolSetup();
	return S_OK;
}

void maptoolScene::release()
{
}

void maptoolScene::update()
{
	//ä��� ��� ����
	{
		//��������(�ǵ������)
		if (PtInRect(&_cameraRc, _ptMouse))
		{
			if (INPUT->GetKeyDown(VK_LBUTTON) || INPUT->GetKeyDown(VK_RBUTTON) || INPUT->GetKeyDown('C') || INPUT->GetKeyDown('F'))
			{
				for (int i = 0; i < TILEX * TILEY; i++)
				{
					if (PtInRect(&_tiles[i].rc, _ptMouse))
					{
						if (_save)
						{
							this->save2();
							_save = false;
						}
						else
						{
							this->save1();
							_save = true;
						}
					}
				}
			}
			//�巡��Ǯ ���
			if (PtInRect(&_cameraRc, _ptMouse) && !PtInRect(&_rcPageBnO, _ptMouse) && !PtInRect(&_rcPagePnE, _ptMouse))
			{
				if (INPUT->GetKey(VK_RBUTTON))
				{
					for (int i = 0; i < TILEX * TILEY; i++)
					{
						//ó�� Ŭ���� ���� ��ǥ�� ����ϰ� ���콺�� �̵��� ��ŭ�� ��Ʈ�� �����ϴ� �κ�
						if (PtInRect(&_tiles[i].rc, _ptMouse))
						{
							if (!_temp)
							{
								_tempLeft = _tiles[i].rc.left;
								_tempTop = _tiles[i].rc.top;
								_tempRight = _tiles[i].rc.right;
								_tempBottom = _tiles[i].rc.bottom;
								_tempX = winX;
								_tempY = winY;
								_temp = true;
							}
							//�����ʾƷ�����
							if (_tempLeft <= _tiles[i].rc.left && _tempTop <= _tiles[i].rc.top)
							{
								_rcMulti = RectMake(_tempLeft - (_tempX - winX), _tempTop - (_tempY - winY), _tiles[i].rc.right - _tempLeft + (_tempX - winX), _tiles[i].rc.bottom - _tempTop + (_tempY - winY));
							}
							//����������
							else if (_tempLeft >= _tiles[i].rc.left && _tempTop >= _tiles[i].rc.top)
							{
								_rcMulti = RectMake(_tiles[i].rc.left, _tiles[i].rc.top, _tempRight - _tiles[i].rc.left - (_tempX - winX), _tempBottom - _tiles[i].rc.top - (_tempY - winY));
							}
							//������������
							else if (_tempLeft <= _tiles[i].rc.left && _tempTop >= _tiles[i].rc.top)
							{
								_rcMulti = RectMake(_tempLeft - (_tempX - winX), _tiles[i].rc.top - (_tempY - winY), _tiles[i].rc.right - _tempLeft + (_tempX - winX), _tempBottom - _tiles[i].rc.top - (_tempY - winY));
							}
							//���ʾƷ�����
							else if (_tempLeft >= _tiles[i].rc.left && _tempTop <= _tiles[i].rc.top)
							{
								_rcMulti = RectMake(_tiles[i].rc.left, _tempTop - (_tempY - winY), _tempRight - _tiles[i].rc.left - (_tempX - winX), _tiles[i].rc.bottom - _tempTop + (_tempY - winY));
							}
						}
					}
				}
			}//�巡��Ǯ
		}
		//C ��ư�� ������ Ŭ����
		for (int i = 0; i < TILEX * TILEY; i++)
		{
			if (INPUT->GetKey('C'))
			{

				//if (_ctrlSelect == CTRL_TERRAIN)
				//{
				//	_tiles[i].terrainFrameX = 3;
				//	_tiles[i].terrainFrameY = 0;
				//	_tiles[i].terrain = terrainSelect(_currentTile.x, _currentTile.y);
				//}
				//�����ư�� ������Ʈ��?
				if (_ctrlSelect == KIND_OBJECT)
				{
					_tiles[i].objFrameX = 0;
					_tiles[i].objFrameY = 0;
					_tiles[i].obj = OBJ_NONE;
				}
			}
		}
		//F��ư�� ���� �� ����� Ÿ���� ���õ� Ÿ�Ϸ� ���� �ٲ۴�
		for (int i = 0; i < TILEX * TILEY; i++)
		{


			//���콺�� ������ �� Ÿ���� ���� ���� �����Ѵ�.
			if (PtInRect(&_tiles[i].rc, _ptMouse))
			{
				if (_ctrlSelect == KIND_OBJECT)
				{
					_SelectTilesX = _tiles[i].objFrameX;
					_SelectTilesY = _tiles[i].objFrameY;
				}
			}
			if (INPUT->GetKey('F'))
			{
				for (int j = 0; j < TILEX * TILEY; j++)
				{
					//���� Ŭ���Ѱ��� ���̶� �Ȱ��� Ÿ���� ������Ÿ�Ϸ� �ٲ۴�.
					if (_SelectTilesX == _tiles[j].objFrameX && _SelectTilesY == _tiles[j].objFrameY)//_SelectTilesX == _tiles[j].terrainFrameX && _SelectTilesY == _tiles[j].terrainFrameY ||)
					{
						//�����ư�� ������Ʈ��?
						if (_ctrlSelect == KIND_OBJECT)
						{
							_tiles[j].objFrameX = _currentTile.x;
							_tiles[j].objFrameY = _currentTile.y;
							//���������� ������Ʈ ���� ������
							switch (pageCount)
							{
							case 0:
								_tiles[j].obj = OBJ_OBJECT1;
								break;
							case 1:
								_tiles[j].obj = OBJ_OBJECT2;
								break;
							case 2:
								_tiles[j].obj = OBJ_OBJECT3;
								break;
							case 3:
								_tiles[j].obj = OBJ_OBJECT4;
								break;
							case 4:
								_tiles[j].obj = OBJ_OBJECT5;
								break;
							}
						}
						//�����ư�� ���찳��?
						if (_ctrlSelect == CTRL_OBJERASER)
						{
							_tiles[j].objFrameX = 0;
							_tiles[j].objFrameY = 0;
							_tiles[j].obj = OBJ_NONE;
						}
					}
				}
			}
		}
		//ZŰ ������ CTRL + Z ���� ȿ��(�ǵ�����)
		if (INPUT->GetKeyDown('Z'))
		{
			if (_save)
			{
				this->load1();

			}
			else
			{
				this->load2();
			}
		}
		
		//�÷��̾��
		if (_ctrlSelect == CHARACTER_PLAYER)
		{
			if (PtInRect(&(IMAGEMANAGER->findImage("mario")->boudingBox()), _ptMouse))
			{
				if (INPUT->GetKey(VK_LBUTTON))
				{
					isSelectPlayer[0] = true;
					isSelectPlayer[1] = false;
					isSelectPlayer[2] = false;
					isSelectPlayer[3] = false;
				} 
			}
			if (PtInRect(&(IMAGEMANAGER->findImage("realMario")->boudingBox()), _ptMouse))
			{
				if (INPUT->GetKey(VK_LBUTTON))
				{
					isSelectPlayer[1] = true;
					isSelectPlayer[0] = false;
					isSelectPlayer[2] = false;
					isSelectPlayer[3] = false;
				}
			}
			if (PtInRect(&(IMAGEMANAGER->findImage("luigi")->boudingBox()), _ptMouse))
			{
				if (INPUT->GetKey(VK_LBUTTON))
				{
					isSelectPlayer[2] = true;
					isSelectPlayer[1] = false;
					isSelectPlayer[0] = false;
					isSelectPlayer[3] = false;
				}
			}
			if (PtInRect(&(IMAGEMANAGER->findImage("toad")->boudingBox()), _ptMouse))
			{
				if (INPUT->GetKey(VK_LBUTTON))
				{
					isSelectPlayer[3] = true;
					isSelectPlayer[0] = false;
					isSelectPlayer[2] = false;
					isSelectPlayer[1] = false;
				}
			}

		}
		//���ʹ̼���
		if (_ctrlSelect == CHARACTER_ENEMY)
		{
			if (PtInRect(&(IMAGEMANAGER->findImage("WallIdle")->boudingBox()), _ptMouse))
			{
				if (INPUT->GetKey(VK_LBUTTON))
				{
					isSelectEnemy[0] = true;
					isSelectEnemy[1] = false;
					isSelectEnemy[2] = false;
					isSelectEnemy[3] = false;
					isSelectEnemy[4] = false;
					isSelectEnemy[5] = false;
					isSelectEnemy[6] = false;
					isSelectEnemy[7] = false;
					isSelectEnemy[8] = false;



				}
			}
			if (PtInRect(&(IMAGEMANAGER->findImage("SkeletonIdle")->boudingBox()), _ptMouse))
			{
				if (INPUT->GetKey(VK_LBUTTON))
				{
					isSelectEnemy[1] = true;
					isSelectEnemy[0] = false;
					isSelectEnemy[2] = false;
					isSelectEnemy[3] = false;
					isSelectEnemy[4] = false;
					isSelectEnemy[5] = false;
					isSelectEnemy[6] = false;
					isSelectEnemy[7] = false;
					isSelectEnemy[8] = false;


				}
			}
			if (PtInRect(&(IMAGEMANAGER->findImage("RedTurtleIdle")->boudingBox()), _ptMouse))
			{
				if (INPUT->GetKey(VK_LBUTTON))
				{
					isSelectEnemy[2] = true;
					isSelectEnemy[0] = false;
					isSelectEnemy[1] = false;
					isSelectEnemy[3] = false;
					isSelectEnemy[4] = false;
					isSelectEnemy[5] = false;
					isSelectEnemy[6] = false;
					isSelectEnemy[7] = false;
					isSelectEnemy[8] = false;


				}
			}
			if (PtInRect(&(IMAGEMANAGER->findImage("MushroomIdle")->boudingBox()), _ptMouse))
			{
				if (INPUT->GetKey(VK_LBUTTON))
				{
					isSelectEnemy[3] = true;
					isSelectEnemy[0] = false;
					isSelectEnemy[2] = false;
					isSelectEnemy[1] = false;
					isSelectEnemy[4] = false;
					isSelectEnemy[5] = false;
					isSelectEnemy[6] = false;
					isSelectEnemy[7] = false;
					isSelectEnemy[8] = false;

				}
			}
			if (PtInRect(&(IMAGEMANAGER->findImage("MiniTurtleIdle")->boudingBox()), _ptMouse))
			{
				if (INPUT->GetKey(VK_LBUTTON))
				{
					isSelectEnemy[4] = true;
					isSelectEnemy[0] = false;
					isSelectEnemy[2] = false;
					isSelectEnemy[3] = false;
					isSelectEnemy[1] = false;
					isSelectEnemy[5] = false;
					isSelectEnemy[6] = false;
					isSelectEnemy[7] = false;
					isSelectEnemy[8] = false;

				}
			}
			if (PtInRect(&(IMAGEMANAGER->findImage("MiniCupaIdle")->boudingBox()), _ptMouse))
			{
				if (INPUT->GetKey(VK_LBUTTON))
				{
					isSelectEnemy[5] = true;
					isSelectEnemy[0] = false;
					isSelectEnemy[2] = false;
					isSelectEnemy[3] = false;
					isSelectEnemy[4] = false;
					isSelectEnemy[1] = false;
					isSelectEnemy[6] = false;
					isSelectEnemy[7] = false;
					isSelectEnemy[8] = false;

				}
			}
			if (PtInRect(&(IMAGEMANAGER->findImage("GgulIdle")->boudingBox()), _ptMouse))
			{
				if (INPUT->GetKey(VK_LBUTTON))
				{
					isSelectEnemy[6] = true;
					isSelectEnemy[0] = false;
					isSelectEnemy[2] = false;
					isSelectEnemy[3] = false;
					isSelectEnemy[4] = false;
					isSelectEnemy[5] = false;
					isSelectEnemy[1] = false;
					isSelectEnemy[7] = false;
					isSelectEnemy[8] = false;

				}
			}
			if (PtInRect(&(IMAGEMANAGER->findImage("GreenTurtleIdle")->boudingBox()), _ptMouse))
			{
				if (INPUT->GetKey(VK_LBUTTON))
				{
					isSelectEnemy[7] = true;
					isSelectEnemy[0] = false;
					isSelectEnemy[2] = false;
					isSelectEnemy[3] = false;
					isSelectEnemy[4] = false;
					isSelectEnemy[5] = false;
					isSelectEnemy[6] = false;
					isSelectEnemy[1] = false;
					isSelectEnemy[8] = false;

				}
			}
			if (PtInRect(&(IMAGEMANAGER->findImage("CupaIdle")->boudingBox()), _ptMouse))
			{
				if (INPUT->GetKey(VK_LBUTTON))
				{
					isSelectEnemy[8] = true;
					isSelectEnemy[0] = false;
					isSelectEnemy[2] = false;
					isSelectEnemy[3] = false;
					isSelectEnemy[4] = false;
					isSelectEnemy[5] = false;
					isSelectEnemy[6] = false;
					isSelectEnemy[7] = false;
					isSelectEnemy[1] = false;

				}
			}

		}
		//���찳�϶� ���ʹ� ���� �ʱ�ȭ ( �ƹ��͵� �������� ���� )
		if (_isBnOOpen)
		{

		}
		else if (_isPnEOpen)
		{
			if (_ctrlSelect == CTRL_ENMERASER)
			{
				for (int i = 0; i < 9; i++)
				{
					isSelectEnemy[i] = false;
					enemyPrev[i] = false;
				}
			}
		}
		//���콺 ����Ű �������� temp�� ��Ʈ �ʱ�ȭ
		if (!_isBnOMove&&!_isPnEMove)
		{
			if (_isBnOOpen)
			{
				//if (!PtInRect(&_rcPageBnO, _ptMouse))
				{
					if (INPUT->GetKey(VK_LBUTTON))
					{
						this->setMap();
					}
					if (_isClick && INPUT->GetKeyUp(VK_LBUTTON))
					{
						this->setMap();
						_isClick = false;
						_temp = false;
					}
				}
			}
			if (_isPnEOpen)
			{
				//if (!PtInRect(&_rcPagePnE, _ptMouse))
				{
					if (INPUT->GetKey(VK_LBUTTON))
					{
						this->setPlayer();
						this->setEnemy();
					}
					if (_isClick && INPUT->GetKeyUp(VK_LBUTTON))
					{
						_isClick = false;
						_temp = false;
					}
				}
			}
			//���콺 ���� �ȿ����̰� �Ѵ�.
		}
		//���콺 ������Ű �������� �ʱ�ȭ
		if (INPUT->GetKeyUp(VK_RBUTTON))
		{
			_isBnOMove = false;
			_isPnEMove = false;
			_temp = false;
			this->setMap();
			_rcMulti = RectMake(0, 0, 0, 0);
		}
	}
	//��ư����(�ٸ��ߺ� ������ �ȵǰԲ�)
	if (PtInRect(&_rcBook, _ptMouse) || PtInRect(&_rcPageBnO, _ptMouse) || PtInRect(&_rcPagePnE, _ptMouse))
	{
		RECT temp;
		if (INPUT->GetKeyDown(VK_LBUTTON))
		{
			if (!_isBnOOpen && !_isPnEOpen)
			{
				
				if (PtInRect(&_EE, _ptMouse) && !_Est)
				{
					_Est = true;
				}
				else if (PtInRect(&_EE, _ptMouse) && _Est)
				{
					_Est = false;
				}
				if (PtInRect(&_rcSave, _ptMouse))
				{
					_ctrlSelect = CTRL_SAVE;
					this->save();
				}
				if (PtInRect(&_rcLoad, _ptMouse))
				{
					_ctrlSelect = CTRL_LOAD;
					this->load();
				}
				if (PtInRect(&_rcEraser, _ptMouse))
				{
					_ctrlSelect = CTRL_OBJERASER;
				}
				if (PtInRect(&_rcBnO, _ptMouse))
				{
					_isBnOOpen = true;
					_isPnEOpen = false;
					_ctrlSelect = KIND_BG;
				}
				if (PtInRect(&_rcPnE, _ptMouse))
				{
					_isBnOOpen = false;
					_isPnEOpen = true;
					_ctrlSelect = CHARACTER_PLAYER;
				}
				if (PtInRect(&_rcStart, _ptMouse))
				{
					this->save();
					SOUNDMANAGER->play("���ۼҸ�");
					SCENEMANAGER->loadScene("�ε�ȭ��");
				}
			}
			else if(_isBnOOpen)
			{
				if (!IntersectRect(&temp, &_rcSave, &_rcPageBnO))
				{

					if (PtInRect(&_rcSave, _ptMouse))
					{
						_ctrlSelect = CTRL_SAVE;
						this->save();
					}
				}
				if (!IntersectRect(&temp, &_rcLoad, &_rcPageBnO))
				{
					if (PtInRect(&_rcLoad, _ptMouse))
					{
						_ctrlSelect = CTRL_LOAD;
						this->load();
					}
				}
				if (!IntersectRect(&temp, &_rcEraser, &_rcPageBnO))
				{
					if (PtInRect(&_rcEraser, _ptMouse))
					{
						_ctrlSelect = CTRL_OBJERASER;

					}
				}
				if (!IntersectRect(&temp, &_rcBnO, &_rcPageBnO))
				{
					if (PtInRect(&_rcBnO, _ptMouse))
					{
						_isBnOOpen = false;
					}
				}
				if (!IntersectRect(&temp, &_rcPnE, &_rcPageBnO))
				{
					if (PtInRect(&_rcPnE, _ptMouse))
					{
						_isBnOOpen = false;
						_isPnEOpen = true;
						_ctrlSelect = CHARACTER_PLAYER;
					}
				}
				if (PtInRect(&_rcBackGround, _ptMouse))
				{
					_ctrlSelect = KIND_BG;				//Ÿ�� ���� = ���	
				}
				if (PtInRect(&_rcObject, _ptMouse))
				{
					_ctrlSelect = KIND_OBJECT;			//Ÿ�� ���� = ������Ʈ
				}
				//����ȭ��ǥ Ŭ��
				if (PtInRect(&_rcPrev, _ptMouse))
				{
					if (pageCount > 0) pageCount--;
				}
				//����ȭ��ǥ Ŭ��
				if (PtInRect(&_rcNext, _ptMouse))
				{
					if (pageCount < 4) pageCount++;
				}
				//å���� �ݱ� ��ư�� ������ ������.
				if (PtInRect(&_BnOClose, _ptMouse))
				{
					_isBnOOpen = false;
				}
				if (!IntersectRect(&temp, &_rcStart, &_rcPageBnO))
				{
					if (PtInRect(&_rcStart, _ptMouse))
					{
						this->save();
						SOUNDMANAGER->play("���ۼҸ�");
							SCENEMANAGER->loadScene("�ε�ȭ��");
					}
				}
			}
			else if (_isPnEOpen)
			{
				if (!IntersectRect(&temp, &_rcSave, &_rcPagePnE))
				{

					if (PtInRect(&_rcSave, _ptMouse))
					{
						_ctrlSelect = CTRL_SAVE;
						this->save();
					}
				}
				if (!IntersectRect(&temp, &_rcLoad, &_rcPagePnE))
				{
					if (PtInRect(&_rcLoad, _ptMouse))
					{
						_ctrlSelect = CTRL_LOAD;
						this->load();
					}
				}
				if (!IntersectRect(&temp, &_rcEraser, &_rcPagePnE))
				{
					if (PtInRect(&_rcEraser, _ptMouse))
					{
						_ctrlSelect = CTRL_ENMERASER;

					}
				}
				if (!IntersectRect(&temp, &_rcPnE, &_rcPagePnE))
				{
					if (PtInRect(&_rcPnE, _ptMouse))
					{
						_isPnEOpen = false;
					}
				}
				if (!IntersectRect(&temp, &_rcBnO, &_rcPagePnE))
				{
					if (PtInRect(&_rcBnO, _ptMouse))
					{
						_isBnOOpen = true;
						_isPnEOpen = false;
						_ctrlSelect = KIND_BG;
					}
				}
				if (PtInRect(&_rcPlayer, _ptMouse))
				{
					_ctrlSelect = CHARACTER_PLAYER;		//�÷��̾�
				}
				if (PtInRect(&_rcEnemy, _ptMouse))
				{
					_ctrlSelect = CHARACTER_ENEMY;		//���ʹ�
				}
				//å���� �ݱ� ��ư�� ������ ������.
				if (PtInRect(&_PnEClose, _ptMouse))
				{
					_isPnEOpen = false;
				}
				if (!IntersectRect(&temp, &_rcStart, &_rcPagePnE))
				{
					if (PtInRect(&_rcStart, _ptMouse))
					{
						this->save();
						SOUNDMANAGER->play("���ۼҸ�");
						SCENEMANAGER->loadScene("�ε�ȭ��");
					}
				}
			}
		}
	}
	
	//BnO
	{
		//BnO �ű��
		{
			for (int i = 0; i < 4; i++)
			{
				if (!_isBnOMove && _isBnOOpen && PtInRect(&_moveBnORC[i], _ptMouse))
				{
					if ((INPUT->GetKey(VK_RBUTTON)))
					{
						_isBnOMove = true;
						_once = true;
					}
				}
			}
			//BnO�����̴� ����
			if (_isBnOMove)
			{
				if (_once)
				{
					_ptPrevMouse.x = _ptMouse.x;
					_ptPrevMouse.y = _ptMouse.y;
					_mouseDisX = _ptPrevMouse.x - _rcPageBnO.left;
					_mouseDisY = _ptPrevMouse.y - _rcPageBnO.top;
					_once = false;
				}
				//_rcPageBnO.left = _ptMouse.x - _mouseDisX;
				//_rcPageBnO.top = _ptMouse.y - _mouseDisY;
				_rcPageBnO = RectMake(_ptMouse.x - _mouseDisX, _ptMouse.y - _mouseDisY, 400, 600);
			}
			//�ݴ� ��ư
			_BnOClose = RectMake(_rcPageBnO.left + 150, _rcPageBnO.top + 511, 100, 50);
			//BnO �ű� �� �ִ� ����RC ��ġ
			_moveBnORC[0] = RectMake(_rcPageBnO.left, _rcPageBnO.top, 400, 20);
			_moveBnORC[1] = RectMake(_rcPageBnO.left, _rcPageBnO.top, 20, 600);
			_moveBnORC[2] = RectMake(_rcPageBnO.left, _rcPageBnO.top + 580, 400, 20);
			_moveBnORC[3] = RectMake(_rcPageBnO.left + 380, _rcPageBnO.top, 20, 600);
			_tileX = _rcPageBnO.left + 36;
			_tileY = _rcPageBnO.top + 83;
		}
		if (_isBnOOpen)
		{
			//��� ���� �̹��� ��ǥ ������Ʈ
			IMAGEMANAGER->findImage("sampleCloud")->setX(_rcPageBnO.left + 35);
			IMAGEMANAGER->findImage("sampleCloud")->setY(_rcPageBnO.top + 83);
			IMAGEMANAGER->findImage("sampleMountain")->setX(_rcPageBnO.left + 150);
			IMAGEMANAGER->findImage("sampleMountain")->setY(_rcPageBnO.top + 83);
			IMAGEMANAGER->findImage("sampleForest")->setX(_rcPageBnO.left + 265);
			IMAGEMANAGER->findImage("sampleForest")->setY(_rcPageBnO.top + 83);
			IMAGEMANAGER->findImage("sampleSea")->setX(_rcPageBnO.left + 35);
			IMAGEMANAGER->findImage("sampleSea")->setY(_rcPageBnO.top + 303);
			IMAGEMANAGER->findImage("sampleJungle")->setX(_rcPageBnO.left + 150);
			IMAGEMANAGER->findImage("sampleJungle")->setY(_rcPageBnO.top + 303);
			IMAGEMANAGER->findImage("sampleSky")->setX(_rcPageBnO.left + 265);
			IMAGEMANAGER->findImage("sampleSky")->setY(_rcPageBnO.top + 303);
			//å�� ������ �̵� ��ư ��ǥ ������Ʈ
			_rcPrev = RectMake(_rcPageBnO.left + 38, _rcPageBnO.top + 511, 44, 44);	//���� ��ư ��Ʈ
			_rcNext = RectMake(_rcPageBnO.left + 318, _rcPageBnO.top + 511, 44, 44);	//���� ��ư ��Ʈ
			//å�� ��׶���� ������Ʈ ��ư��ǥ ������Ʈ
			_rcBackGround = RectMake(_rcPageBnO.left + 77, _rcPageBnO.top + 37, 55, 30);
			_rcObject = RectMake(_rcPageBnO.left + 242, _rcPageBnO.top + 37, 80, 30);
		}
	}
	//�÷��̾� ���ʹ� å��
	{
			//PnE �ű��
			for (int i = 0; i < 4; i++)
			{
				if (!_isPnEMove && _isPnEOpen && PtInRect(&_movePnERC[i], _ptMouse))
				{
					if ((INPUT->GetKey(VK_RBUTTON)))
					{
						_isPnEMove = true;
						_once = true;
					}
				}
			}
			//PnE�����̴� ����
			if (_isPnEMove)
			{
				if (_once)
				{
					_ptPrevMouse.x = _ptMouse.x;
					_ptPrevMouse.y = _ptMouse.y;
					_mouseDisX = _ptPrevMouse.x - _rcPagePnE.left;
					_mouseDisY = _ptPrevMouse.y - _rcPagePnE.top;
					_once = false;
				}
				//_rcPagePnE.left = _ptMouse.x - _mouseDisX;
				//_rcPagePnE.top = _ptMouse.y - _mouseDisY;
				_rcPagePnE = RectMake(_ptMouse.x - _mouseDisX, _ptMouse.y - _mouseDisY, 400, 600);

			}
			//�ݴ� ��ư
			_PnEClose = RectMake(_rcPagePnE.left + 150, _rcPagePnE.top + 511, 100, 50);
			//�÷��̾� �̹��� ��ǥ ������Ʈ
			IMAGEMANAGER->findImage("mario")->setX(_rcPagePnE.left + 80);
			IMAGEMANAGER->findImage("mario")->setY(_rcPagePnE.top + 150);
			IMAGEMANAGER->findImage("realMario")->setX(_rcPagePnE.left + 230);
			IMAGEMANAGER->findImage("realMario")->setY(_rcPagePnE.top + 150);
			IMAGEMANAGER->findImage("luigi")->setX(_rcPagePnE.left + 80);
			IMAGEMANAGER->findImage("luigi")->setY(_rcPagePnE.top + 300);
			IMAGEMANAGER->findImage("toad")->setX(_rcPagePnE.left + 230);
			IMAGEMANAGER->findImage("toad")->setY(_rcPagePnE.top + 300);

			//���ʹ� �̹��� ��ǥ ������Ʈ
			IMAGEMANAGER->findImage("WallIdle")->setX(_rcPagePnE.left + 60);
			IMAGEMANAGER->findImage("WallIdle")->setY(_rcPagePnE.top + 100);
			IMAGEMANAGER->findImage("SkeletonIdle")->setX(_rcPagePnE.left + 180);
			IMAGEMANAGER->findImage("SkeletonIdle")->setY(_rcPagePnE.top + 100);
			IMAGEMANAGER->findImage("RedTurtleIdle")->setX(_rcPagePnE.left + 300);
			IMAGEMANAGER->findImage("RedTurtleIdle")->setY(_rcPagePnE.top + 100);
			IMAGEMANAGER->findImage("MushroomIdle")->setX(_rcPagePnE.left + 60);
			IMAGEMANAGER->findImage("MushroomIdle")->setY(_rcPagePnE.top + 250);
			IMAGEMANAGER->findImage("CupaIdle")->setX(_rcPagePnE.left + 135);
			IMAGEMANAGER->findImage("CupaIdle")->setY(_rcPagePnE.top + 160);
			IMAGEMANAGER->findImage("MiniTurtleIdle")->setX(_rcPagePnE.left + 300);
			IMAGEMANAGER->findImage("MiniTurtleIdle")->setY(_rcPagePnE.top + 250);
			IMAGEMANAGER->findImage("MiniCupaIdle")->setX(_rcPagePnE.left + 60);
			IMAGEMANAGER->findImage("MiniCupaIdle")->setY(_rcPagePnE.top + 400);
			IMAGEMANAGER->findImage("GgulIdle")->setX(_rcPagePnE.left + 180);
			IMAGEMANAGER->findImage("GgulIdle")->setY(_rcPagePnE.top + 400);
			IMAGEMANAGER->findImage("GreenTurtleIdle")->setX(_rcPagePnE.left + 300);
			IMAGEMANAGER->findImage("GreenTurtleIdle")->setY(_rcPagePnE.top + 400);

			//PnE �ű� �� �ִ� ����RC ��ġ
			_movePnERC[0] = RectMake(_rcPagePnE.left, _rcPagePnE.top, 400, 20);
			_movePnERC[1] = RectMake(_rcPagePnE.left, _rcPagePnE.top, 20, 600);
			_movePnERC[2] = RectMake(_rcPagePnE.left, _rcPagePnE.top + 580, 400, 20);
			_movePnERC[3] = RectMake(_rcPagePnE.left + 380, _rcPagePnE.top, 20, 600);

			//player, enemy ��ư ��Ʈ
			_rcPlayer = RectMake(_rcPagePnE.left + 37, _rcPagePnE.top + 37, 160, 32);
			_rcEnemy = RectMake(_rcPagePnE.left + 231, _rcPagePnE.top + 37, 135, 32);
			//�÷��̾��
			if (_ctrlSelect == CHARACTER_PLAYER)
			{
				//���ʹ̸̹����� ����ó��
				for (int i = 0; i < 9; i++)
				{
					enemyPrev[i] = false;
				}
				//��������
				if (PtInRect(&(IMAGEMANAGER->findImage("mario")->boudingBox()), _ptMouse))
				{
					if (INPUT->GetKey(VK_LBUTTON))
					{
						isSelectPlayer[0] = true;
						isSelectPlayer[1] = false;
						isSelectPlayer[2] = false;
						isSelectPlayer[3] = false;
					}
				}
				if (isSelectPlayer[0])
				{
					for (int i = 0; i < TILEX * TILEY; i++)
					{
						if (PtInRect(&_tiles[i].rc, _ptMouse))
						{
							if (i % 100 == 99 || i >= 2400)continue;
							playerPrev[0] = true;
							playerPrev[1] = false;
							playerPrev[2] = false;
							playerPrev[3] = false;
							prevPlayerIndex[0] = i;
							break;
						}

					}
				}
				//�𸶸���
				if (PtInRect(&(IMAGEMANAGER->findImage("realMario")->boudingBox()), _ptMouse))
				{
					if (INPUT->GetKey(VK_LBUTTON))
					{
						isSelectPlayer[1] = true;
						isSelectPlayer[0] = false;
						isSelectPlayer[2] = false;
						isSelectPlayer[3] = false;
					}
				}
				if (isSelectPlayer[1])
				{

					for (int i = 0; i < TILEX * TILEY; i++)
					{
						if (PtInRect(&_tiles[i].rc, _ptMouse))
						{
							if (i % 100 == 99 || i >= 2400)continue;
							playerPrev[1] = true;
							playerPrev[0] = false;
							playerPrev[2] = false;
							playerPrev[3] = false;
							prevPlayerIndex[1] = i;
							break;

						}

					}
				}
				//������
				if (PtInRect(&(IMAGEMANAGER->findImage("luigi")->boudingBox()), _ptMouse))
				{
					if (INPUT->GetKey(VK_LBUTTON))
					{
						isSelectPlayer[2] = true;
						isSelectPlayer[1] = false;
						isSelectPlayer[0] = false;
						isSelectPlayer[3] = false;
					}
				}
				if (isSelectPlayer[2])
				{

					for (int i = 0; i < TILEX * TILEY; i++)
					{
						if (i % 100 == 99 || i >= 2400)continue;
						if (PtInRect(&_tiles[i].rc, _ptMouse))
						{
							playerPrev[2] = true;
							playerPrev[0] = false;
							playerPrev[1] = false;
							playerPrev[3] = false;
							prevPlayerIndex[2] = i;
							break;

						}

					}
				}
				//��������
				if (PtInRect(&(IMAGEMANAGER->findImage("toad")->boudingBox()), _ptMouse))
				{
					if (INPUT->GetKey(VK_LBUTTON))
					{
						isSelectPlayer[3] = true;
						isSelectPlayer[0] = false;
						isSelectPlayer[2] = false;
						isSelectPlayer[1] = false;
					}
				}
				if (isSelectPlayer[3])
				{

					for (int i = 0; i < TILEX * TILEY; i++)
					{
						if (PtInRect(&_tiles[i].rc, _ptMouse))
						{
							if (i % 100 == 99 || i >= 2400)continue;
							playerPrev[3] = true;
							playerPrev[0] = false;
							playerPrev[1] = false;
							playerPrev[2] = false;
							prevPlayerIndex[3] = i;
							break;

						}

					}
				}

			}
			//���ʹ̼���
			if (_ctrlSelect == CHARACTER_ENEMY)
			{
				//�÷��̾� �̸����� ����
				for (int i = 0; i < 4; i++)
				{
					playerPrev[i] = false;
				}
				//��
				if (PtInRect(&(IMAGEMANAGER->findImage("WallIdle")->boudingBox()), _ptMouse))
				{
					if (INPUT->GetKey(VK_LBUTTON))
					{
						isSelectEnemy[0] = true;
						isSelectEnemy[1] = false;
						isSelectEnemy[2] = false;
						isSelectEnemy[3] = false;
						isSelectEnemy[4] = false;
						isSelectEnemy[5] = false;
						isSelectEnemy[6] = false;
						isSelectEnemy[7] = false;
						isSelectEnemy[8] = false;



					}
				}
				if (isSelectEnemy[0])
				{
					for (int i = 0; i < TILEX * TILEY; i++)
					{
						if (PtInRect(&_tiles[i].rc, _ptMouse))
						{
							if (i % 100 == 99 || i >= 2400)continue;

							enemyPrev[0] = true;
							enemyPrev[1] = false;
							enemyPrev[2] = false;
							enemyPrev[3] = false;
							enemyPrev[4] = false;
							enemyPrev[5] = false;
							enemyPrev[6] = false;
							enemyPrev[7] = false;
							enemyPrev[8] = false;
							prevEnemyIndex[0] = i;
							break;

						}
					}
				}
				//����ź���
				if (PtInRect(&(IMAGEMANAGER->findImage("SkeletonIdle")->boudingBox()), _ptMouse))
				{
					if (INPUT->GetKey(VK_LBUTTON))
					{
						isSelectEnemy[1] = true;
						isSelectEnemy[0] = false;
						isSelectEnemy[2] = false;
						isSelectEnemy[3] = false;
						isSelectEnemy[4] = false;
						isSelectEnemy[5] = false;
						isSelectEnemy[6] = false;
						isSelectEnemy[7] = false;
						isSelectEnemy[8] = false;


					}
				}
				if (isSelectEnemy[1])
				{
					for (int i = 0; i < TILEX * TILEY; i++)
					{
						if (PtInRect(&_tiles[i].rc, _ptMouse))
						{
							if (i % 100 == 99 || i >= 2400)continue;
							enemyPrev[1] = true;
							enemyPrev[0] = false;
							enemyPrev[2] = false;
							enemyPrev[3] = false;
							enemyPrev[4] = false;
							enemyPrev[5] = false;
							enemyPrev[6] = false;
							enemyPrev[7] = false;
							enemyPrev[8] = false;
							prevEnemyIndex[1] = i;
							break;
						}

					}
				}
				//���� �ź���
				if (PtInRect(&(IMAGEMANAGER->findImage("RedTurtleIdle")->boudingBox()), _ptMouse))
				{
					if (INPUT->GetKey(VK_LBUTTON))
					{
						isSelectEnemy[2] = true;
						isSelectEnemy[0] = false;
						isSelectEnemy[1] = false;
						isSelectEnemy[3] = false;
						isSelectEnemy[4] = false;
						isSelectEnemy[5] = false;
						isSelectEnemy[6] = false;
						isSelectEnemy[7] = false;
						isSelectEnemy[8] = false;


					}
				}
				if (isSelectEnemy[2])
				{
					for (int i = 0; i < TILEX * TILEY; i++)
					{
						if (PtInRect(&_tiles[i].rc, _ptMouse))
						{
							if (i >= 2400)continue;
							enemyPrev[2] = true;
							enemyPrev[1] = false;
							enemyPrev[0] = false;
							enemyPrev[3] = false;
							enemyPrev[4] = false;
							enemyPrev[5] = false;
							enemyPrev[6] = false;
							enemyPrev[7] = false;
							enemyPrev[8] = false;
							prevEnemyIndex[2] = i;
							break;
						}

					}
				}
				//������
				if (PtInRect(&(IMAGEMANAGER->findImage("MushroomIdle")->boudingBox()), _ptMouse))
				{
					if (INPUT->GetKey(VK_LBUTTON))
					{
						isSelectEnemy[3] = true;
						isSelectEnemy[0] = false;
						isSelectEnemy[2] = false;
						isSelectEnemy[1] = false;
						isSelectEnemy[4] = false;
						isSelectEnemy[5] = false;
						isSelectEnemy[6] = false;
						isSelectEnemy[7] = false;
						isSelectEnemy[8] = false;

					}
				}
				if (isSelectEnemy[3])
				{
					for (int i = 0; i < TILEX * TILEY; i++)
					{
						if (PtInRect(&_tiles[i].rc, _ptMouse))
						{
							enemyPrev[3] = true;
							enemyPrev[1] = false;
							enemyPrev[2] = false;
							enemyPrev[0] = false;
							enemyPrev[4] = false;
							enemyPrev[5] = false;
							enemyPrev[6] = false;
							enemyPrev[7] = false;
							enemyPrev[8] = false;
							prevEnemyIndex[3] = i;
							break;

						}

					}
				}
				//������
				if (PtInRect(&(IMAGEMANAGER->findImage("MiniTurtleIdle")->boudingBox()), _ptMouse))
				{
					if (INPUT->GetKey(VK_LBUTTON))
					{
						isSelectEnemy[4] = true;
						isSelectEnemy[0] = false;
						isSelectEnemy[2] = false;
						isSelectEnemy[3] = false;
						isSelectEnemy[1] = false;
						isSelectEnemy[5] = false;
						isSelectEnemy[6] = false;
						isSelectEnemy[7] = false;
						isSelectEnemy[8] = false;

					}
				}
				if (isSelectEnemy[4])
				{
					for (int i = 0; i < TILEX * TILEY; i++)
					{

						if (PtInRect(&_tiles[i].rc, _ptMouse))
						{
							enemyPrev[4] = true;
							enemyPrev[1] = false;
							enemyPrev[2] = false;
							enemyPrev[3] = false;
							enemyPrev[0] = false;
							enemyPrev[5] = false;
							enemyPrev[6] = false;
							enemyPrev[7] = false;
							enemyPrev[8] = false;
							prevEnemyIndex[4] = i;
							break;

						}

					}
				}
				//���ľƵ�
				if (PtInRect(&(IMAGEMANAGER->findImage("MiniCupaIdle")->boudingBox()), _ptMouse))
				{
					if (INPUT->GetKey(VK_LBUTTON))
					{
						isSelectEnemy[5] = true;
						isSelectEnemy[0] = false;
						isSelectEnemy[2] = false;
						isSelectEnemy[3] = false;
						isSelectEnemy[4] = false;
						isSelectEnemy[1] = false;
						isSelectEnemy[6] = false;
						isSelectEnemy[7] = false;
						isSelectEnemy[8] = false;

					}
				}
				if (isSelectEnemy[5])
				{
					for (int i = 0; i < TILEX * TILEY; i++)
					{
						if (PtInRect(&_tiles[i].rc, _ptMouse))
						{
							if (i % 100 == 99 || i >= 2400)continue;
							enemyPrev[5] = true;
							enemyPrev[1] = false;
							enemyPrev[2] = false;
							enemyPrev[3] = false;
							enemyPrev[4] = false;
							enemyPrev[0] = false;
							enemyPrev[6] = false;
							enemyPrev[7] = false;
							enemyPrev[8] = false;
							prevEnemyIndex[5] = i;
							break;
						}
					}
				}
				//��	
				if (PtInRect(&(IMAGEMANAGER->findImage("GgulIdle")->boudingBox()), _ptMouse))
				{
					if (INPUT->GetKey(VK_LBUTTON))
					{
						isSelectEnemy[6] = true;
						isSelectEnemy[0] = false;
						isSelectEnemy[2] = false;
						isSelectEnemy[3] = false;
						isSelectEnemy[4] = false;
						isSelectEnemy[5] = false;
						isSelectEnemy[1] = false;
						isSelectEnemy[7] = false;
						isSelectEnemy[8] = false;

					}
				}
				if (isSelectEnemy[6])
				{
					for (int i = 0; i < TILEX * TILEY; i++)
					{
						if (PtInRect(&_tiles[i].rc, _ptMouse))
						{
							enemyPrev[6] = true;
							enemyPrev[1] = false;
							enemyPrev[2] = false;
							enemyPrev[3] = false;
							enemyPrev[4] = false;
							enemyPrev[5] = false;
							enemyPrev[0] = false;
							enemyPrev[7] = false;
							enemyPrev[8] = false;
							prevEnemyIndex[6] = i;
							break;

						}

					}
				}
				//�ʷϰź���
				if (PtInRect(&(IMAGEMANAGER->findImage("GreenTurtleIdle")->boudingBox()), _ptMouse))
				{
					if (INPUT->GetKey(VK_LBUTTON))
					{
						isSelectEnemy[7] = true;
						isSelectEnemy[0] = false;
						isSelectEnemy[2] = false;
						isSelectEnemy[3] = false;
						isSelectEnemy[4] = false;
						isSelectEnemy[5] = false;
						isSelectEnemy[6] = false;
						isSelectEnemy[1] = false;
						isSelectEnemy[8] = false;

					}
				}
				if (isSelectEnemy[7])
				{
					for (int i = 0; i < TILEX * TILEY; i++)
					{
						if (PtInRect(&_tiles[i].rc, _ptMouse))
						{
							if (i >= 2400)continue;
							enemyPrev[7] = true;
							enemyPrev[1] = false;
							enemyPrev[2] = false;
							enemyPrev[3] = false;
							enemyPrev[4] = false;
							enemyPrev[5] = false;
							enemyPrev[6] = false;
							enemyPrev[0] = false;
							enemyPrev[8] = false;
							prevEnemyIndex[7] = i;
							break;
						}

					}
				}
				//����
				if (PtInRect(&(IMAGEMANAGER->findImage("CupaIdle")->boudingBox()), _ptMouse))
				{
					if (INPUT->GetKey(VK_LBUTTON))
					{
						isSelectEnemy[8] = true;
						isSelectEnemy[0] = false;
						isSelectEnemy[2] = false;
						isSelectEnemy[3] = false;
						isSelectEnemy[4] = false;
						isSelectEnemy[5] = false;
						isSelectEnemy[6] = false;
						isSelectEnemy[7] = false;
						isSelectEnemy[1] = false;

					}
				}
				if (isSelectEnemy[8])
				{
					for (int i = 0; i < TILEX * TILEY; i++)
					{
						if (PtInRect(&_tiles[i].rc, _ptMouse))
						{

							if (i % 100 > 97 || i >= 2200)continue;
							enemyPrev[8] = true;
							enemyPrev[1] = false;
							enemyPrev[2] = false;
							enemyPrev[3] = false;
							enemyPrev[4] = false;
							enemyPrev[5] = false;
							enemyPrev[6] = false;
							enemyPrev[7] = false;
							enemyPrev[0] = false;
							prevEnemyIndex[8] = i;
							break;

						}

					}
				}
			}
		}

	//���
	if(_isBnOOpen)
	{
		if (_ctrlSelect == KIND_BG)
		{
			//������� ������ ���
			if (PtInRect(&(IMAGEMANAGER->findImage("sampleCloud")->boudingBox()), _ptMouse))
			{
				if (INPUT->GetKey(VK_LBUTTON))
				{
					isSelectBg[0] = true;
					isSelectBg[1] = false;
					isSelectBg[2] = false;
					isSelectBg[3] = false;
					isSelectBg[4] = false;
					isSelectBg[5] = false;
				}
			}
			//���� ������ ���
			if (PtInRect(&(IMAGEMANAGER->findImage("sampleMountain")->boudingBox()), _ptMouse))
			{
				if (INPUT->GetKey(VK_LBUTTON))
				{
					isSelectBg[1] = true;
					isSelectBg[0] = false;
					isSelectBg[2] = false;
					isSelectBg[3] = false;
					isSelectBg[4] = false;
					isSelectBg[5] = false;
				}
			}
			//����� ������ ���
			if (PtInRect(&(IMAGEMANAGER->findImage("sampleForest")->boudingBox()), _ptMouse))
			{
				if (INPUT->GetKey(VK_LBUTTON))
				{
					isSelectBg[2] = true;
					isSelectBg[0] = false;
					isSelectBg[1] = false;
					isSelectBg[3] = false;
					isSelectBg[4] = false;
					isSelectBg[5] = false;
				}
			}
			//���ع�� ������ ���
			if (PtInRect(&(IMAGEMANAGER->findImage("sampleSea")->boudingBox()), _ptMouse))
			{
				if (INPUT->GetKey(VK_LBUTTON))
				{
					isSelectBg[3] = true;
					isSelectBg[0] = false;
					isSelectBg[1] = false;
					isSelectBg[2] = false;
					isSelectBg[4] = false;
					isSelectBg[5] = false;
				}
			}
			//���۹�� ������ ���
			if (PtInRect(&(IMAGEMANAGER->findImage("sampleJungle")->boudingBox()), _ptMouse))
			{
				if (INPUT->GetKey(VK_LBUTTON))
				{
					isSelectBg[4] = true;
					isSelectBg[0] = false;
					isSelectBg[1] = false;
					isSelectBg[2] = false;
					isSelectBg[3] = false;
					isSelectBg[5] = false;
				}
			}
			//�ϴù�� ������ ���
			if (PtInRect(&(IMAGEMANAGER->findImage("sampleSky")->boudingBox()), _ptMouse))
			{
				if (INPUT->GetKey(VK_LBUTTON))
				{
					isSelectBg[5] = true;
					isSelectBg[1] = false;
					isSelectBg[2] = false;
					isSelectBg[3] = false;
					isSelectBg[4] = false;
					isSelectBg[0] = false;
				}
			}
		}
	}
	//ī�޶�
	{
		//ī�޶� ���콺�� �����̱�����(��/��)
		if (INPUT->GetKeyDown(VK_SPACE))
		{
			if (_mouseMove)
			{
				_mouseMove = false;
			}
			else
			{
				_mouseMove = true;
			}

		}
		if (_mouseMove)
		{
			//���콺�� ī�޶� �ȿ� �ִ���
			if (PtInRect(&_cameraRc, _ptMouse))
			{
				_mouseB = true;
			}
			else
			{
				_mouseB = false;
			}
			//���콺��Ʈ�� ���콺�� ����ٴϰ���
			_mouseRc = RectMakeCenter(_ptMouse.x, _ptMouse.y, 100, 100);
			//���콺�� ī�޶� �ȿ��� ����� ������
			if (_mouseB)
			{
				if (_mouseRc.left <= 0)
				{
					if (winX < 0)
					{
						winX += 40;

					}
				}
				if (_mouseRc.right >= 820)
				{
					if (winX > -3200)
					{
						winX -= 40;
					}
				}
				if (_mouseRc.top <= 0)
				{
					if (winY < 0)
					{
						winY += 40;
					}
				}
				if (_mouseRc.bottom >= 820)
				{
					if (winY > -200)
					{
						winY -= 40;
					}
				}
				
			}
		}
		// w ������ ������ �ø��ų� ���콺 ��Ʈ ���� ������ ���� �ö�
		if (INPUT->GetKey('W'))
		{
			if (winY < 0)
			{
				winY += 40.0f;
			}
		}
		//s ������ �ʾƷ��� �����ų� ���콺 ��Ʈ �Ʒ��� ������ �Ʒ��� ������
		if (INPUT->GetKey('S'))
		{

			if (winY > -200)
			{
				winY -= 40.0f;
			}
		}
		//d ������ �ʿ��������� �ű�ų� ���콺 ��Ʈ �����ʿ� ������ ���������� �Űܰ�
		if (INPUT->GetKey('D'))
		{
			if (winX > -3200)
			{
				winX -= 40.0f;
			}
		}
		//a ������ �ʿ������� �ű�ų� ���콺 ��Ʈ ���ʿ� ������ �������� �Űܰ�
		if (INPUT->GetKey('A'))
		{
			if (winX < 0)
			{
				winX += 40.0f;
			}
		}
		//�����θ�ŭ �ٽ� �׷���
		for (int i = 0; i < TILEY; i++)
		{
			for (int j = 0; j < TILEX; j++)
			{
				_tiles[i * TILEX + j].rc = RectMake(j * TILESIZE + winX + _bar, i * TILESIZE + winY + _bar, TILESIZE, TILESIZE);
			}
		}
		//�̴ϸ� �þ� ������
		_miniPlayer = RectMake(840 - (winX / 10), 640 - (winY / 5), 80, 160);

	}
	//������ ����Ÿ�� ��Ʈ �ʱ�ȭ
	for (int i = 0; i < SAMPLETILEY; i++)
	{
		for (int j = 0; j < SAMPLETILEX; j++)
		{
			_sampleTile[i * SAMPLETILEX + j].rc = RectMake(_rcPageBnO.left + 36 + j * TILESIZE, _rcPageBnO.top + 83 + i * TILESIZE, TILESIZE, TILESIZE);

			_sampleTile[i * SAMPLETILEX + j].objFrameX = j;
			_sampleTile[i * SAMPLETILEX + j].objFrameY = i;
		}
	}
}

void maptoolScene::render()
{
	//���õ� ��� �̹��� ���(�̴ϸ� ����)
	for (int i = 0; i < 6; i++)
	{
		if (isSelectBg[i])
			switch (i)
			{
			case 0:
				IMAGEMANAGER->render("cloud", getMemDC(), winX+20, winY+20);
				for (int i = 0; i< 4; i++)
				{
					IMAGEMANAGER->render("sampleCloud", getMemDC(), 840 + 100 * i, 640);
				}
				FrameRect(getMemDC(), _miniPlayer, RGB(100, 100, 255));
				break;
			case 1:
				IMAGEMANAGER->render("mountain", getMemDC(), winX+20, winY+20);
				for (int i = 0; i < 4; i++)
				{
					IMAGEMANAGER->scaleRender("sampleMountain", getMemDC(), 840+i*100, 640, 1, 1);
				}
				FrameRect(getMemDC(), _miniPlayer, RGB(255, 255, 255));

				break;
			case 2:
				IMAGEMANAGER->render("forest", getMemDC(), winX+20, winY+20);
				for (int i = 0; i < 4; i++)
				{
					IMAGEMANAGER->scaleRender("sampleForest", getMemDC(), 840 + i * 100, 640, 1, 1);
				}
				FrameRect(getMemDC(), _miniPlayer, RGB(100,255, 100));

				break;
			case 3:
				IMAGEMANAGER->render("sea", getMemDC(), winX+20, winY+20);
				for (int i = 0; i < 4; i++)
				{
					IMAGEMANAGER->scaleRender("sampleSea", getMemDC(), 840+100*i, 640, 1, 1);
				}
				FrameRect(getMemDC(), _miniPlayer, RGB(205, 100, 205));

				break;
			case 4:
				//�̰Ż�� ����׶����Դϴ�
				IMAGEMANAGER->render("jungle", getMemDC(), winX+20, winY+20);
				for (int i = 0; i < 4; i++)
				{
					IMAGEMANAGER->scaleRender("sampleJungle", getMemDC(), 840+100*i, 640, 1, 1);
				}
				FrameRect(getMemDC(), _miniPlayer, RGB(155, 155, 155));
				break;
			case 5:
				IMAGEMANAGER->render("sky_bg", getMemDC(), winX+20, winY+20);
				for (int i = 0; i < 4; i++)
				{
					IMAGEMANAGER->render("sampleSky", getMemDC(), 840+100*i, 640);
				}
				FrameRect(getMemDC(), _miniPlayer, RGB(0, 0, 0));
				break;
			}
	}
	//�̽��Ϳ��� �� ���(���ϼ̳�??)
	if (_Est)
	{
		IMAGEMANAGER->render("EST", getMemDC(), 840, 20);
	}
	else
	{
		IMAGEMANAGER->render("MENU", getMemDC(), 840, 20);
	}
	//�ΰ���ȭ�� �̴ϸ� ������ �׸���
	RECT rc;
	for (int i = 0; i < TILEX * TILEY; i++)
	{
		//�Ϲ� Ÿ��
		if (IntersectRect(&rc, &_tiles[i].rc, &_cameraRc))
		{
			//������Ʈ �������� �ٸ� �̹��� Ÿ�� ��Ÿ����
			if (_tiles[i].obj == OBJ_OBJECT1)
			{
				IMAGEMANAGER->frameRender("basic", getMemDC(), _tiles[i].rc.left, _tiles[i].rc.top,
					_tiles[i].objFrameX, _tiles[i].objFrameY);
			}
			if (_tiles[i].obj == OBJ_OBJECT2)
			{
				IMAGEMANAGER->frameRender("snow", getMemDC(), _tiles[i].rc.left, _tiles[i].rc.top,
					_tiles[i].objFrameX, _tiles[i].objFrameY);
			}
			if (_tiles[i].obj == OBJ_OBJECT3)
			{
				IMAGEMANAGER->frameRender("sky", getMemDC(), _tiles[i].rc.left, _tiles[i].rc.top,
					_tiles[i].objFrameX, _tiles[i].objFrameY);
			}
			if (_tiles[i].obj == OBJ_OBJECT4)
			{
				IMAGEMANAGER->frameRender("object", getMemDC(), _tiles[i].rc.left, _tiles[i].rc.top,
					_tiles[i].objFrameX, _tiles[i].objFrameY);
			}
			if (_tiles[i].obj == OBJ_OBJECT5)
			{
				IMAGEMANAGER->frameRender("basement", getMemDC(), _tiles[i].rc.left, _tiles[i].rc.top,
					_tiles[i].objFrameX, _tiles[i].objFrameY);
			}
		}
		//�̴ϸ�Ÿ��
		if (_tiles[i].obj == OBJ_OBJECT1)
		{
			IMAGEMANAGER->findImage("basic")->scaleFrameRender(getMemDC(), _mini[i].rc.left, _mini[i].rc.top,
				_tiles[i].objFrameX, _tiles[i].objFrameY,0.1,0.2);
		}
		if (_tiles[i].obj == OBJ_OBJECT2)
		{
			IMAGEMANAGER->findImage("snow")->scaleFrameRender(getMemDC(), _mini[i].rc.left, _mini[i].rc.top,
				_tiles[i].objFrameX, _tiles[i].objFrameY,0.1,0.2);
		}
		if (_tiles[i].obj == OBJ_OBJECT3)
		{
			IMAGEMANAGER->findImage("sky")->scaleFrameRender(getMemDC(), _mini[i].rc.left, _mini[i].rc.top,
				_tiles[i].objFrameX, _tiles[i].objFrameY,0.1,0.2);
		}
		if (_tiles[i].obj == OBJ_OBJECT4)
		{
			IMAGEMANAGER->findImage("object")->scaleFrameRender(getMemDC(), _mini[i].rc.left, _mini[i].rc.top,
				_tiles[i].objFrameX, _tiles[i].objFrameY,0.1,0.2);
		}
		if (_tiles[i].obj == OBJ_OBJECT5)
		{
			IMAGEMANAGER->findImage("basement")->scaleFrameRender(getMemDC(), _mini[i].rc.left, _mini[i].rc.top,
				_tiles[i].objFrameX, _tiles[i].objFrameY,0.1,0.2);
		}
		//ī�޶�Ʈ���� ���� ����
		if (IntersectRect(&rc, &_tiles[i].rc, &_cameraRc))
		{
			//�÷��̾� �ʿ� �׸���
			{
				//��������
				if (isRenderPlayer[0])
					if (IntersectRect(&rc, &_tiles[playerIndex[0]].rc, &_cameraRc))
					{
						IMAGEMANAGER->render("mario", getMemDC(), _tiles[playerIndex[0]].rc.left, _tiles[playerIndex[0]].rc.top);
					}
				//�𸶸���
				if (isRenderPlayer[1])
					if (IntersectRect(&rc, &_tiles[playerIndex[1]].rc, &_cameraRc))
					{
						IMAGEMANAGER->frameRender("realMario", getMemDC(), _tiles[playerIndex[1]].rc.left, _tiles[playerIndex[1]].rc.top, 0, 0);
					}
				//������
				if (isRenderPlayer[2])
					if (IntersectRect(&rc, &_tiles[playerIndex[2]].rc, &_cameraRc))
					{
						IMAGEMANAGER->frameRender("luigi", getMemDC(), _tiles[playerIndex[2]].rc.left, _tiles[playerIndex[2]].rc.top, 0, 0);
					}
				//��������
				if (isRenderPlayer[3])
					if (IntersectRect(&rc, &_tiles[playerIndex[3]].rc, &_cameraRc))
					{
						IMAGEMANAGER->frameRender("toad", getMemDC(), _tiles[playerIndex[3]].rc.left, _tiles[playerIndex[3]].rc.top, 0, 0);
					}
			}
			//���ʹ� �׸���
			{
				//Wall
				for (int j = 0; j < enemyIndex[0].size(); j++)
				{
					if (IntersectRect(&rc, &_tiles[enemyIndex[0][j]].rc, &_cameraRc))
					{
						if (j % 4 == 0)IMAGEMANAGER->render("WallIdle", getMemDC(), _tiles[enemyIndex[0][j]].rc.left, _tiles[enemyIndex[0][j]].rc.top);
					}
				}
				//SkeletonIdle
				for (int j = 0; j < enemyIndex[1].size(); j++)
				{
					if (IntersectRect(&rc, &_tiles[enemyIndex[1][j]].rc, &_cameraRc))
					{
						if (j % 4 == 0)IMAGEMANAGER->render("SkeletonIdle", getMemDC(), _tiles[enemyIndex[1][j]].rc.left, _tiles[enemyIndex[1][j]].rc.top);
					}
				}
				//RedTurtleIdle
				for (int j = 0; j < enemyIndex[2].size(); j++)
				{
					if (IntersectRect(&rc, &_tiles[enemyIndex[2][j]].rc, &_cameraRc))
					{
						if (j % 2 == 0)IMAGEMANAGER->render("RedTurtleIdle", getMemDC(), _tiles[enemyIndex[2][j]].rc.left, _tiles[enemyIndex[2][j]].rc.top);
					}
				}
				//MushroomIdle
				for (int j = 0; j < enemyIndex[3].size(); j++)
				{
					if (IntersectRect(&rc, &_tiles[enemyIndex[3][j]].rc, &_cameraRc))
					{
						IMAGEMANAGER->render("MushroomIdle", getMemDC(), _tiles[enemyIndex[3][j]].rc.left, _tiles[enemyIndex[3][j]].rc.top);
					}
				}
				//MiniTurtleIdle
				for (int j = 0; j < enemyIndex[4].size(); j++)
				{
					if (IntersectRect(&rc, &_tiles[enemyIndex[4][j]].rc, &_cameraRc))
					{
						IMAGEMANAGER->render("MiniTurtleIdle", getMemDC(), _tiles[enemyIndex[4][j]].rc.left, _tiles[enemyIndex[4][j]].rc.top);
					}
				}
				//MiniCupaIdle
				for (int j = 0; j < enemyIndex[5].size(); j++)
				{
					if (IntersectRect(&rc, &_tiles[enemyIndex[5][j]].rc, &_cameraRc))
					{
						if (j % 4 == 0)IMAGEMANAGER->render("MiniCupaIdle", getMemDC(), _tiles[enemyIndex[5][j]].rc.left, _tiles[enemyIndex[5][j]].rc.top);
					}
				}
				//GgulIdle
				for (int j = 0; j < enemyIndex[6].size(); j++)
				{
					if (IntersectRect(&rc, &_tiles[enemyIndex[6][j]].rc, &_cameraRc))
					{
						IMAGEMANAGER->render("GgulIdle", getMemDC(), _tiles[enemyIndex[6][j]].rc.left, _tiles[enemyIndex[6][j]].rc.top);
					}
				}
				//GreenTurtleIdle
				for (int j = 0; j < enemyIndex[7].size(); j++)
				{
					if (IntersectRect(&rc, &_tiles[enemyIndex[7][j]].rc, &_cameraRc))
					{
						if (j % 2 == 0)IMAGEMANAGER->render("GreenTurtleIdle", getMemDC(), _tiles[enemyIndex[7][j]].rc.left, _tiles[enemyIndex[7][j]].rc.top);
					}
				}

				//CupaIdle
				if (isRenderBoss)
					for (int j = 0; j < enemyIndex[8].size(); j++)
					{
						if (IntersectRect(&rc, &_tiles[enemyIndex[8][j]].rc, &_cameraRc))
						{
							if (j % 16 == 0)IMAGEMANAGER->render("CupaIdle", getMemDC(), _tiles[enemyIndex[8][j]].rc.left, _tiles[enemyIndex[8][j]].rc.top);
						}
					}
			}
		}
	}
	//�̸�����
	if (PtInRect(&_cameraRc, _ptMouse))
	{
		//�÷��̾� �̸�����
		{
			if (_ctrlSelect == CHARACTER_PLAYER)
			{
				if (playerPrev[0])
					IMAGEMANAGER->alphaRender("mario", getMemDC(), _tiles[prevPlayerIndex[0]].rc.left, _tiles[prevPlayerIndex[0]].rc.top, 100);
				if (playerPrev[1])
					IMAGEMANAGER->alphaFrameRender("realMario", getMemDC(), _tiles[prevPlayerIndex[1]].rc.left, _tiles[prevPlayerIndex[1]].rc.top, 0, 0, 100);
				if (playerPrev[2])
					IMAGEMANAGER->alphaFrameRender("luigi", getMemDC(), _tiles[prevPlayerIndex[2]].rc.left, _tiles[prevPlayerIndex[2]].rc.top, 0, 0, 100);
				if (playerPrev[3])
					IMAGEMANAGER->alphaFrameRender("toad", getMemDC(), _tiles[prevPlayerIndex[3]].rc.left, _tiles[prevPlayerIndex[3]].rc.top, 0, 0, 100);
			}
		}

		//���ʹ� �̸�����
		{
			if (_ctrlSelect == CHARACTER_ENEMY)
			{
				if (enemyPrev[0])
					IMAGEMANAGER->alphaRender("WallIdle", getMemDC(), _tiles[prevEnemyIndex[0]].rc.left, _tiles[prevEnemyIndex[0]].rc.top, 100);
				if (enemyPrev[1])
					IMAGEMANAGER->alphaRender("SkeletonIdle", getMemDC(), _tiles[prevEnemyIndex[1]].rc.left, _tiles[prevEnemyIndex[1]].rc.top, 100);
				if (enemyPrev[2])
					IMAGEMANAGER->alphaRender("RedTurtleIdle", getMemDC(), _tiles[prevEnemyIndex[2]].rc.left, _tiles[prevEnemyIndex[2]].rc.top, 100);
				if (enemyPrev[3])
					IMAGEMANAGER->alphaRender("MushroomIdle", getMemDC(), _tiles[prevEnemyIndex[3]].rc.left, _tiles[prevEnemyIndex[3]].rc.top, 100);
				if (enemyPrev[4])
					IMAGEMANAGER->alphaRender("MiniTurtleIdle", getMemDC(), _tiles[prevEnemyIndex[4]].rc.left, _tiles[prevEnemyIndex[4]].rc.top, 100);
				if (enemyPrev[5])
					IMAGEMANAGER->alphaRender("MiniCupaIdle", getMemDC(), _tiles[prevEnemyIndex[5]].rc.left, _tiles[prevEnemyIndex[5]].rc.top, 100);
				if (enemyPrev[6])
					IMAGEMANAGER->alphaRender("GgulIdle", getMemDC(), _tiles[prevEnemyIndex[6]].rc.left, _tiles[prevEnemyIndex[6]].rc.top, 100);
				if (enemyPrev[7])
					IMAGEMANAGER->alphaRender("GreenTurtleIdle", getMemDC(), _tiles[prevEnemyIndex[7]].rc.left, _tiles[prevEnemyIndex[7]].rc.top, 100);
				if (enemyPrev[8])
					IMAGEMANAGER->alphaRender("CupaIdle", getMemDC(), _tiles[prevEnemyIndex[8]].rc.left, _tiles[prevEnemyIndex[8]].rc.top, 100);
			}
		}
	}
	
	//���� ����ȭ�� �� ������ ����Ÿ�� ��Ʈ �����ֱ�(�����)-������
	if (INPUT->GetToggleKey(VK_F1))
	{
		for (int i = 0; i < TILEX * TILEY; i++)
		{
			Rectangle(getMemDC(), _tiles[i].rc);
			//FrameRect(getMemDC(), _tiles[i].rc, RGB(255, 255, 0));
		}
		if (_ctrlSelect == KIND_OBJECT)
		{
			for (int i = 0; i < SAMPLETILEX * SAMPLETILEY; i++)
			{

				FrameRect(getMemDC(), _sampleTile[i].rc, RGB(255, 255, 0));
			}
		}
	}
	//��Ʈ�� ��ư �̹��� ���
	IMAGEMANAGER->frameRender("button", getMemDC(), _rcEraser.left, _rcEraser.top, 0, 0);
	IMAGEMANAGER->frameRender("button", getMemDC(), _rcBnO.left, _rcBnO.top, 0, 4);
	IMAGEMANAGER->frameRender("button", getMemDC(), _rcSave.left, _rcSave.top, 0, 3);
	IMAGEMANAGER->frameRender("button", getMemDC(), _rcLoad.left, _rcLoad.top, 0, 2);
	IMAGEMANAGER->frameRender("button", getMemDC(), _rcPnE.left, _rcPnE.top, 0, 1);
	IMAGEMANAGER->frameRender("button", getMemDC(), _rcStart.left, _rcStart.top, 0, 5);
	//��Ʈ�� ��ư ���� ���콺 �÷��� ��� �̹��� ���
	if (PtInRect(&_rcEraser, _ptMouse))
	{
		IMAGEMANAGER->frameRender("button2", getMemDC(), _rcEraser.left, _rcEraser.top, 0, 0);
	}
	if (PtInRect(&_rcBnO, _ptMouse))
	{
		IMAGEMANAGER->frameRender("button2", getMemDC(), _rcBnO.left, _rcBnO.top, 0, 4);
	}
	if (PtInRect(&_rcSave, _ptMouse))
	{
		IMAGEMANAGER->frameRender("button2", getMemDC(), _rcSave.left, _rcSave.top, 0, 3);
	}
	if (PtInRect(&_rcLoad, _ptMouse))
	{
		IMAGEMANAGER->frameRender("button2", getMemDC(), _rcLoad.left, _rcLoad.top, 0, 2);
	}
	if (PtInRect(&_rcPnE, _ptMouse))
	{
		IMAGEMANAGER->frameRender("button2", getMemDC(), _rcPnE.left, _rcPnE.top, 0, 1);
	}
	if (PtInRect(&_rcStart, _ptMouse))
	{
		IMAGEMANAGER->frameRender("button2", getMemDC(), _rcStart.left, _rcStart.top, 0, 5);
	}

	//�̴ϸ� ������Ʋ
	for (int i = 0; i < 6; i++)
	{
		if (isSelectBg[i])
			switch (i)
			{
			case 0:
				FrameRect(getMemDC(), _miniPlayer, RGB(100, 100, 255));
				break;
			case 1:
				FrameRect(getMemDC(), _miniPlayer, RGB(255, 255, 255));
				break;
			case 2:
				FrameRect(getMemDC(), _miniPlayer, RGB(100, 255, 100));
				break;
			case 3:
				FrameRect(getMemDC(), _miniPlayer, RGB(205, 100, 205));
				break;
			case 4:
				//�̰Ż�� ����׶����Դϴ�
				FrameRect(getMemDC(), _miniPlayer, RGB(155, 155, 155));
				break;
			case 5:
				FrameRect(getMemDC(), _miniPlayer, RGB(0, 0, 0));
				break;
			}
	}
	//�ն��� UI
	IMAGEMANAGER->render("FrontUI", getMemDC());
	//å���
	if (_isBnOOpen)
	{
		//Rectangle(getMemDC(), _rcPage);
		IMAGEMANAGER->render("tileBookBnO", getMemDC(), _rcPageBnO.left, _rcPageBnO.top);
		//BG��ư �̹��� ���
		if (PtInRect(&_rcBackGround, _ptMouse) && INPUT->GetKey(VK_LBUTTON))
		{
			IMAGEMANAGER->frameRender("bgButton", getMemDC(), _rcBackGround.left, _rcBackGround.top, 0, 1);

		}
		else
			IMAGEMANAGER->frameRender("bgButton", getMemDC(), _rcBackGround.left, _rcBackGround.top, 0, 0);
		//OBJ��ư �̹��� ���
		if (PtInRect(&_rcObject, _ptMouse) && INPUT->GetKey(VK_LBUTTON))
		{
			IMAGEMANAGER->frameRender("objButton", getMemDC(), _rcObject.left, _rcObject.top, 0, 1);

		}
		else
			IMAGEMANAGER->frameRender("objButton", getMemDC(), _rcObject.left, _rcObject.top, 0, 0);
		//������Ʈ�϶� ȭ��ǥ ���
		if (_ctrlSelect == KIND_OBJECT)
		{	//���� ȭ��ǥ ��ư �̹��� ���
			if (PtInRect(&_rcPrev, _ptMouse) && INPUT->GetKey(VK_LBUTTON))
			{
				IMAGEMANAGER->frameRender("leftButton", getMemDC(), _rcPrev.left, _rcPrev.top, 0, 1);
			}
			else
				IMAGEMANAGER->frameRender("leftButton", getMemDC(), _rcPrev.left, _rcPrev.top, 0, 0);
			//������ ȭ��ǥ ��ư �̹��� ���
			if (PtInRect(&_rcNext, _ptMouse) && INPUT->GetKey(VK_LBUTTON))
			{
				IMAGEMANAGER->frameRender("rightButton", getMemDC(), _rcNext.left, _rcNext.top, 0, 1);
			}
			else
				IMAGEMANAGER->frameRender("rightButton", getMemDC(), _rcNext.left, _rcNext.top, 0, 0);
		}
		//��� ���� �̹��� ���
		if (_ctrlSelect == KIND_BG)
		{
			IMAGEMANAGER->render("sampleCloud", getMemDC(), IMAGEMANAGER->findImage("sampleCloud")->getX(), IMAGEMANAGER->findImage("sampleCloud")->getY());
			IMAGEMANAGER->render("sampleMountain", getMemDC(), IMAGEMANAGER->findImage("sampleMountain")->getX(), IMAGEMANAGER->findImage("sampleMountain")->getY());
			IMAGEMANAGER->render("sampleForest", getMemDC(), IMAGEMANAGER->findImage("sampleForest")->getX(), IMAGEMANAGER->findImage("sampleForest")->getY());
			IMAGEMANAGER->render("sampleJungle", getMemDC(), IMAGEMANAGER->findImage("sampleJungle")->getX(), IMAGEMANAGER->findImage("sampleJungle")->getY());
			IMAGEMANAGER->render("sampleSea", getMemDC(), IMAGEMANAGER->findImage("sampleSea")->getX(), IMAGEMANAGER->findImage("sampleSea")->getY());
			IMAGEMANAGER->render("sampleSky", getMemDC(), IMAGEMANAGER->findImage("sampleSky")->getX(), IMAGEMANAGER->findImage("sampleSky")->getY());
		}

		//������Ʈ ���� �̹���
		if (_ctrlSelect == KIND_OBJECT || _ctrlSelect == CTRL_OBJERASER)
		{
			//������ �̵��� ���� ��� ��ȭ
			switch (pageCount)
			{
			case 0:
			{
				IMAGEMANAGER->render("basic", getMemDC(), _sampleTile[0].rc.left, _sampleTile[0].rc.top);
				break;
			}
			case 1:
			{
				IMAGEMANAGER->render("snow", getMemDC(), _sampleTile[0].rc.left, _sampleTile[0].rc.top);
				break;
			}
			case 2:
			{
				IMAGEMANAGER->render("sky", getMemDC(), _sampleTile[0].rc.left, _sampleTile[0].rc.top);
				break;
			}
			case 3:
			{
				IMAGEMANAGER->render("object", getMemDC(), _sampleTile[0].rc.left, _sampleTile[0].rc.top);
				break;
			}
			case 4:
			{
				IMAGEMANAGER->render("basement", getMemDC(), _sampleTile[0].rc.left, _sampleTile[0].rc.top);
				break;

			}
			}
		}
		//Ŭ�� ������ �巡�� ���� �����ְ� Ŭ�� Ǯ���� �� ���콺�� �޸���.
		for (int i = 0; i < TILEX * TILEY; i++)
		{
			if (IntersectRect(&rc, &_tiles[i].rc, &_cameraRc))
			{
				if (_ctrlSelect == KIND_OBJECT)
				{
					RECT temp;
					
						if (_isClick)
						{
							FrameRect(getMemDC(), _rcDrag, RGB(255, 0, 0));
						}
						else
						{
							if (PtInRect(&_tiles[i].rc, _ptMouse) || IntersectRect(&temp, &_rcMulti, &_tiles[i].rc))
							{
							for (int j = 0; j < _currentTile.height; j++)
							{
								for (int k = 0; k < _currentTile.width; k++)
								{
									if (pageCount == 0)
									{
										IMAGEMANAGER->alphaFrameRender("basic", getMemDC(), _tiles[i].rc.left + k * TILESIZE, _tiles[i].rc.top + j * TILESIZE,
											_currentTile.x + k, _currentTile.y + j, 70);

									}
									else if (pageCount == 1)
									{
										IMAGEMANAGER->alphaFrameRender("snow", getMemDC(), _tiles[i].rc.left + k * TILESIZE, _tiles[i].rc.top + j * TILESIZE,
											_currentTile.x + k, _currentTile.y + j, 70);
									}
									else if (pageCount == 2)
									{
										IMAGEMANAGER->alphaFrameRender("sky", getMemDC(), _tiles[i].rc.left + k * TILESIZE, _tiles[i].rc.top + j * TILESIZE,
											_currentTile.x + k, _currentTile.y + j, 70);
									}
									else if (pageCount == 3)
									{
										IMAGEMANAGER->alphaFrameRender("object", getMemDC(), _tiles[i].rc.left + k * TILESIZE, _tiles[i].rc.top + j * TILESIZE,
											_currentTile.x + k, _currentTile.y + j, 70);
									}
									else if (pageCount == 4)
									{
										IMAGEMANAGER->alphaFrameRender("basement", getMemDC(), _tiles[i].rc.left + k * TILESIZE, _tiles[i].rc.top + j * TILESIZE,
											_currentTile.x + k, _currentTile.y + j, 70);
									}

								}
							}
						}
					}
				}
			}
		}
	}	
	if (_isPnEOpen)
	{
		//Rectangle(getMemDC(), _rcPage);
		IMAGEMANAGER->render("tileBookPnE", getMemDC(), _rcPagePnE.left, _rcPagePnE.top);
		//player��ư �̹��� ���
		if (PtInRect(&_rcPlayer, _ptMouse) && INPUT->GetKey(VK_LBUTTON))
		{
			IMAGEMANAGER->frameRender("playerButton", getMemDC(), _rcPlayer.left, _rcPlayer.top, 0, 1);
		}
		else
			IMAGEMANAGER->frameRender("playerButton", getMemDC(), _rcPlayer.left, _rcPlayer.top, 0, 0);
		//enemy��ư �̹��� ���
		if (PtInRect(&_rcEnemy, _ptMouse) && INPUT->GetKey(VK_LBUTTON))
		{
			IMAGEMANAGER->frameRender("enemyButton", getMemDC(), _rcEnemy.left, _rcEnemy.top, 0, 1);
		}
		else
			IMAGEMANAGER->frameRender("enemyButton", getMemDC(), _rcEnemy.left, _rcEnemy.top, 0, 0);

		
		//�÷��̾� ���� �̹��� ���
		if (_ctrlSelect == CHARACTER_PLAYER)
		{
			IMAGEMANAGER->render("mario", getMemDC(), IMAGEMANAGER->findImage("mario")->getX(), IMAGEMANAGER->findImage("mario")->getY());
			IMAGEMANAGER->frameRender("realMario", getMemDC(), IMAGEMANAGER->findImage("realMario")->getX(), IMAGEMANAGER->findImage("realMario")->getY(), 0, 0);
			IMAGEMANAGER->frameRender("luigi", getMemDC(), IMAGEMANAGER->findImage("luigi")->getX(), IMAGEMANAGER->findImage("luigi")->getY(), 0, 0);
			IMAGEMANAGER->frameRender("toad", getMemDC(), IMAGEMANAGER->findImage("toad")->getX(), IMAGEMANAGER->findImage("toad")->getY(), 0, 0);
		}

		//���ʹ� ���� �̹��� ���
		if (_ctrlSelect == CHARACTER_ENEMY|| _ctrlSelect == CTRL_ENMERASER)
		{
			IMAGEMANAGER->render("WallIdle", getMemDC(), IMAGEMANAGER->findImage("WallIdle")->getX(), IMAGEMANAGER->findImage("WallIdle")->getY());
			IMAGEMANAGER->render("SkeletonIdle", getMemDC(), IMAGEMANAGER->findImage("SkeletonIdle")->getX(), IMAGEMANAGER->findImage("SkeletonIdle")->getY());
			IMAGEMANAGER->render("RedTurtleIdle", getMemDC(), IMAGEMANAGER->findImage("RedTurtleIdle")->getX(), IMAGEMANAGER->findImage("RedTurtleIdle")->getY());
			IMAGEMANAGER->render("MushroomIdle", getMemDC(), IMAGEMANAGER->findImage("MushroomIdle")->getX(), IMAGEMANAGER->findImage("MushroomIdle")->getY());
			IMAGEMANAGER->render("MiniTurtleIdle", getMemDC(), IMAGEMANAGER->findImage("MiniTurtleIdle")->getX(), IMAGEMANAGER->findImage("MiniTurtleIdle")->getY());
			IMAGEMANAGER->render("MiniCupaIdle", getMemDC(), IMAGEMANAGER->findImage("MiniCupaIdle")->getX(), IMAGEMANAGER->findImage("MiniCupaIdle")->getY());
			IMAGEMANAGER->render("GgulIdle", getMemDC(), IMAGEMANAGER->findImage("GgulIdle")->getX(), IMAGEMANAGER->findImage("GgulIdle")->getY());
			IMAGEMANAGER->render("GreenTurtleIdle", getMemDC(), IMAGEMANAGER->findImage("GreenTurtleIdle")->getX(), IMAGEMANAGER->findImage("GreenTurtleIdle")->getY());
			IMAGEMANAGER->render("CupaIdle", getMemDC(), IMAGEMANAGER->findImage("CupaIdle")->getX(), IMAGEMANAGER->findImage("CupaIdle")->getY());
		}

	}
	if (_ctrlSelect == CTRL_OBJERASER||_ctrlSelect == CTRL_ENMERASER)
	{
		IMAGEMANAGER->render("���찳", getMemDC(), _ptMouse.x - 10, _ptMouse.y - 13);

	}
	else
	{
		IMAGEMANAGER->render("���콺", getMemDC(), _ptMouse.x - 5, _ptMouse.y - 13);
	}
}
void maptoolScene::maptoolSetup()
{
	//���� �ΰ���ȭ�� ��Ʈ �ʱ�ȭ
	for (int i = 0; i < TILEY; i++)
	{
		for (int j = 0; j < TILEX; j++)
		{
			_tiles[i * TILEX + j].rc = RectMake(j * TILESIZE, i * TILESIZE, TILESIZE, TILESIZE);
			_mini[i * TILEX + j].rc = RectMake(840+j * TILESIZE / 10,640+ i * TILESIZE / 5, TILESIZE / 10, TILESIZE / 5);
		}
	}

	

}
void maptoolScene::selectTile()
{
	for (int i = 0; i < SAMPLETILEX * SAMPLETILEY; i++)
	{
		//ó�� Ŭ���� Ÿ�� ����
		if (!_isClick)
		{
			if (PtInRect(&_sampleTile[i].rc, _ptMouse))
			{
				_currentTile.x = _sampleTile[i].objFrameX;
				_currentTile.y = _sampleTile[i].objFrameY;

				_isClick = true;
				break;
			}
		}
		//�巡���ϴ� ���߿� Ÿ�� ����/���� ���� ����
		else
		{
			if (PtInRect(&_sampleTile[i].rc, _ptMouse))
			{
				_rcDrag = RectMake(_tileX + _currentTile.x * TILESIZE, _tileY + _currentTile.y * TILESIZE,
					_currentTile.width * TILESIZE, _currentTile.height * TILESIZE);
				_currentTile.width = _sampleTile[i].objFrameX - _currentTile.x + 1;
				_currentTile.height = _sampleTile[i].objFrameY - _currentTile.y + 1;
			}
		}
	}

}
void maptoolScene::setMap()
{
	
	for (int i = 0; i < SAMPLETILEX * SAMPLETILEY; i++)
	{
		//ó�� Ŭ���� Ÿ�� ����
		if (!_isClick)
		{
			if (PtInRect(&_sampleTile[i].rc, _ptMouse))
			{
				_currentTile.x = _sampleTile[i].objFrameX;
				_currentTile.y = _sampleTile[i].objFrameY;

				_isClick = true;
				break;
			}
		}
		//�巡���ϴ� ���߿� Ÿ�� ����/���� ���� ����
		else
		{
			if (PtInRect(&_sampleTile[i].rc, _ptMouse)&&_isBnOOpen)
			{
				if (_ctrlSelect == CTRL_OBJERASER)
				{
					_ctrlSelect = KIND_OBJECT;
				}
				_rcDrag = RectMake(_tileX + _currentTile.x * TILESIZE, _tileY + _currentTile.y * TILESIZE,
					_currentTile.width * TILESIZE, _currentTile.height * TILESIZE);
				_currentTile.width = _sampleTile[i].objFrameX - _currentTile.x + 1;
				_currentTile.height = _sampleTile[i].objFrameY - _currentTile.y + 1;
			}
		}
	}
	//�ΰ���ȭ�� ��ƮƲ�� �浹�߳�?
	if (PtInRect(&_cameraRc, _ptMouse))
	{
		_paint = true;
	}
	else
	{
		_paint = false;
	}
	if (!_isBnOMove || !_isPnEMove)
	{
		if (!PtInRect(&_rcPageBnO, _ptMouse) && !PtInRect(&_rcPagePnE, _ptMouse))
		{
			for (int i = 0; i < TILEX * TILEY; i++)
			{
				RECT rc;
				if (_paint)
				{
					RECT temp;
					if (IntersectRect(&temp, &_rcMulti, &_tiles[i].rc))
					{
						//�����ư�� ���찳��?
						if (_ctrlSelect == CTRL_OBJERASER)
						{
							_tiles[i].objFrameX = 8;
							_tiles[i].objFrameY = 9;
							_tiles[i].obj = OBJ_NONE;
						}
						if (_ctrlSelect == KIND_OBJECT)
						{
							for (int j = i; j < i + _currentTile.height; j++)
							{
								for (int k = i; k < i + _currentTile.width; k++)
								{

									//���������� ������Ʈ ���� ������
									switch (pageCount)
									{
									case 0:
										_tiles[((j - i) * TILEX) + k].obj = OBJ_OBJECT1;
										break;
									case 1:
										_tiles[((j - i) * TILEX) + k].obj = OBJ_OBJECT2;
										break;
									case 2:
										_tiles[((j - i) * TILEX) + k].obj = OBJ_OBJECT3;
										break;
									case 3:
										_tiles[((j - i) * TILEX) + k].obj = OBJ_OBJECT4;
										break;
									case 4:
										_tiles[((j - i) * TILEX) + k].obj = OBJ_OBJECT5;
										break;
									}
									_tiles[((j - i) * TILEX) + k].objFrameX = _currentTile.x + (k - i);
									_tiles[((j - i) * TILEX) + k].objFrameY = _currentTile.y + (j - i);
								}

							}
						}
					}
					if (PtInRect(&_tiles[i].rc, _ptMouse))
					{
						//�����ư�� ���찳��?
						if (_ctrlSelect == CTRL_OBJERASER)
						{
							_tiles[i].objFrameX = 8;
							_tiles[i].objFrameY = 9;
							_tiles[i].obj = OBJ_NONE;
						}
						//�����ư�� ������Ʈ��?
						if (_ctrlSelect == KIND_OBJECT)
						{
							for (int j = i; j < i + _currentTile.height; j++)
							{
								for (int k = i; k < i + _currentTile.width; k++)
								{

									//���������� ������Ʈ ���� ������
									switch (pageCount)
									{
									case 0:
										_tiles[((j - i) * TILEX) + k].obj = OBJ_OBJECT1;
										break;
									case 1:
										_tiles[((j - i) * TILEX) + k].obj = OBJ_OBJECT2;
										break;
									case 2:
										_tiles[((j - i) * TILEX) + k].obj = OBJ_OBJECT3;
										break;
									case 3:
										_tiles[((j - i) * TILEX) + k].obj = OBJ_OBJECT4;
										break;
									case 4:
										_tiles[((j - i) * TILEX) + k].obj = OBJ_OBJECT5;
										break;
									}
									_tiles[((j - i) * TILEX) + k].objFrameX = _currentTile.x + (k - i);
									_tiles[((j - i) * TILEX) + k].objFrameY = _currentTile.y + (j - i);
								}

							}
						}

					}
				}
			}
		}
	}
}
void maptoolScene::setPlayer()
{

	if (_ctrlSelect == CHARACTER_PLAYER)
	{
		if(PtInRect(&_cameraRc, _ptMouse)&&!PtInRect(&_rcPagePnE,_ptMouse))
		{
			//��������
			if (isSelectPlayer[0])
			{
				for (int i = 0; i < TILEX * TILEY; i++)
				{
					if (PtInRect(&_tiles[i].rc, _ptMouse))
					{
						if (i % 100 == 99 || i >= 2400)continue;
						playerIndex[0] = i;
						isRenderPlayer[0] = true;
						isRenderPlayer[1] = false;
						isRenderPlayer[2] = false;
						isRenderPlayer[3] = false;

						//�÷��̾� ���� ����
						_playerData.champ = Toadette;
						_playerData.x = _tiles[i].rc.left;
						_playerData.y = _tiles[i].rc.top;
						break;

					}

				}
			}
			//�𸶸���
			if (isSelectPlayer[1])
			{

				for (int i = 0; i < TILEX * TILEY; i++)
				{
					if (PtInRect(&_tiles[i].rc, _ptMouse))
					{
						if (i % 100 == 99 || i >= 2400)continue;
						playerIndex[1] = i;
						isRenderPlayer[1] = true;
						isRenderPlayer[0] = false;
						isRenderPlayer[2] = false;
						isRenderPlayer[3] = false;

						//�÷��̾� ���� ����
						_playerData.champ = Mario;
						_playerData.x = _tiles[i].rc.left;
						_playerData.y = _tiles[i].rc.top;

						break;

					}

				}
			}
			//������
			if (isSelectPlayer[2])
			{

				for (int i = 0; i < TILEX * TILEY; i++)
				{
					if (i % 100 == 99 || i >= 2400)continue;
					if (PtInRect(&_tiles[i].rc, _ptMouse))
					{
						playerIndex[2] = i;
						isRenderPlayer[2] = true;
						isRenderPlayer[0] = false;
						isRenderPlayer[1] = false;
						isRenderPlayer[3] = false;

						//�÷��̾� ���� ����
						_playerData.champ = Luigi;
						_playerData.x = _tiles[i].rc.left;
						_playerData.y = _tiles[i].rc.top;

						break;

					}

				}
			}
			//��������
			if (isSelectPlayer[3])
			{

				for (int i = 0; i < TILEX * TILEY; i++)
				{
					if (PtInRect(&_tiles[i].rc, _ptMouse))
					{
						if (i % 100 == 99 || i >= 2400)continue;
						playerIndex[3] = i;
						isRenderPlayer[3] = true;
						isRenderPlayer[0] = false;
						isRenderPlayer[2] = false;
						isRenderPlayer[1] = false;

						//�÷��̾� ���� ����
						_playerData.champ = Toad;
						_playerData.x = _tiles[i].rc.left;
						_playerData.y = _tiles[i].rc.top;

						break;

					}

				}
			}
		}
	}

}
void maptoolScene::setEnemy()
{
	if (_ctrlSelect == CHARACTER_ENEMY)
	{
		if (PtInRect(&_cameraRc, _ptMouse))
		{
			//WallIdle
			if (isSelectEnemy[0])
			{
				for (int i = 0; i < TILEX * TILEY; i++)
				{
					isCollision = false;
					if (PtInRect(&_tiles[i].rc, _ptMouse))
					{
						if (i % 100 == 99 || i >= 2400)continue;

						for (int j = 0; j < usedIndex.size(); j++)
						{
							if (usedIndex[j] == i || usedIndex[j] == i + 1 || usedIndex[j] == i + 100 || usedIndex[j] == i + 101)
							{
								isCollision = true;
							}

						}
						if (!isCollision)
						{
							enemyIndex[0].push_back(i);
							enemyIndex[0].push_back(i + 1);
							enemyIndex[0].push_back(i + 100);
							enemyIndex[0].push_back(i + 101);
							usedIndex.push_back(i);
							usedIndex.push_back(i + 1);
							usedIndex.push_back(i + 100);
							usedIndex.push_back(i + 101);


							//���ʹ� ���� ����
							ENEMYDATA data;
							data.type = Wall;
							data.x = _tiles[i].rc.left;
							data.y = _tiles[i].rc.top;

							_vEnemyData.push_back(data);
							break;
						}




					}
				}
			}
			//SkeletonIdle
			if (isSelectEnemy[1])
			{
				for (int i = 0; i < TILEX * TILEY; i++)
				{
					isCollision = false;
					if (PtInRect(&_tiles[i].rc, _ptMouse))
					{
						if (i % 100 == 99 || i >= 2400)continue;
						for (int j = 0; j < usedIndex.size(); j++)
						{
							if (usedIndex[j] == i || usedIndex[j] == i + 1 || usedIndex[j] == i + 100 || usedIndex[j] == i + 101)
							{
								isCollision = true;
							}

						}
						if (!isCollision)
						{
							enemyIndex[1].push_back(i);
							enemyIndex[1].push_back(i + 1);
							enemyIndex[1].push_back(i + 100);
							enemyIndex[1].push_back(i + 101);
							usedIndex.push_back(i);
							usedIndex.push_back(i + 1);
							usedIndex.push_back(i + 100);
							usedIndex.push_back(i + 101);

							//���ʹ� ���� ����
							ENEMYDATA data;
							data.type = Skeleton;
							data.x = _tiles[i].rc.left;
							data.y = _tiles[i].rc.top;

							_vEnemyData.push_back(data);
							break;
						}

					}

				}
			}
			//RedTurtleIdle
			if (isSelectEnemy[2])
			{
				for (int i = 0; i < TILEX * TILEY; i++)
				{
					isCollision = false;
					if (PtInRect(&_tiles[i].rc, _ptMouse))
					{
						if (i >= 2400)continue;
						for (int j = 0; j < usedIndex.size(); j++)
						{
							if (usedIndex[j] == i || usedIndex[j] == i + 100)
							{
								isCollision = true;
							}

						}


						if (!isCollision)
						{
							enemyIndex[2].push_back(i);
							enemyIndex[2].push_back(i + 100);
							usedIndex.push_back(i);
							usedIndex.push_back(i + 100);
							//���ʹ� ���� ����
							ENEMYDATA data;
							data.type = RedTurtle;
							data.x = _tiles[i].rc.left;
							data.y = _tiles[i].rc.top;

							_vEnemyData.push_back(data);
							break;
						}

					}

				}
			}
			//MushroomIdle
			if (isSelectEnemy[3])
			{
				for (int i = 0; i < TILEX * TILEY; i++)
				{
					isCollision = false;
					if (PtInRect(&_tiles[i].rc, _ptMouse))
					{
						for (int j = 0; j < usedIndex.size(); j++)
						{
							if (usedIndex[j] == i)
							{
								isCollision = true;
							}

						}


						if (!isCollision)
						{
							enemyIndex[3].push_back(i);
							usedIndex.push_back(i);
							//���ʹ� ���� ����
							ENEMYDATA data;
							data.type = Mushroom;
							data.x = _tiles[i].rc.left;
							data.y = _tiles[i].rc.top;

							_vEnemyData.push_back(data);

							break;
						}

					}

				}
			}
			//MiniTurtleIdle
			if (isSelectEnemy[4])
			{
				for (int i = 0; i < TILEX * TILEY; i++)
				{

					if (PtInRect(&_tiles[i].rc, _ptMouse))
					{
						isCollision = false;
						for (int j = 0; j < usedIndex.size(); j++)
						{
							if (usedIndex[j] == i)
							{
								isCollision = true;
							}

						}


						if (!isCollision)
						{
							enemyIndex[4].push_back(i);
							usedIndex.push_back(i);
							//���ʹ� ���� ����
							ENEMYDATA data;
							data.type = MiniTurtle;
							data.x = _tiles[i].rc.left;
							data.y = _tiles[i].rc.top;

							_vEnemyData.push_back(data);

							break;
						}

					}

				}
			}
			//MiniCupaIdle
			if (isSelectEnemy[5])
			{
				for (int i = 0; i < TILEX * TILEY; i++)
				{
					if (PtInRect(&_tiles[i].rc, _ptMouse))
					{
						isCollision = false;
						if (i % 100 == 99 || i >= 2400)continue;
						for (int j = 0; j < usedIndex.size(); j++)
						{
							if (usedIndex[j] == i || usedIndex[j] == i + 1 || usedIndex[j] == i + 100 || usedIndex[j] == i + 101)
							{
								isCollision = true;
							}

						}


						if (!isCollision)
						{
							enemyIndex[5].push_back(i);
							enemyIndex[5].push_back(i + 1);
							enemyIndex[5].push_back(i + 100);
							enemyIndex[5].push_back(i + 101);
							usedIndex.push_back(i);
							usedIndex.push_back(i + 1);
							usedIndex.push_back(i + 100);
							usedIndex.push_back(i + 101);
							//���ʹ� ���� ����
							ENEMYDATA data;
							data.type = MiniCupa;
							data.x = _tiles[i].rc.left;
							data.y = _tiles[i].rc.top;

							_vEnemyData.push_back(data);

							break;
						}

					}

				}
			}
			//GgulIdle
			if (isSelectEnemy[6])
			{
				for (int i = 0; i < TILEX * TILEY; i++)
				{
					isCollision = false;
					if (PtInRect(&_tiles[i].rc, _ptMouse))
					{
						for (int j = 0; j < usedIndex.size(); j++)
						{
							if (usedIndex[j] == i)
							{
								isCollision = true;
							}

						}

						if (!isCollision)
						{
							enemyIndex[6].push_back(i);
							usedIndex.push_back(i);
							//���ʹ� ���� ����
							ENEMYDATA data;
							data.type = Ggul;
							data.x = _tiles[i].rc.left;
							data.y = _tiles[i].rc.top;

							_vEnemyData.push_back(data);

							break;
						}

					}

				}
			}
			//GreenTurtleIdle
			if (isSelectEnemy[7])
			{
				for (int i = 0; i < TILEX * TILEY; i++)
				{
					if (PtInRect(&_tiles[i].rc, _ptMouse))
					{
						isCollision = false;
						if (i >= 2400)continue;
						for (int j = 0; j < usedIndex.size(); j++)
						{
							if (usedIndex[j] == i || usedIndex[j] == i + 100)
							{
								isCollision = true;
							}

						}


						if (!isCollision)
						{
							enemyIndex[7].push_back(i);
							enemyIndex[7].push_back(i + 100);
							usedIndex.push_back(i);
							usedIndex.push_back(i + 100);
							//���ʹ� ���� ����
							ENEMYDATA data;
							data.type = GreenTurtle;
							data.x = _tiles[i].rc.left;
							data.y = _tiles[i].rc.top;

							_vEnemyData.push_back(data);

							break;
						}

					}

				}
			}
			//CupaIdle
			if (isSelectEnemy[8])
			{
				for (int i = 0; i < TILEX * TILEY; i++)
				{
					if (PtInRect(&_tiles[i].rc, _ptMouse))
					{
						if (tmp != i)
						{
							for (int k = 0; k < usedIndex.size(); k++)
							{
								if (usedIndex[k] == tmp)
								{
									usedIndex.erase(usedIndex.begin() + k);
									break;
								}
							}
							for (int k = 0; k < usedIndex.size(); k++)
							{
								if (usedIndex[k] == tmp + 1)
								{
									usedIndex.erase(usedIndex.begin() + k);
									break;
								}
							}
							for (int k = 0; k < usedIndex.size(); k++)
							{
								if (usedIndex[k] == tmp + 2)
								{
									usedIndex.erase(usedIndex.begin() + k);
									break;
								}
							}
							for (int k = 0; k < usedIndex.size(); k++)
							{
								if (usedIndex[k] == tmp + 3)
								{
									usedIndex.erase(usedIndex.begin() + k);
									break;
								}
							}

							for (int k = 0; k < usedIndex.size(); k++)
							{
								if (usedIndex[k] == tmp + 100)
								{
									usedIndex.erase(usedIndex.begin() + k);
									break;
								}
							}
							for (int k = 0; k < usedIndex.size(); k++)
							{
								if (usedIndex[k] == tmp + 101)
								{
									usedIndex.erase(usedIndex.begin() + k);
									break;
								}
							}
							for (int k = 0; k < usedIndex.size(); k++)
							{
								if (usedIndex[k] == tmp + 102)
								{
									usedIndex.erase(usedIndex.begin() + k);
									break;
								}
							}
							for (int k = 0; k < usedIndex.size(); k++)
							{
								if (usedIndex[k] == tmp + 103)
								{
									usedIndex.erase(usedIndex.begin() + k);
									break;
								}
							}

							for (int k = 0; k < usedIndex.size(); k++)
							{
								if (usedIndex[k] == tmp + 200)
								{
									usedIndex.erase(usedIndex.begin() + k);
									break;
								}
							}
							for (int k = 0; k < usedIndex.size(); k++)
							{
								if (usedIndex[k] == tmp + 201)
								{
									usedIndex.erase(usedIndex.begin() + k);
									break;
								}
							}
							for (int k = 0; k < usedIndex.size(); k++)
							{
								if (usedIndex[k] == tmp + 202)
								{
									usedIndex.erase(usedIndex.begin() + k);
									break;
								}
							}
							for (int k = 0; k < usedIndex.size(); k++)
							{
								if (usedIndex[k] == tmp + 203)
								{
									usedIndex.erase(usedIndex.begin() + k);
									break;
								}
							}

							for (int k = 0; k < usedIndex.size(); k++)
							{
								if (usedIndex[k] == tmp + 300)
								{
									usedIndex.erase(usedIndex.begin() + k);
									break;
								}
							}
							for (int k = 0; k < usedIndex.size(); k++)
							{
								if (usedIndex[k] == tmp + 301)
								{
									usedIndex.erase(usedIndex.begin() + k);
									break;
								}
							}
							for (int k = 0; k < usedIndex.size(); k++)
							{
								if (usedIndex[k] == tmp + 302)
								{
									usedIndex.erase(usedIndex.begin() + k);
									break;
								}
							}
							for (int k = 0; k < usedIndex.size(); k++)
							{
								if (usedIndex[k] == tmp + 303)
								{
									usedIndex.erase(usedIndex.begin() + k);
									break;
								}
							}


							for (int k = 0; k < enemyIndex[8].size(); k++)
							{
								if (enemyIndex[8][k] == tmp)
								{
									enemyIndex[8].erase(enemyIndex[8].begin() + k);
									break;
								}
							}
							for (int k = 0; k < enemyIndex[8].size(); k++)
							{
								if (enemyIndex[8][k] == tmp + 1)
								{
									enemyIndex[8].erase(enemyIndex[8].begin() + k);
									break;
								}
							}
							for (int k = 0; k < enemyIndex[8].size(); k++)
							{
								if (enemyIndex[8][k] == tmp + 2)
								{
									enemyIndex[8].erase(enemyIndex[8].begin() + k);
									break;
								}
							}
							for (int k = 0; k < enemyIndex[8].size(); k++)
							{
								if (enemyIndex[8][k] == tmp + 3)
								{
									enemyIndex[8].erase(enemyIndex[8].begin() + k);
									break;
								}
							}

							for (int k = 0; k < enemyIndex[8].size(); k++)
							{
								if (enemyIndex[8][k] == tmp + 100)
								{
									enemyIndex[8].erase(enemyIndex[8].begin() + k);
									break;
								}
							}
							for (int k = 0; k < enemyIndex[8].size(); k++)
							{
								if (enemyIndex[8][k] == tmp + 101)
								{
									enemyIndex[8].erase(enemyIndex[8].begin() + k);
									break;
								}
							}
							for (int k = 0; k < enemyIndex[8].size(); k++)
							{
								if (enemyIndex[8][k] == tmp + 102)
								{
									enemyIndex[8].erase(enemyIndex[8].begin() + k);
									break;
								}
							}
							for (int k = 0; k < enemyIndex[8].size(); k++)
							{
								if (enemyIndex[8][k] == tmp + 103)
								{
									enemyIndex[8].erase(enemyIndex[8].begin() + k);
									break;
								}
							}

							for (int k = 0; k < enemyIndex[8].size(); k++)
							{
								if (enemyIndex[8][k] == tmp + 200)
								{
									enemyIndex[8].erase(enemyIndex[8].begin() + k);
									break;
								}
							}
							for (int k = 0; k < enemyIndex[8].size(); k++)
							{
								if (enemyIndex[8][k] == tmp + 201)
								{
									enemyIndex[8].erase(enemyIndex[8].begin() + k);
									break;
								}
							}
							for (int k = 0; k < enemyIndex[8].size(); k++)
							{
								if (enemyIndex[8][k] == tmp + 202)
								{
									enemyIndex[8].erase(enemyIndex[8].begin() + k);
									break;
								}
							}
							for (int k = 0; k < enemyIndex[8].size(); k++)
							{
								if (enemyIndex[8][k] == tmp + 203)
								{
									enemyIndex[8].erase(enemyIndex[8].begin() + k);
									break;
								}
							}

							for (int k = 0; k < enemyIndex[8].size(); k++)
							{
								if (enemyIndex[8][k] == tmp + 300)
								{
									enemyIndex[8].erase(enemyIndex[8].begin() + k);
									break;
								}
							}
							for (int k = 0; k < enemyIndex[8].size(); k++)
							{
								if (enemyIndex[8][k] == tmp + 301)
								{
									enemyIndex[8].erase(enemyIndex[8].begin() + k);
									break;
								}
							}
							for (int k = 0; k < enemyIndex[8].size(); k++)
							{
								if (enemyIndex[8][k] == tmp + 302)
								{
									enemyIndex[8].erase(enemyIndex[8].begin() + k);
									break;
								}
							}
							for (int k = 0; k < enemyIndex[8].size(); k++)
							{
								if (enemyIndex[8][k] == tmp + 303)
								{
									enemyIndex[8].erase(enemyIndex[8].begin() + k);
									break;
								}
							}
						}
						isCollision = false;
						if (i % 100 > 97 || i >= 2200)continue;
						for (int j = 0; j < usedIndex.size(); j++)
						{
							if (usedIndex[j] == i || usedIndex[j] == i + 1 || usedIndex[j] == i + 2 || usedIndex[j] == i + 3 || usedIndex[j] == i + 100 || usedIndex[j] == i + 101 || usedIndex[j] == i + 102 || usedIndex[j] == i + 103
								|| usedIndex[j] == i + 200 || usedIndex[j] == i + 201 || usedIndex[j] == i + 202 || usedIndex[j] == i + 203 || usedIndex[j] == i + 300 || usedIndex[j] == i + 301 || usedIndex[j] == i + 302 || usedIndex[j] == i + 303)
							{
								isCollision = true;
							}

						}
						if (!isCollision)
						{
							tmp = i;
							enemyIndex[8].push_back(i);
							enemyIndex[8].push_back(i + 1);
							enemyIndex[8].push_back(i + 2);
							enemyIndex[8].push_back(i + 3);
							enemyIndex[8].push_back(i + 100);
							enemyIndex[8].push_back(i + 101);
							enemyIndex[8].push_back(i + 102);
							enemyIndex[8].push_back(i + 103);
							enemyIndex[8].push_back(i + 200);
							enemyIndex[8].push_back(i + 201);
							enemyIndex[8].push_back(i + 202);
							enemyIndex[8].push_back(i + 203);
							enemyIndex[8].push_back(i + 300);
							enemyIndex[8].push_back(i + 301);
							enemyIndex[8].push_back(i + 302);
							enemyIndex[8].push_back(i + 303);
							usedIndex.push_back(i);
							usedIndex.push_back(i + 1);
							usedIndex.push_back(i + 2);
							usedIndex.push_back(i + 3);
							usedIndex.push_back(i + 100);
							usedIndex.push_back(i + 101);
							usedIndex.push_back(i + 102);
							usedIndex.push_back(i + 103);
							usedIndex.push_back(i + 200);
							usedIndex.push_back(i + 201);
							usedIndex.push_back(i + 202);
							usedIndex.push_back(i + 203);
							usedIndex.push_back(i + 300);
							usedIndex.push_back(i + 301);
							usedIndex.push_back(i + 302);
							usedIndex.push_back(i + 303);
							//���ʹ� ���� ����
							ENEMYDATA data;
							data.type = Cupa;
							data.x = _tiles[i].rc.left;
							data.y = _tiles[i].rc.top;
							for (int i = 0; i < _vEnemyData.size(); i++)
							{
								if (_vEnemyData[i].type == Cupa)
								{
									_vEnemyData.erase(_vEnemyData.begin() + i);
									break;
								}
							}
							_vEnemyData.push_back(data);
							isRenderBoss = true;
						}
					}
				}
			}
		}
	}
	if (_ctrlSelect == CTRL_ENMERASER)
	{
		for (int i = 0; i < TILEX * TILEY; i++)
		{
			if (PtInRect(&_tiles[i].rc, _ptMouse)&&!PtInRect(&_rcPagePnE, _ptMouse))
			{
				//���ʹ� �����
				for (int j = 0; j < enemyIndex[0].size(); j++)
				{
					if (enemyIndex[0][j] == i)
					{

						switch (j % 4)
						{
						case 0:
							enemyIndex[0].erase(enemyIndex[0].begin() + j);
							enemyIndex[0].erase(enemyIndex[0].begin() + j);
							enemyIndex[0].erase(enemyIndex[0].begin() + j);
							enemyIndex[0].erase(enemyIndex[0].begin() + j);
							break;
						case 1:
							enemyIndex[0].erase(enemyIndex[0].begin() + (j - 1));
							enemyIndex[0].erase(enemyIndex[0].begin() + (j - 1));
							enemyIndex[0].erase(enemyIndex[0].begin() + (j - 1));
							enemyIndex[0].erase(enemyIndex[0].begin() + (j - 1));
							break;
						case 2:
							enemyIndex[0].erase(enemyIndex[0].begin() + (j - 2));
							enemyIndex[0].erase(enemyIndex[0].begin() + (j - 2));
							enemyIndex[0].erase(enemyIndex[0].begin() + (j - 2));
							enemyIndex[0].erase(enemyIndex[0].begin() + (j - 2));
							break;
						case 3:
							enemyIndex[0].erase(enemyIndex[0].begin() + (j - 3));
							enemyIndex[0].erase(enemyIndex[0].begin() + (j - 3));
							enemyIndex[0].erase(enemyIndex[0].begin() + (j - 3));
							enemyIndex[0].erase(enemyIndex[0].begin() + (j - 3));
							break;
						}
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == i)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == i + 1)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == i + 100)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == i + 101)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}
						break;
					}
				}
				for (int j = 0; j < enemyIndex[1].size(); j++)
				{
					if (enemyIndex[1][j] == i)
					{
						switch (j % 4)
						{
						case 0:
							enemyIndex[1].erase(enemyIndex[1].begin() + j);
							enemyIndex[1].erase(enemyIndex[1].begin() + j);
							enemyIndex[1].erase(enemyIndex[1].begin() + j);
							enemyIndex[1].erase(enemyIndex[1].begin() + j);
							break;
						case 1:
							enemyIndex[1].erase(enemyIndex[1].begin() + (j - 1));
							enemyIndex[1].erase(enemyIndex[1].begin() + (j - 1));
							enemyIndex[1].erase(enemyIndex[1].begin() + (j - 1));
							enemyIndex[1].erase(enemyIndex[1].begin() + (j - 1));
							break;
						case 2:
							enemyIndex[1].erase(enemyIndex[1].begin() + (j - 2));
							enemyIndex[1].erase(enemyIndex[1].begin() + (j - 2));
							enemyIndex[1].erase(enemyIndex[1].begin() + (j - 2));
							enemyIndex[1].erase(enemyIndex[1].begin() + (j - 2));
							break;
						case 3:
							enemyIndex[1].erase(enemyIndex[1].begin() + (j - 3));
							enemyIndex[1].erase(enemyIndex[1].begin() + (j - 3));
							enemyIndex[1].erase(enemyIndex[1].begin() + (j - 3));
							enemyIndex[1].erase(enemyIndex[1].begin() + (j - 3));
							break;
						}
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == i)
							{

								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == i + 1)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == i + 100)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == i + 101)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}
						break;
					}
				}
				for (int j = 0; j < enemyIndex[2].size(); j++)
				{
					if (enemyIndex[2][j] == i)
					{
						switch (j % 2)
						{
						case 0:
							enemyIndex[2].erase(enemyIndex[2].begin() + j);
							enemyIndex[2].erase(enemyIndex[2].begin() + j);
							break;
						case 1:
							enemyIndex[2].erase(enemyIndex[2].begin() + (j - 1));
							enemyIndex[2].erase(enemyIndex[2].begin() + (j - 1));
							break;
						}
						enemyIndex[2].erase(enemyIndex[2].begin() + j);
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == i)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}

						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == i + 100)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}

						break;
					}
				}
				for (int j = 0; j < enemyIndex[3].size(); j++)
				{
					if (enemyIndex[3][j] == i)
					{
						enemyIndex[3].erase(enemyIndex[3].begin() + j);
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == i)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}

						break;
					}
				}
				for (int j = 0; j < enemyIndex[4].size(); j++)
				{
					if (enemyIndex[4][j] == i)
					{
						enemyIndex[4].erase(enemyIndex[1].begin() + j);
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == i)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}

						break;
					}
				}
				for (int j = 0; j < enemyIndex[5].size(); j++)
				{
					if (enemyIndex[5][j] == i)
					{
						switch (j % 4)
						{
						case 0:
							enemyIndex[5].erase(enemyIndex[5].begin() + j);
							enemyIndex[5].erase(enemyIndex[5].begin() + j);
							enemyIndex[5].erase(enemyIndex[5].begin() + j);
							enemyIndex[5].erase(enemyIndex[5].begin() + j);
							break;
						case 1:
							enemyIndex[5].erase(enemyIndex[5].begin() + (j - 1));
							enemyIndex[5].erase(enemyIndex[5].begin() + (j - 1));
							enemyIndex[5].erase(enemyIndex[5].begin() + (j - 1));
							enemyIndex[5].erase(enemyIndex[5].begin() + (j - 1));
							break;
						case 2:
							enemyIndex[5].erase(enemyIndex[5].begin() + (j - 2));
							enemyIndex[5].erase(enemyIndex[5].begin() + (j - 2));
							enemyIndex[5].erase(enemyIndex[5].begin() + (j - 2));
							enemyIndex[5].erase(enemyIndex[5].begin() + (j - 2));
							break;
						case 3:
							enemyIndex[5].erase(enemyIndex[5].begin() + (j - 3));
							enemyIndex[5].erase(enemyIndex[5].begin() + (j - 3));
							enemyIndex[5].erase(enemyIndex[5].begin() + (j - 3));
							enemyIndex[5].erase(enemyIndex[5].begin() + (j - 3));
							break;
						}
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == i)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == i + 1)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == i + 100)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == i + 101)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}
						break;
					}
				}
				for (int j = 0; j < enemyIndex[6].size(); j++)
				{
					if (enemyIndex[6][j] == i)
					{
						enemyIndex[6].erase(enemyIndex[6].begin() + j);
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == i)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}

						break;
					}
				}
				for (int j = 0; j < enemyIndex[7].size(); j++)
				{
					if (enemyIndex[7][j] == i)
					{
						switch (j % 2)
						{
						case 0:
							enemyIndex[7].erase(enemyIndex[7].begin() + j);
							enemyIndex[7].erase(enemyIndex[7].begin() + j);
							break;
						case 1:
							enemyIndex[7].erase(enemyIndex[7].begin() + (j - 1));
							enemyIndex[7].erase(enemyIndex[7].begin() + (j - 1));
							break;
						}
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == i)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == i)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}

						break;
					}
				}

				//���� �����
				for (int j = 0; j < enemyIndex[8].size(); j++)
				{
					if (enemyIndex[8][j] == i)
					{
						isSelectEnemy[8] = false;
						isRenderBoss = false;
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == tmp)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == tmp + 1)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == tmp + 2)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == tmp + 3)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}

						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == tmp + 100)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == tmp + 101)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == tmp + 102)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == tmp + 103)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}

						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == tmp + 200)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == tmp + 201)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == tmp + 202)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == tmp + 203)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == tmp + 300)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == tmp + 301)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == tmp + 302)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}
						}
						for (int k = 0; k < usedIndex.size(); k++)
						{
							if (usedIndex[k] == tmp + 303)
							{
								usedIndex.erase(usedIndex.begin() + k);
								break;
							}

						}
					}
				}
			}
		}
	}
}
void maptoolScene::save()
{
	HANDLE file;
	DWORD write;
	_vectorSize = _vEnemyData.size();
	_readCnt = 0;
	LARGE_INTEGER l_int;
	file = CreateFile("save.map", GENERIC_WRITE, 0, NULL, CREATE_ALWAYS,
		FILE_ATTRIBUTE_NORMAL, NULL);
	WriteFile(file, _tiles, sizeof(tagTile) * TILEX * TILEY, &write, NULL);
	WriteFile(file, isSelectBg, sizeof(isSelectBg)*6, &write, NULL);
	
	CloseHandle(file);
	file = CreateFile("vectorSizeSave.map", GENERIC_WRITE, 0, NULL, CREATE_ALWAYS,
		FILE_ATTRIBUTE_NORMAL, NULL);
	WriteFile(file, &_vectorSize, sizeof(int), &write, NULL);
	CloseHandle(file);
	file = CreateFile("savePlayer.map", GENERIC_WRITE, 0, NULL, CREATE_ALWAYS,
		FILE_ATTRIBUTE_NORMAL, NULL);
	WriteFile(file, &_playerData, sizeof(PLAYERDATA), &write, NULL);
	CloseHandle(file);
	file = CreateFile("saveEnemy.map", GENERIC_WRITE, 0, NULL, CREATE_ALWAYS,
		FILE_ATTRIBUTE_NORMAL, NULL);
	while (_readCnt < _vectorSize)
	{
		l_int.QuadPart = sizeof(ENEMYDATA) * _readCnt;
		SetFilePointerEx(file, l_int, NULL, FILE_CURRENT);
		WriteFile(file, &_vEnemyData[_readCnt], sizeof(ENEMYDATA), &write, NULL);
		_readCnt++;
	}
	CloseHandle(file);
}
void maptoolScene::load()
{
	_readCnt = 0;
	HANDLE file;
	DWORD read;
	LARGE_INTEGER l_int;
	_vEnemyData.clear();

	file = CreateFile("save.map", GENERIC_READ, 0, NULL, OPEN_EXISTING,
		FILE_ATTRIBUTE_NORMAL, NULL);
	ReadFile(file, _tiles, sizeof(tagTile) * TILEX * TILEY, &read, NULL);
	ReadFile(file, isSelectBg, sizeof(isSelectBg)*6, &read, NULL);
	CloseHandle(file);
	file = CreateFile("vectorSizeSave.map", GENERIC_READ, 0, NULL, OPEN_EXISTING,
		FILE_ATTRIBUTE_NORMAL, NULL);
	ReadFile(file, &_vectorSize, sizeof(int), &read, NULL);
	CloseHandle(file);
	file = CreateFile("savePlayer.map", GENERIC_READ, 0, NULL, OPEN_EXISTING,
		FILE_ATTRIBUTE_NORMAL, NULL);
	ReadFile(file, &_playerData, sizeof(PLAYERDATA), &read, NULL);
	CloseHandle(file);
	file = CreateFile("saveEnemy.map", GENERIC_READ, 0, NULL, OPEN_EXISTING,
		FILE_ATTRIBUTE_NORMAL, NULL);
	while (_readCnt < _vectorSize)
	{
		ENEMYDATA _data;
		l_int.QuadPart = sizeof(ENEMYDATA) * _readCnt;
		SetFilePointerEx(file, l_int, NULL, FILE_CURRENT);
		ReadFile(file, &_data, sizeof(ENEMYDATA), &read, NULL);
		_vEnemyData.push_back(_data);
		_readCnt++;
	}
	CloseHandle(file);
}
void maptoolScene::save1()
{
	HANDLE file;
	DWORD write;

	file = CreateFile("save1.map", GENERIC_WRITE, 0, NULL, CREATE_ALWAYS,
		FILE_ATTRIBUTE_NORMAL, NULL);
	WriteFile(file, _tiles, sizeof(tagTile) * TILEX * TILEY, &write, NULL);
	WriteFile(file, isSelectBg, sizeof(isSelectBg) * 6, &write, NULL);
	CloseHandle(file);
}
void maptoolScene::load1()
{
	HANDLE file;
	DWORD read;

	file = CreateFile("save1.map", GENERIC_READ, 0, NULL, OPEN_EXISTING,
		FILE_ATTRIBUTE_NORMAL, NULL);
	ReadFile(file, _tiles, sizeof(tagTile) * TILEX * TILEY, &read, NULL);
	ReadFile(file, isSelectBg, sizeof(isSelectBg) * 6, &read, NULL);
	CloseHandle(file);
}
void maptoolScene::save2()
{
	HANDLE file;
	DWORD write;

	file = CreateFile("save2.map", GENERIC_WRITE, 0, NULL, CREATE_ALWAYS,
		FILE_ATTRIBUTE_NORMAL, NULL);
	WriteFile(file, _tiles, sizeof(tagTile) * TILEX * TILEY, &write, NULL);
	WriteFile(file, isSelectBg, sizeof(isSelectBg) * 6, &write, NULL);
	CloseHandle(file);
}
void maptoolScene::load2()
{
	HANDLE file;
	DWORD read;

	file = CreateFile("save2.map", GENERIC_READ, 0, NULL, OPEN_EXISTING,
		FILE_ATTRIBUTE_NORMAL, NULL);
	ReadFile(file, _tiles, sizeof(tagTile) * TILEX * TILEY, &read, NULL);
	ReadFile(file, isSelectBg, sizeof(isSelectBg) * 6, &read, NULL);
	CloseHandle(file);
}