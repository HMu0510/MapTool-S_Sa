#include "stdafx.h"
#include "minion.h"
