#include "stdafx.h"
#include "PlayMap.h"

HRESULT PlayMap::init()
{
	_collision = IMAGEMANAGER->addImage("collision", "collision.bmp", 800, 800, false);
	for (int i = 0; i < TILEY; i++)
	{
		for (int j = 0; j < TILEX; j++)
		{
			_tiles[i * TILEX + j].rc = RectMake(j * TILESIZE, i * TILESIZE, TILESIZE, TILESIZE);
		}
	}
	
	_rc = RectMakeCenter(100, 100, 100, 100);
	return S_OK;
}

void PlayMap::release()
{
}

void PlayMap::update()
{
	this->load();
	if (INPUT->GetKey(VK_DOWN))
	{
		_rc.bottom += 5.0f;
		_rc.top += 5.0f;
	}
	if (INPUT->GetKey(VK_UP))
	{
		_rc.bottom -= 5.0f;
		_rc.top -= 5.0f;
	}
	if (INPUT->GetKey(VK_RIGHT))
	{
		_rc.right += 5.0f;
		_rc.left += 5.0f;
	}
	if (INPUT->GetKey(VK_LEFT))
	{
		_rc.right -= 5.0f;
		_rc.left -= 5.0f;
	}
	_probeY = _rc.bottom;
	for (int i = _probeY - 10; i < _probeY + 10; i++)
	{
		COLORREF color = GetPixel(_collision->getMemDC(), _rc.left + (_rc.right - _rc.left)/2, i);
		int r = GetRValue(color);
		int g = GetGValue(color);
		int b = GetBValue(color);
		if (!(r == 255 && g == 0 && b == 255))
		{
			_rc.top = i - 100;
			_rc.bottom = i;
			break;
		}
	}
}

void PlayMap::render()
{
	for (int i = 0; i < TILEX * TILEY; i++)
	{
		IMAGEMANAGER->frameRender("tilemap", getMemDC(), _tiles[i].rc.left, _tiles[i].rc.top,
			_tiles[i].terrainFrameX, _tiles[i].terrainFrameY);	
	}
	//�ΰ���ȭ�� ������Ʈ�� �׸���
	for (int i = 0; i < TILEX * TILEY; i++)
	{
		if (_tiles[i].obj == OBJ_NONE) continue;
		IMAGEMANAGER->frameRender("tilemap", _collision->getMemDC(), _tiles[i].rc.left, _tiles[i].rc.top,
			_tiles[i].objFrameX, _tiles[i].objFrameY);
		IMAGEMANAGER->frameRender("tilemap", getMemDC(), _tiles[i].rc.left, _tiles[i].rc.top,
			_tiles[i].objFrameX, _tiles[i].objFrameY);
	}
	IMAGEMANAGER->render("collision", getMemDC(), 0, 0);
	Rectangle(getMemDC(), _rc);
	
	CHAR str[128];
	sprintf(str, "%d", _rc.top);
	TextOut(getMemDC(), 100, 100, str, strlen(str));
}
void PlayMap::save()
{
	HANDLE file;
	DWORD write;

	file = CreateFile("save.map", GENERIC_WRITE, 0, NULL, CREATE_ALWAYS,
		FILE_ATTRIBUTE_NORMAL, NULL);
	WriteFile(file, _tiles, sizeof(tagTile) * TILEX * TILEY, &write, NULL);
	CloseHandle(file);
}

void PlayMap::load()
{
	HANDLE file;
	DWORD read;

	file = CreateFile("save.map", GENERIC_READ, 0, NULL, OPEN_EXISTING,
		FILE_ATTRIBUTE_NORMAL, NULL);
	ReadFile(file, _tiles, sizeof(tagTile) * TILEX * TILEY, &read, NULL);
	CloseHandle(file);
}